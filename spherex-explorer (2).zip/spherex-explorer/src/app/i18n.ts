import { usePrefs } from './prefs';
import type { Lang } from './prefs';

/** Small dictionary for navigation and settings. Extend by adding keys; missing keys fall back to English. */
const D: Record<string, Record<Lang, string>> = {
  explorer: { en: 'Explorer', fr: 'Explorateur', es: 'Explorador' },
  measure: { en: 'Measure', fr: 'Mesurer', es: 'Medir' },
  spectrum: { en: 'Spectrum', fr: 'Spectre', es: 'Espectro' },
  exposures: { en: 'Exposures', fr: 'Expositions', es: 'Exposiciones' },
  candidates: { en: 'Candidates', fr: 'Candidats', es: 'Candidatos' },
  inject: { en: 'Inject test', fr: 'Test d’injection', es: 'Prueba de inyección' },
  compare: { en: 'Real sky', fr: 'Ciel réel', es: 'Cielo real' },
  tests: { en: 'Test targets', fr: 'Cibles de test', es: 'Objetivos de prueba' },
  about: { en: 'About', fr: 'À propos', es: 'Acerca de' },
  settings: { en: 'Settings', fr: 'Réglages', es: 'Ajustes' },
  tools: { en: 'Tools', fr: 'Outils', es: 'Herramientas' },
  dataSaver: { en: 'Data saver', fr: 'Économiseur de données', es: 'Ahorro de datos' },
  palette: { en: 'Colour-blind-safe colours', fr: 'Couleurs adaptées au daltonisme', es: 'Colores aptos para daltonismo' },
  motion: { en: 'Reduce motion', fr: 'Réduire les animations', es: 'Reducir movimiento' },
  language: { en: 'Language', fr: 'Langue', es: 'Idioma' },
  save: { en: 'Save as candidate', fr: 'Enregistrer comme candidat', es: 'Guardar como candidato' },
  export: { en: 'Export CSV', fr: 'Exporter en CSV', es: 'Exportar CSV' },
};
export const useT = () => { const { lang } = usePrefs(); return (k: string) => D[k]?.[lang] ?? D[k]?.en ?? k; };
