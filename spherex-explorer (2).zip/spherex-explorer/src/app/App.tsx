import { lazy, Suspense } from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { ExplorationPage } from '../features/exploration/ExplorationPage';
import { AppProviders } from './providers';

const page = <T extends string>(load: () => Promise<Record<T, React.ComponentType>>, name: T) => lazy(() => load().then((m) => ({ default: m[name] })));
const Measure = page(() => import('../features/screens/MeasurePage'), 'MeasurePage');
const Spectrum = page(() => import('../features/screens/SpectrumPage'), 'SpectrumPage');
const Exposures = page(() => import('../features/screens/ExposuresPage'), 'ExposuresPage');
const Candidates = page(() => import('../features/screens/CandidatesPage'), 'CandidatesPage');
const Inject = page(() => import('../features/screens/InjectPage'), 'InjectPage');
const Compare = page(() => import('../features/screens/ComparePage'), 'ComparePage');
const Tests = page(() => import('../features/screens/TestsPage'), 'TestsPage');
const About = page(() => import('../features/screens/AboutPage'), 'AboutPage');
const Settings = page(() => import('../features/screens/SettingsPage'), 'SettingsPage');

export function App() {
  return (
    <AppProviders>
      <BrowserRouter>
        <Suspense fallback={<div className="screen" style={{ display: 'grid', placeItems: 'center', color: '#9fadc4' }}>Loading…</div>}>
          <Routes>
            <Route path="/" element={<ExplorationPage />} />
            <Route path="/measure" element={<Measure />} />
            <Route path="/spectrum" element={<Spectrum />} />
            <Route path="/exposures" element={<Exposures />} />
            <Route path="/candidates" element={<Candidates />} />
            <Route path="/inject" element={<Inject />} />
            <Route path="/compare" element={<Compare />} />
            <Route path="/tests" element={<Tests />} />
            <Route path="/about" element={<About />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="*" element={<ExplorationPage />} />
          </Routes>
        </Suspense>
      </BrowserRouter>
    </AppProviders>
  );
}
