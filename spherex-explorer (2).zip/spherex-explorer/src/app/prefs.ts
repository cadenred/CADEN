import { useSyncExternalStore } from 'react';

export type Lang = 'en' | 'fr' | 'es';
export type Prefs = { dataSaver: boolean; palette: 'default' | 'cvd'; reduceMotion: boolean; lang: Lang };
const KEY = 'lumenx-prefs';
const systemReduce = () => typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
const defaults = (): Prefs => ({ dataSaver: false, palette: 'default', reduceMotion: systemReduce(), lang: 'en' });
const read = (): Prefs => { try { return { ...defaults(), ...JSON.parse(localStorage.getItem(KEY) ?? '{}') }; } catch { return defaults(); } };
let cur = read();
const subs = new Set<() => void>();
export const getPrefs = () => cur;
export function setPrefs(p: Partial<Prefs>) {
  cur = { ...cur, ...p }; try { localStorage.setItem(KEY, JSON.stringify(cur)); } catch { /* ignore */ }
  document.documentElement.dataset.motion = cur.reduceMotion ? 'reduce' : 'full'; document.documentElement.lang = cur.lang;
  subs.forEach((f) => f());
}
export const usePrefs = () => useSyncExternalStore((f) => { subs.add(f); return () => subs.delete(f); }, getPrefs);
if (typeof document !== 'undefined') { document.documentElement.dataset.motion = cur.reduceMotion ? 'reduce' : 'full'; document.documentElement.lang = cur.lang; }
