import { useEffect, useState } from 'react';
import type { MotionFit } from './astrometry';

export type Candidate = {
  id: string; created: string; targetKey: string; name: string; ra: number; dec: number; fov: number;
  visits: number; pm: number; pmErr: number; pmE: number; pmN: number; pa: number; plx: number; plxErr: number;
  cls: string; inGaia: boolean; inWise: boolean; flux: { first: number; last: number; dF: number; pct: number; z: number } | null;
  link: string; note: string;
};
const KEY = 'lumenx-candidates';
const load = (): Candidate[] => { try { const v = JSON.parse(localStorage.getItem(KEY) ?? '[]'); return Array.isArray(v) ? v : []; } catch { return []; } };
const listeners = new Set<() => void>();
const save = (c: Candidate[]) => { try { localStorage.setItem(KEY, JSON.stringify(c)); } catch { /* ignore */ } listeners.forEach((f) => f()); };

export const addCandidate = (c: Candidate) => save([c, ...load().filter((x) => x.id !== c.id)]);
export const removeCandidate = (id: string) => save(load().filter((c) => c.id !== id));
export const clearCandidates = () => save([]);
export const updateNote = (id: string, note: string) => save(load().map((c) => (c.id === id ? { ...c, note } : c)));
export function useCandidates() {
  const [list, setList] = useState<Candidate[]>(load);
  useEffect(() => { const f = () => setList(load()); listeners.add(f); window.addEventListener('storage', f); return () => { listeners.delete(f); window.removeEventListener('storage', f); }; }, []);
  return list;
}

/** Rough class from the fitted motion. Rates: 1″/day (= 365″/yr) is asteroid/comet territory; nearby stars and brown dwarfs are below that. */
export function classify(fit: MotionFit | null) {
  if (!fit) return 'Unclassified (too few visits)';
  const sigPlx = fit.errPlx > 0 ? Math.abs(fit.plx) / fit.errPlx : 0;
  if (fit.withParallax && sigPlx > 3 && Math.abs(fit.plx) > 1) return 'Solar-system distance (parallax larger than any star’s)';
  if (fit.pm > 365) return 'Asteroid / comet-speed mover';
  if (fit.pm < Math.max(0.05, 3 * fit.errPm)) return 'Static (no significant motion)';
  if (fit.pm >= 0.3) return 'Brown-dwarf / nearby-star-speed mover';
  return 'Slow mover (distant star)';
}

export const candidatesCsv = (list: Candidate[]) => {
  const head = ['id', 'created', 'name', 'ra_deg', 'dec_deg', 'class', 'pm_arcsec_per_yr', 'pm_err', 'pm_ra_cosdec', 'pm_dec', 'position_angle_deg', 'parallax_arcsec', 'parallax_err', 'visits', 'in_gaia', 'in_wise', 'flux_first', 'flux_last', 'delta_flux', 'percent_change', 'z', 'link', 'note'];
  const q = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const rows = list.map((c) => [c.id, c.created, c.name, c.ra.toFixed(6), c.dec.toFixed(6), c.cls, c.pm.toFixed(4), c.pmErr.toFixed(4), c.pmE.toFixed(4), c.pmN.toFixed(4), c.pa.toFixed(1), c.plx.toFixed(4), c.plxErr.toFixed(4), c.visits, c.inGaia, c.inWise, c.flux?.first.toFixed(3) ?? '', c.flux?.last.toFixed(3) ?? '', c.flux?.dF.toFixed(3) ?? '', c.flux?.pct.toFixed(1) ?? '', c.flux?.z.toFixed(1) ?? '', c.link, c.note].map(q).join(','));
  return [head.join(','), ...rows].join('\n');
};
export function download(name: string, text: string, mime = 'text/csv') {
  const a = document.createElement('a'); a.download = name; a.href = URL.createObjectURL(new Blob([text], { type: mime })); a.click(); window.setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
