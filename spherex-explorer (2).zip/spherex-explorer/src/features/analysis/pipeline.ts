import { activeSource } from '../data/dataSource';
import type { Cutout, SkyRef } from '../data/dataSource';
import { BANDS, bandsOfArray, ALL_BANDS } from '../exploration/demoData';
import { stretchOf } from '../exploration/demoData';
import { aperture, fitMotion, marksToPoints, trackFrom, dominance } from './astrometry';
import type { Mark } from './astrometry';
import { KNOWN } from '../data/knownValues';

export type BandSet = 'all' | 'long' | `a${number}`;
export const bandsOf = (s: BandSet) => (s === 'all' ? ALL_BANDS : s === 'long' ? [...bandsOfArray(4), ...bandsOfArray(5)] : bandsOfArray(+s.slice(1)));
export const bandSetLabel = (s: BandSet) => (s === 'all' ? 'All 102 bands' : s === 'long' ? 'Arrays 5+6 (3.8–5 µm)' : `Array ${+s.slice(1) + 1}`);
void BANDS;

export async function loadCuts(ref: SkyRef, fov: number, bands: number[]) {
  const vis = await activeSource.visits(ref), cuts: Cutout[] = [];
  for (let v = 0; v < vis.length; v++) cuts.push(await activeSource.cutout(ref, fov, v, bands));
  return { vis, cuts, stretch: cuts.length ? stretchOf(cuts[0].data) : { lo: 0, hi: 1 } };
}
export const fluxCurve = (cuts: Cutout[], marks: Mark[]) => marks.map((m) => ({ visit: m.visit, ...aperture(cuts[m.visit], m.x, m.y) }));
/** First-to-last brightness change of a tracked source: dF, percent change and significance (dF over combined noise). */
export function photometryChange(cuts: Cutout[], marks: Mark[]) {
  if (marks.length < 2) return null;
  const f = fluxCurve(cuts, marks), a = f[0], b = f[f.length - 1], dF = b.flux - a.flux;
  return { first: a.flux, last: b.flux, dF, pct: a.flux !== 0 ? (dF / Math.abs(a.flux)) * 100 : 0, z: dF / Math.hypot(a.err, b.err) };
}
/** Auto-measure used by the test-target page: track from the centre of the cutout, fit, compare with the literature. */
export async function autoMeasure(ref: SkyRef, id: string, fov = 10) {
  const bands = bandsOf(KNOWN[id]?.bands === 'long' ? 'long' : 'all'), { cuts } = await loadCuts(ref, fov, bands);
  const c = cuts[0].wcs, marks = trackFrom(cuts, { visit: 0, x: c.cx, y: c.cy }), pts = marksToPoints(cuts, marks);
  const lin = fitMotion(pts, false), par = fitMotion(pts, true);
  return { marks, lin, par, dom: lin ? dominance(lin, par) : null, phot: photometryChange(cuts, marks), visits: cuts.length };
}
