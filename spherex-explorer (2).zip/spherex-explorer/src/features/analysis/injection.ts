/**
 * Injection tests: put synthetic movers of known speed and brightness into a field, then ask whether people / the
 * detector find them. Injection is synthetic by definition, so this module works on the demo scene; with real data
 * the same idea is done by adding model PSFs to real cutouts.
 */
import { buildScene, renderBands, sourceFlux, pixelAt, PIXEL_ARCSEC, BANDS } from '../exploration/demoData';
import type { Scene, Source, TargetDef } from '../exploration/demoData';
import { baselineDetector, findResiduals } from '../exploration/changeDetection';

export type Injected = { src: Source; id: number; speed: number; meanFlux: number; angle: number };
export function rng(seed: number) { let a = seed >>> 0; return () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

const SPEC = { T: 3000, ref: 3.0 };
const shape = (() => { const s = { e0: 0, n0: 0, pmE: 0, pmN: 0, amp: 1, spec: SPEC, isTarget: false, gaia: false, wise: false } as Source; return BANDS.reduce((a, b) => a + sourceFlux(s, b.center, 2026), 0) / BANDS.length; })();
/** A mover whose all-band mean flux is `meanFlux` (demo units) and whose speed is `speed` arcsec/yr. */
export function makeMover(rnd: () => number, w: number, speed: number, meanFlux: number, id: number): Injected {
  const angle = rnd() * 2 * Math.PI, pad = 0.18 * w * PIXEL_ARCSEC, span = (w * PIXEL_ARCSEC) / 2 - pad;
  const src: Source = { e0: (rnd() * 2 - 1) * span, n0: (rnd() * 2 - 1) * span, pmE: Math.cos(angle) * speed, pmN: Math.sin(angle) * speed, amp: meanFlux / shape, spec: SPEC, isTarget: false, gaia: false, wise: false, label: `Injected #${id + 1}` };
  return { src, id, speed, meanFlux, angle };
}
/** Scene with extra sources; positions are kept inside the frame at the first and last visit. */
export function withInjected(base: TargetDef, fov: number, movers: Injected[]): Scene {
  const sc = buildScene(base, fov);
  return { ...sc, sources: [...sc.sources, ...movers.map((m) => m.src)], stamps: new Map(), pixmaps: new Map() };
}
export type Recovery = { found: boolean; visit: number | null };
/** Does the baseline detector find the mover in any consecutive visit pair? (a residual lands within `tol` px of it) */
export function detectorRecovers(sc: Scene, m: Injected, bands: number[], tol = 2.5, minP = 0.5): Recovery {
  for (let ep = 1; ep < sc.years.length; ep++) {
    const a = renderBands(sc, ep - 1, bands), b = renderBands(sc, ep, bands);
    const prob = baselineDetector.detect({ a: a.data, b: b.data, sigmaA: a.sigma, sigmaB: b.sigma, width: sc.w, height: sc.h });
    const res = findResiduals(prob, a.data, b.data, Math.hypot(a.sigma, b.sigma), sc.w, sc.h, minP, 40);
    const pa = pixelAt(sc, m.src, ep - 1), pb = pixelAt(sc, m.src, ep);
    if (res.some((r) => Math.hypot(r.x - pb.x, r.y - pb.y) <= tol || Math.hypot(r.x - pa.x, r.y - pa.y) <= tol)) return { found: true, visit: ep };
  }
  return { found: false, visit: null };
}
export const SPEEDS = [1, 2, 4, 8, 16, 32];
export const FLUXES = [0.3, 0.6, 1.2, 2.4, 4.8];
export type Cell = { speed: number; flux: number; hit: number; n: number };
/** Recovery fraction on a speed x brightness grid. Async in slices so the page stays responsive. */
export async function sensitivityGrid(base: TargetDef, fov: number, bands: number[], trials: number, onProgress: (f: number) => void): Promise<Cell[]> {
  const out: Cell[] = [], total = SPEEDS.length * FLUXES.length * trials; let done = 0;
  for (const speed of SPEEDS) for (const flux of FLUXES) {
    let hit = 0;
    for (let t = 0; t < trials; t++) {
      const rnd = rng(9000 + done * 7919), w = Math.max(8, Math.round((fov * 60) / PIXEL_ARCSEC)), m = makeMover(rnd, w, speed, flux, 0);
      if (detectorRecovers(withInjected(base, fov, [m]), m, bands).found) hit++;
      done++; if (done % 3 === 0) { onProgress(done / total); await new Promise((r) => window.setTimeout(r, 0)); }
    }
    out.push({ speed, flux, hit, n: trials });
  }
  onProgress(1); return out;
}
