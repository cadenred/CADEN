/**
 * Astrometry: centroiding, tracking an object across visits, and fitting its motion.
 * The workflow follows the standard pipeline stages: difference/significance -> detection -> photometry -> fit.
 */
import { FLAG } from '../exploration/demoData';
import type { Cutout } from '../data/dataSource';
import { parallaxFactor } from '../exploration/cadence';
import { tanToSky } from '../exploration/wcs';

const BAD = FLAG.HOT | FLAG.CR | FLAG.EDGE;
const median = (a: number[]) => { if (!a.length) return 0; const s = [...a].sort((x, y) => x - y), m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };

export type Centroid = { x: number; y: number; sx: number; sy: number; peak: number; snr: number };
/**
 * Background-subtracted centroid inside radius r. Flagged (bad) pixels are never trusted: each is replaced by its
 * mirror pixel about the current centre (a PSF is symmetric) or, failing that, by the median of its good neighbours.
 */
export function centroidAt(c: Cutout, x0: number, y0: number, r = 3): Centroid | null {
  const { w, h, data, flags, sigma } = c, xi = Math.round(x0), yi = Math.round(y0);
  if (xi < 0 || yi < 0 || xi >= w || yi >= h) return null;
  const ring: number[] = [];
  for (let y = yi - r - 4; y <= yi + r + 4; y++) for (let x = xi - r - 4; x <= xi + r + 4; x++) {
    if (x < 0 || y < 0 || x >= w || y >= h) continue; const d = Math.hypot(x - xi, y - yi);
    if (d > r + 1.5 && d <= r + 4.5 && !(flags[y * w + x] & BAD)) ring.push(data[y * w + x]);
  }
  const bg = median(ring), S = 2 * r + 3, at = (x: number, y: number) => (y - yi + r + 1) * S + (x - xi + r + 1);
  const val = new Float32Array(S * S), bad = new Uint8Array(S * S).fill(1), inside = new Uint8Array(S * S);
  for (let y = yi - r - 1; y <= yi + r + 1; y++) for (let x = xi - r - 1; x <= xi + r + 1; x++) {
    if (x < 0 || y < 0 || x >= w || y >= h) continue; const k = at(x, y), i = y * w + x;
    val[k] = data[i] - bg; bad[k] = flags[i] & BAD ? 1 : 0; if (Math.hypot(x - xi, y - yi) <= r + 0.01) inside[k] = 1;
  }
  const filled = Float32Array.from(val);
  for (let y = yi - r - 1; y <= yi + r + 1; y++) for (let x = xi - r - 1; x <= xi + r + 1; x++) {
    const k = at(x, y); if (!bad[k]) continue; const nb: number[] = [];
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const xx = x + dx, yy = y + dy; if ((dx || dy) && xx >= xi - r - 1 && xx <= xi + r + 1 && yy >= yi - r - 1 && yy <= yi + r + 1 && !bad[at(xx, yy)] && at(xx, yy) >= 0) nb.push(val[at(xx, yy)]); }
    filled[k] = nb.length ? median(nb) : 0;
  }
  let mx = xi, my = yi, peak = -Infinity, sw = 0, vx = 0, vy = 0;
  for (let pass = 0; pass < 3; pass++) {
    if (pass > 0) for (let y = yi - r; y <= yi + r; y++) for (let x = xi - r; x <= xi + r; x++) {
      const k = at(x, y); if (!bad[k]) continue;
      const rx = Math.round(2 * mx - x), ry = Math.round(2 * my - y);
      if (rx >= xi - r - 1 && rx <= xi + r + 1 && ry >= yi - r - 1 && ry <= yi + r + 1 && !bad[at(rx, ry)]) filled[k] = val[at(rx, ry)];
    }
    let s = 0, sx = 0, sy = 0; peak = -Infinity;
    for (let y = yi - r; y <= yi + r; y++) for (let x = xi - r; x <= xi + r; x++) {
      const k = at(x, y); if (!inside[k]) continue; const f = Math.max(0, filled[k]); s += f; sx += f * x; sy += f * y; if (f > peak) peak = f;
    }
    if (s <= 0) return null; mx = sx / s; my = sy / s; sw = s;
  }
  for (let y = yi - r; y <= yi + r; y++) for (let x = xi - r; x <= xi + r; x++) { const k = at(x, y); if (!inside[k]) continue; const f = Math.max(0, filled[k]); vx += f * 0 + (x - mx) ** 2; vy += (y - my) ** 2; }
  const floor = 0.03;
  return { x: mx, y: my, sx: Math.max(floor, (sigma * Math.sqrt(vx)) / sw), sy: Math.max(floor, (sigma * Math.sqrt(vy)) / sw), peak, snr: peak / sigma };
}

/** Brightest un-flagged 3x3-smoothed pixel within `rad` of (x0, y0). */
export function findPeak(c: Cutout, x0: number, y0: number, rad: number) {
  const { w, h, data, flags } = c; let best: { x: number; y: number; v: number } | null = null;
  for (let y = Math.max(1, Math.floor(y0 - rad)); y <= Math.min(h - 2, Math.ceil(y0 + rad)); y++) for (let x = Math.max(1, Math.floor(x0 - rad)); x <= Math.min(w - 2, Math.ceil(x0 + rad)); x++) {
    if (Math.hypot(x - x0, y - y0) > rad) continue;
    let s = 0, k = 0, bad = false;
    for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const i = (y + dy) * w + x + dx; if (flags[i] & BAD) bad = true; else { s += data[i]; k++; } }
    if (bad && (flags[y * w + x] & BAD)) continue;
    const v = s / Math.max(1, k); if (!best || v > best.v) best = { x, y, v };
  }
  return best;
}

/** Aperture photometry: summed background-subtracted flux inside radius r, with its noise. */
export function aperture(c: Cutout, x: number, y: number, r = 2.5) {
  const { w, h, data, flags, sigma } = c, ring: number[] = [], xi = Math.round(x), yi = Math.round(y);
  for (let j = yi - 9; j <= yi + 9; j++) for (let i = xi - 9; i <= xi + 9; i++) {
    if (i < 0 || j < 0 || i >= w || j >= h) continue; const d = Math.hypot(i - x, j - y);
    if (d > 5 && d <= 9 && !(flags[j * w + i] & BAD)) ring.push(data[j * w + i]);
  }
  const bg = median(ring); let sum = 0, n = 0;
  for (let j = yi - 4; j <= yi + 4; j++) for (let i = xi - 4; i <= xi + 4; i++) {
    if (i < 0 || j < 0 || i >= w || j >= h || Math.hypot(i - x, j - y) > r || (flags[j * w + i] & BAD)) continue;
    sum += data[j * w + i] - bg; n++;
  }
  return { flux: sum, err: sigma * Math.sqrt(Math.max(1, n)) * Math.sqrt(1 + 1 / Math.max(1, ring.length / 4)), n };
}

export type Mark = { visit: number; x: number; y: number; sx: number; sy: number; snr: number; manual?: boolean };
/** Follow an object through every visit starting from a click, predicting its next position from the motion so far. */
export function trackFrom(cuts: Cutout[], start: { visit: number; x: number; y: number }, searchPx = 3): Mark[] {
  const out = new Map<number, Mark>();
  const first = centroidAt(cuts[start.visit], start.x, start.y);
  const pk = findPeak(cuts[start.visit], start.x, start.y, 2);
  const c0 = pk ? centroidAt(cuts[start.visit], pk.x, pk.y) ?? first : first;
  if (!c0) return [];
  out.set(start.visit, { visit: start.visit, x: c0.x, y: c0.y, sx: c0.sx, sy: c0.sy, snr: c0.snr });
  const walk = (dir: 1 | -1) => {
    let prev = out.get(start.visit)!, vel = { x: 0, y: 0 }; // pixels per day
    for (let v = start.visit + dir; v >= 0 && v < cuts.length; v += dir) {
      const dt = cuts[v].mjd - cuts[prev.visit].mjd, px = prev.x + vel.x * dt, py = prev.y + vel.y * dt;
      const pk2 = findPeak(cuts[v], px, py, searchPx); if (!pk2) break;
      const ce = centroidAt(cuts[v], pk2.x, pk2.y); if (!ce || ce.snr < 2.5) break;
      const m: Mark = { visit: v, x: ce.x, y: ce.y, sx: ce.sx, sy: ce.sy, snr: ce.snr };
      if (Math.abs(dt) > 1e-6) vel = { x: (m.x - prev.x) / (cuts[v].mjd - cuts[prev.visit].mjd), y: (m.y - prev.y) / (cuts[v].mjd - cuts[prev.visit].mjd) };
      out.set(v, m); prev = m;
    }
  };
  walk(1); walk(-1);
  return [...out.values()].sort((a, b) => a.visit - b.visit);
}

/**
 * Follow a DISTANT solar-system object: for an assumed distance (AU) its apparent position changes mostly through the
 * yearly parallax, which we can predict from the date alone. Scanning many distances and keeping the one that lands
 * on a consistent source in every visit is a "shift-and-stack" search for Planet X-like bodies.
 */
export function trackAtDistance(cuts: Cutout[], start: { visit: number; x: number; y: number }, distAU: number, searchPx = 3) {
  const { wcs } = cuts[0], plx = 206265 / distAU, f0 = parallaxFactor(wcs.ra0, wcs.dec0, cuts[start.visit].mjd);
  const marks: Mark[] = []; let score = 0, found = 0;
  for (let v = 0; v < cuts.length; v++) {
    const f = parallaxFactor(wcs.ra0, wcs.dec0, cuts[v].mjd), px = start.x - (plx * (f.e - f0.e)) / wcs.pix, py = start.y - (plx * (f.n - f0.n)) / wcs.pix;
    const pk = findPeak(cuts[v], px, py, searchPx); if (!pk) continue;
    const ce = centroidAt(cuts[v], pk.x, pk.y); if (!ce || ce.snr < 2.5) continue;
    marks.push({ visit: v, x: ce.x, y: ce.y, sx: ce.sx, sy: ce.sy, snr: ce.snr }); score += Math.min(ce.snr, 30); found++;
  }
  return { marks, score: found === cuts.length ? score : score * 0.2, found, distAU };
}
export function scanDistances(cuts: Cutout[], start: { visit: number; x: number; y: number }, lo = 20, hi = 5000, n = 40) {
  let best: ReturnType<typeof trackAtDistance> | null = null;
  for (let i = 0; i < n; i++) { const d = lo * Math.pow(hi / lo, i / (n - 1)), r = trackAtDistance(cuts, start, d); if (!best || r.score > best.score) best = r; }
  return best!;
}

/* ---------- motion fit ---------- */
export type TrackPoint = { year: number; mjd: number; e: number; n: number; se: number; sn: number; ra: number; dec: number };
export type MotionFit = {
  withParallax: boolean; t0: number; baseline: number;
  e0: number; n0: number; pmE: number; pmN: number; plx: number;
  errPmE: number; errPmN: number; errPlx: number; errPm: number;
  pm: number; pa: number; chi2: number; dof: number; chi2r: number;
};
function solve(A: number[][], b: number[]) {
  const n = b.length, M = A.map((r, i) => [...r, b[i]]);
  for (let i = 0; i < n; i++) {
    let p = i; for (let k = i + 1; k < n; k++) if (Math.abs(M[k][i]) > Math.abs(M[p][i])) p = k;
    [M[i], M[p]] = [M[p], M[i]]; if (Math.abs(M[i][i]) < 1e-14) return null;
    for (let k = 0; k < n; k++) if (k !== i) { const f = M[k][i] / M[i][i]; for (let j = i; j <= n; j++) M[k][j] -= f * M[i][j]; }
  }
  return M.map((r, i) => r[n] / r[i]);
}
function invert(A: number[][]) {
  const n = A.length, cols: number[][] = [];
  for (let j = 0; j < n; j++) { const e = Array(n).fill(0); e[j] = 1; const s = solve(A, e); if (!s) return null; cols.push(s); }
  return cols[0].map((_, i) => cols.map((c) => c[i]));
}

/** Weighted least-squares fit of offsets (arcsec) to  position = P0 + mu * (t - t0)  [+ parallax ellipse]. */
export function fitMotion(pts: TrackPoint[], withParallax: boolean): MotionFit | null {
  const np = withParallax ? 5 : 4;
  if (pts.length < 2 || 2 * pts.length < np) return null;
  const t0 = pts.reduce((s, p) => s + p.year, 0) / pts.length, ra = pts[0].ra, dec = pts[0].dec;
  const rows: { a: number[]; y: number; w: number }[] = [];
  for (const p of pts) {
    const t = p.year - t0, f = parallaxFactor(ra, dec, p.mjd);
    rows.push({ a: withParallax ? [1, 0, t, 0, f.e] : [1, 0, t, 0], y: p.e, w: 1 / (p.se * p.se) });
    rows.push({ a: withParallax ? [0, 1, 0, t, f.n] : [0, 1, 0, t], y: p.n, w: 1 / (p.sn * p.sn) });
  }
  const AtA = Array.from({ length: np }, () => Array(np).fill(0)), Atb = Array(np).fill(0);
  for (const r of rows) for (let i = 0; i < np; i++) { Atb[i] += r.w * r.a[i] * r.y; for (let j = 0; j < np; j++) AtA[i][j] += r.w * r.a[i] * r.a[j]; }
  const sol = solve(AtA, Atb), cov = invert(AtA); if (!sol || !cov) return null;
  let chi2 = 0; for (const r of rows) { const m = r.a.reduce((s, v, i) => s + v * sol[i], 0); chi2 += r.w * (r.y - m) ** 2; }
  const dof = rows.length - np, chi2r = dof > 0 ? chi2 / dof : NaN, infl = dof > 0 ? Math.sqrt(Math.max(1, chi2r)) : 1;
  const err = (i: number) => Math.sqrt(Math.max(0, cov[i][i])) * infl, pmE = sol[2], pmN = sol[3], pm = Math.hypot(pmE, pmN);
  const errPm = pm > 0 ? Math.sqrt((pmE * err(2)) ** 2 + (pmN * err(3)) ** 2) / pm : Math.hypot(err(2), err(3));
  const years = pts.map((p) => p.year);
  return { withParallax, t0, baseline: Math.max(...years) - Math.min(...years), e0: sol[0], n0: sol[1], pmE, pmN, plx: withParallax ? sol[4] : 0, errPmE: err(2), errPmN: err(3), errPlx: withParallax ? err(4) : 0, errPm, pm, pa: ((Math.atan2(pmE, pmN) * 180) / Math.PI + 360) % 360, chi2, dof, chi2r };
}
/** Model position (arcsec) of a fit at a date. */
export function modelAt(f: MotionFit, year: number, mjd: number, ra: number, dec: number) {
  const t = year - f.t0, p = parallaxFactor(ra, dec, mjd);
  return { e: f.e0 + f.pmE * t + f.plx * p.e, n: f.n0 + f.pmN * t + f.plx * p.n };
}

/** Which term wins: the straight-line drift over the baseline, or the yearly parallax wobble? */
export function dominance(lin: MotionFit, par: MotionFit | null) {
  if (!par) return { verdict: 'Need at least three visits to separate parallax from motion.', plxSig: 0, dominant: 'unknown' as const };
  const sig = par.errPlx > 0 ? Math.abs(par.plx) / par.errPlx : 0, drift = par.pm * par.baseline, wobble = Math.abs(par.plx);
  const dominant = drift >= wobble ? ('motion' as const) : ('parallax' as const);
  const verdict = sig < 2 ? `Parallax is not significant (${sig.toFixed(1)}σ): the track is consistent with a straight line (Δχ² vs line ${(lin.chi2 - par.chi2).toFixed(1)}).`
    : dominant === 'motion' ? `Straight-line motion dominates (${drift.toFixed(2)}″ over the baseline vs ${wobble.toFixed(2)}″ of wobble); parallax is detected at ${sig.toFixed(1)}σ.`
    : `The yearly wobble dominates (${wobble.toFixed(1)}″ of parallax vs ${drift.toFixed(2)}″ of drift), detected at ${sig.toFixed(1)}σ.`;
  return { verdict, plxSig: sig, dominant };
}

/** Marks -> arcsec offsets (East/North of the cutout centre) using the cutout's WCS. */
export function marksToPoints(cuts: Cutout[], marks: Mark[]): TrackPoint[] {
  return marks.map((m) => {
    const c = cuts[m.visit], { wcs } = c, e = (wcs.cx - m.x) * wcs.pix, n = (wcs.cy - m.y) * wcs.pix, sky = tanToSky(wcs.ra0, wcs.dec0, e, n);
    return { year: 2000 + (c.mjd - 51544.5) / 365.25, mjd: c.mjd, e, n, se: m.sx * wcs.pix, sn: m.sy * wcs.pix, ra: sky.ra, dec: sky.dec };
  });
}
