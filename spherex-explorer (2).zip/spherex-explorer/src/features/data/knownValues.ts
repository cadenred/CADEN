/**
 * Literature values used to VALIDATE the proper-motion tool. Values are from published astrometry
 * (Gaia DR3 / Kirkpatrick et al. 2021 / Scholz et al. 2003); rounded. Check against SIMBAD before quoting in the final write-up.
 * Units: proper motion in arcsec/yr (mu_alpha* = mu_alpha cos(dec), mu_delta), parallax in arcsec.
 */

export type KnownValue = {
  pmE: number;
  pmN: number;
  plx: number;
  source: string;
  bands: 'all' | 'long';
  look: string;
};

export const KNOWN: Record<string, KnownValue | null> = {
  barnard: {
    pmE: -0.8028,
    pmN: 10.3624,
    plx: 0.547,
    source: 'Gaia DR3',
    bands: 'all',
    look: 'A bright star that drifts about 10″ every year. The ring should stay on it in every visit.'
  },

  epsindib: {
    pmE: 3.982,
    pmN: -2.467,
    plx: 0.2707,
    source: 'Gaia DR3 (Ba/Bb photocentre)',
    bands: 'all',
    look: 'Faint blended pair 402″ east of the bright star ε Indi A. Both move together at about 4.7″/yr.'
  },

  wise0855: {
    pmE: -8.1237,
    pmN: 0.6732,
    plx: 0.439,
    source: 'Kirkpatrick et al. 2021',
    bands: 'long',
    look: 'Almost invisible below 3 µm. Use the long-wavelength arrays (4–5 µm) and follow it west at about 8″/yr.'
  },

  rwaur: null,
  rdra: null,

  'planetx-sim': {
    pmE: 0.12,
    pmN: -0.05,
    plx: 206265 / 500,
    source: 'Planet X scenario',
    bands: 'long',
    look: 'Parallax wobble of about 412″ with almost no straight-line motion.'
  }
};

export const TEST_LOOK: Record<string, string> = {
  rwaur: 'An irregular variable: the position stays put but the brightness wanders. Compare visits in single-band view.',
  rdra: 'A Mira variable near the north ecliptic pole, so it has many visits. Open the light curve and look for the 245-day swing.'
};

export const lookFor = (id: string) =>
  KNOWN[id]?.look ?? TEST_LOOK[id] ?? '';

export const totalPm = (v: { pmE: number; pmN: number }) =>
  Math.hypot(v.pmE, v.pmN);