/**
 * Spectral features worth marking on a SPHEREx spectrum (wavelengths in µm, approximate band centres).
 * Check against the SPHEREx science documentation before printing in the final write-up.
 */
export type Feature = { id: string; label: string; um: number; kind: 'absorption' | 'emission'; text: string };
export const FEATURES: Feature[] = [
  { id: 'h2o', label: 'H₂O ice', um: 3.0, kind: 'absorption', text: 'Water ice: the main reservoir of water in cold clouds and discs. It shows as a broad dip.' },
  { id: 'pah', label: '3.3 µm', um: 3.3, kind: 'emission', text: 'Emission from small carbon-rich grains (PAHs); in cold brown dwarfs, methane absorbs near here.' },
  { id: 'ch3oh', label: 'CH₃OH ice', um: 3.53, kind: 'absorption', text: 'Methanol ice, a building block of larger organic molecules.' },
  { id: 'co2', label: 'CO₂ ice', um: 4.27, kind: 'absorption', text: 'Carbon dioxide ice: a sharp, deep dip.' },
  { id: 'co', label: 'CO ice', um: 4.67, kind: 'absorption', text: 'Carbon monoxide ice, found in the coldest, densest regions.' },
];
export const bbShape = (lam: number, T: number) => 1 / (Math.pow(lam, 5) * (Math.exp(14388 / (lam * T)) - 1));

export type Pt = { lam: number; flux: number; err: number };
/** Best blackbody (temperature grid + analytic scale) by chi-square. */
export function fitBlackbody(pts: Pt[]) {
  let best = { T: 0, scale: 0, chi2: Infinity };
  for (let T = 200; T <= 9000; T += T < 1500 ? 25 : 100) {
    let num = 0, den = 0;
    for (const p of pts) { const m = bbShape(p.lam, T), w = 1 / (p.err * p.err); num += w * p.flux * m; den += w * m * m; }
    const scale = den > 0 ? num / den : 0; if (scale <= 0) continue;
    let chi2 = 0; for (const p of pts) chi2 += ((p.flux - scale * bbShape(p.lam, T)) / p.err) ** 2;
    if (chi2 < best.chi2) best = { T, scale, chi2 };
  }
  return { ...best, dof: Math.max(1, pts.length - 2) };
}
/** Plain-language summary of a fitted temperature. */
export function readout(T: number) {
  const peak = 2898 / T; // Wien's law, µm
  const kind = T < 400 ? 'a very cold object (colder than a hot drink)' : T < 1000 ? 'a cold brown dwarf or planet-mass object' : T < 2500 ? 'a warm brown dwarf or very cool star' : T < 4500 ? 'a cool red star' : 'a hotter, bluer star';
  const where = peak > 5 ? 'beyond the longest SPHEREx band (5 µm), so it looks brightest at the red end' : peak < 0.75 ? 'bluer than SPHEREx can see, so it rises toward the blue end' : `near ${peak.toFixed(1)} µm`;
  return `Best blackbody ≈ ${T} K: ${kind}. Its light peaks ${where}.`;
}
