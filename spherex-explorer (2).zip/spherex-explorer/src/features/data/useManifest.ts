import { useEffect, useState } from 'react';
import { activeSource } from './dataSource';
import type { Manifest } from './dataSource';

const KEY = 'lumenx-seen-version';
const read = () => { try { return localStorage.getItem(KEY); } catch { return null; } };
/** Current dataset manifest, re-checked every few minutes, plus whether it is newer than the version this viewer last saw. */
export function useManifest() {
  const [manifest, setManifest] = useState<Manifest | null>(null);
  const [seen, setSeen] = useState<string | null>(read);
  useEffect(() => {
    let dead = false;
    const load = () => activeSource.manifest().then((m) => { if (!dead) setManifest(m); }, () => undefined);
    load(); const id = window.setInterval(load, 5 * 60_000);
    return () => { dead = true; window.clearInterval(id); };
  }, []);
  const markSeen = () => { if (manifest) { try { localStorage.setItem(KEY, manifest.version); } catch { /* ignore */ } setSeen(manifest.version); } };
  return { manifest, isNew: !!manifest && seen !== null && seen !== manifest.version, markSeen, firstVisit: seen === null };
}
