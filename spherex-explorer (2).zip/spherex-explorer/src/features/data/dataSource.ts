/**
 * Data adapter. Every screen that needs pixels, visit dates, catalogues or spectra asks the ACTIVE DataSource, never
 * demoData directly, so going from synthetic to real SPHEREx data means writing one class and switching `activeSource`.
 *
 *   DemoSource  - synthetic data from demoData.ts (what runs today)
 *   IrsaSource  - skeleton for real data. Its contract is documented below; nothing in the UI changes when you fill it in.
 *
 * "Easy to update": manifest() returns a version string. The UI compares it with the last version the viewer saw and
 * shows a "new data release" badge (see useManifest.ts). Dropping a new manifest next to new cutouts is the whole update.
 */

import {
  renderBands,
  flagMap,
  catalogue,
  spectrumAt,
  toPixel,
  MANIFEST,
  PIXEL_ARCSEC,
  customTargetDef,
  targetFromKey
} from '../exploration/demoData';

import type { SpectrumPoint, TargetDef } from '../exploration/demoData';

import { surveyVisits } from '../exploration/cadence';
import type { VisitInfo } from '../exploration/cadence';

import { FrameEngine } from '../exploration/engine';

export type SkyRef = {
  id: string;
  name: string;
  ra: number;
  dec: number;
};

export type Cutout = {
  iso: string;
  mjd: number;
  w: number;
  h: number;
  data: Float32Array;
  sigma: number;
  flags: Uint8Array;

  /** tangent-plane WCS: pixel (cx, cy) sits at (ra0, dec0); `pix` is the pixel scale in arcsec; east is toward smaller x */
  wcs: {
    ra0: number;
    dec0: number;
    cx: number;
    cy: number;
    pix: number;
  };
};

export type CatSrc = {
  x: number;
  y: number;
  label?: string;
  moves: boolean;
};

export type Manifest = {
  version: string;
  updated: string;
  source: string;
  real: boolean;
};

export interface DataSource {
  id: string;
  label: string;
  real: boolean;

  manifest(): Promise<Manifest>;
  visits(ref: SkyRef): Promise<VisitInfo[]>;

  /** One cutout, the co-add of `bands` (indices 0..101) at visit index `visit`. */
  cutout(
    ref: SkyRef,
    fovArcmin: number,
    visit: number,
    bands: number[]
  ): Promise<Cutout>;

  catalogue(
    ref: SkyRef,
    fovArcmin: number,
    which: 'gaia' | 'wise',
    visit: number,
    propagate: boolean
  ): Promise<CatSrc[]>;

  spectrum(
    ref: SkyRef,
    fovArcmin: number,
    visit: number,
    x: number,
    y: number
  ): Promise<SpectrumPoint[]>;
}

export const refOf = (t: TargetDef): SkyRef => ({
  id: t.id,
  name: t.name,
  ra: t.ra,
  dec: t.dec
});

class DemoSource implements DataSource {
  id = 'spherex-model';
  label = 'SPHEREx observation model';
  real = false;

  private engine = new FrameEngine();

  private def(ref: SkyRef): TargetDef {
    return targetFromKey(ref.id) ?? customTargetDef(ref.ra, ref.dec);
  }

  async manifest(): Promise<Manifest> {
    return { ...MANIFEST, real: false };
  }

  async visits(ref: SkyRef) {
    const d = this.def(ref);
    return surveyVisits(d.ra, d.dec);
  }

  async cutout(
    ref: SkyRef,
    fov: number,
    visit: number,
    bands: number[]
  ): Promise<Cutout> {
    const d = this.def(ref);
    const sc = this.engine.scene(d, fov);
    const ep = Math.min(visit, sc.years.length - 1);
    const r = renderBands(sc, ep, bands);

    return {
      iso: d.epochs[ep],
      mjd: sc.mjd[ep],
      w: sc.w,
      h: sc.h,
      data: r.data,
      sigma: r.sigma,
      flags: flagMap(sc, ep, bands),
      wcs: {
        ra0: d.ra,
        dec0: d.dec,
        cx: sc.cx,
        cy: sc.cy,
        pix: PIXEL_ARCSEC
      }
    };
  }

  async catalogue(
    ref: SkyRef,
    fov: number,
    which: 'gaia' | 'wise',
    visit: number,
    propagate: boolean
  ): Promise<CatSrc[]> {
    const sc = this.engine.scene(this.def(ref), fov);

    return catalogue(
      sc,
      which,
      sc.years[Math.min(visit, sc.years.length - 1)],
      propagate
    ).map((c) => ({
      ...toPixel(sc, c.e, c.n),
      label: c.label,
      moves: c.moves
    }));
  }

  async spectrum(
    ref: SkyRef,
    fov: number,
    visit: number,
    x: number,
    y: number
  ) {
    const sc = this.engine.scene(this.def(ref), fov);

    return spectrumAt(
      sc,
      Math.min(visit, sc.years.length - 1),
      x,
      y
    );
  }
}

/**
 * Skeleton for real SPHEREx data. Fill these in (e.g. call a small backend that wraps IRSA's SPHEREx spectral-image
 * search and returns the same shapes), then set `activeSource = new IrsaSource(baseUrl)`.
 *
 *   manifest : GET {base}/manifest.json  -> { version, updated, source }
 *   visits   : the exposure table rows covering (ra, dec), grouped into visits
 *   cutout   : co-add of the requested bands, plus the matching variance and flag cutouts, regridded to a TAN WCS
 *   catalogue: Gaia / AllWISE rows in the cutout footprint (positions at their reference epochs + proper motions)
 *   spectrum : per-band flux and error of one pixel
 */

export class IrsaSource implements DataSource {
  id = 'irsa';
  label = 'NASA/IPAC IRSA (SPHEREx)';
  real = true;

  constructor(private base: string) {}

  async manifest(): Promise<Manifest> {
    const r = await fetch(`${this.base}/manifest.json`);

    if (!r.ok) throw new Error('manifest not reachable');

    const m = await r.json();

    return {
      version: String(m.version),
      updated: String(m.updated),
      source: String(m.source ?? 'IRSA'),
      real: true
    };
  }

  visits(): Promise<VisitInfo[]> {
    return Promise.reject(new Error('IrsaSource.visits is not implemented yet'));
  }

  cutout(): Promise<Cutout> {
    return Promise.reject(new Error('IrsaSource.cutout is not implemented yet'));
  }

  catalogue(): Promise<CatSrc[]> {
    return Promise.reject(new Error('IrsaSource.catalogue is not implemented yet'));
  }

  spectrum(): Promise<SpectrumPoint[]> {
    return Promise.reject(new Error('IrsaSource.spectrum is not implemented yet'));
  }
}

export const demoSource: DataSource = new DemoSource();

/** Switch this one line to go real. */
export const activeSource: DataSource = demoSource;