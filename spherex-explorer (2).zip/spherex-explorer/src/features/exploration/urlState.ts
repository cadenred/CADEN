import { nearestBand, BANDS } from './demoData';

export type DisplayMode = 'band' | 'array' | 'all' | 'rgb';
export type EpochOp = 'single' | 'side' | 'blink' | 'add' | 'sub';
export type UrlState = {
  target?: string; ra?: number; dec?: number; fov?: number; band?: number; mode?: DisplayMode; arr?: number;
  epochs?: number[]; op?: EpochOp; overlay: string[]; pm: boolean; mask: boolean; embed: boolean;
};
const num = (v: string | null) => (v !== null && v.trim() !== '' && Number.isFinite(Number(v)) ? Number(v) : undefined);

export function readUrl(search: string): UrlState {
  const p = new URLSearchParams(search);
  const mode = p.get('mode'), op = p.get('op');
  const bandUm = num(p.get('band'));
  return {
    target: p.get('target') ?? undefined, ra: num(p.get('ra')), dec: num(p.get('dec')),
    fov: num(p.get('fov')), band: bandUm === undefined ? undefined : nearestBand(bandUm),
    mode: mode === 'band' || mode === 'array' || mode === 'all' || mode === 'rgb' ? mode : undefined,
    arr: num(p.get('arr')), op: op === 'single' || op === 'side' || op === 'blink' || op === 'add' || op === 'sub' ? op : undefined,
    epochs: p.get('epochs')?.split(',').map((s) => Number(s) - 1).filter((n) => Number.isInteger(n) && n >= 0),
    overlay: (p.get('overlay') ?? '').split(',').filter(Boolean), pm: p.get('pm') === '1', mask: p.get('mask') === '1', embed: p.get('embed') === '1',
  };
}

export function writeUrl(s: { target: string; fov: number; band: number; mode: DisplayMode; arr: number; epochs: number[]; op: EpochOp; overlay: string[]; pm: boolean; mask: boolean; embed: boolean }) {
  const p = new URLSearchParams();
  p.set('target', s.target); p.set('fov', String(s.fov)); p.set('mode', s.mode);
  if (s.mode === 'band') p.set('band', BANDS[s.band].center.toFixed(2));
  if (s.mode === 'array') p.set('arr', String(s.arr + 1));
  p.set('epochs', s.epochs.map((e) => e + 1).join(',')); p.set('op', s.op);
  if (s.overlay.length) p.set('overlay', s.overlay.join(','));
  if (s.pm) p.set('pm', '1');
  if (s.mask) p.set('mask', '1');
  if (s.embed) p.set('embed', '1');
  const url = `${window.location.pathname}?${p.toString()}`;
  try { window.history.replaceState(null, '', url); } catch { /* ignore */ }
}