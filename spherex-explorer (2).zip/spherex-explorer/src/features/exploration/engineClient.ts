import { FrameEngine } from './engine';
import type { FrameParams, FrameResult } from './engine';
import type { TargetDef } from './demoData';

/** Promise API over the frame worker. Falls back to the main thread if Workers are unavailable. */
let worker: Worker | null = null, broken = false, seq = 0;
const pending = new Map<number, { ok: (r: FrameResult) => void; fail: (e: unknown) => void }>();
const local = new FrameEngine();

function getWorker() {
  if (broken) return null;
  if (worker) return worker;
  try {
    worker = new Worker(new URL('./engine.worker.ts', import.meta.url), { type: 'module' });
    worker.onmessage = (e: MessageEvent<{ id: number; result?: FrameResult; error?: string }>) => {
      const p = pending.get(e.data.id); if (!p) return; pending.delete(e.data.id);
      if (e.data.result) p.ok(e.data.result); else p.fail(new Error(e.data.error));
    };
    worker.onerror = () => { broken = true; worker = null; pending.forEach((p, id) => { pending.delete(id); p.fail(new Error('worker failed')); }); };
    return worker;
  } catch { broken = true; return null; }
}

export function requestFrame(target: TargetDef, params: FrameParams): Promise<FrameResult> {
  const w = getWorker();
  if (!w) return new Promise((ok) => window.setTimeout(() => ok(local.frame(target, params)), 0));
  const id = ++seq;
  return new Promise<FrameResult>((ok, fail) => {
    pending.set(id, { ok, fail });
    w.postMessage({ id, target, params });
  }).catch(() => local.frame(target, params));
}
