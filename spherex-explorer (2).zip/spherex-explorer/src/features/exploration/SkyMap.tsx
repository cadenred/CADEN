import { useEffect, useRef } from 'react';
import type { TargetDef } from './demoData';

export type View = { ra: number; dec: number; R: number };
export const D = Math.PI / 180;
export const GLOBE_R = 430;
export const BOT = 108; // space reserved for the timeline dock
export const wrap = (a: number) => ((a % 360) + 360) % 360;

/* ---------- procedural all-sky starfield (stand-in for a real survey map) ---------- */
function rng(seed: number) { let a = seed; return () => { a = (a * 1664525 + 1013904223) >>> 0; return a / 4294967296; }; }
function galToEq(l: number, b: number) {
  const lN = 122.93192 * D, aN = 192.85948 * D, dN = 27.12825 * D;
  const sd = Math.sin(b) * Math.sin(dN) + Math.cos(b) * Math.cos(dN) * Math.cos(lN - l);
  const y = Math.cos(b) * Math.sin(lN - l), x = Math.sin(b) * Math.cos(dN) - Math.cos(b) * Math.sin(dN) * Math.cos(lN - l);
  return [wrap((aN + Math.atan2(y, x)) / D), Math.asin(sd) / D];
}
// each star: ra, dec, size, alpha, warmth
const STARS: number[][] = (() => {
  const r = rng(42), out: number[][] = [];
  const g = () => (r() + r() + r() + r() - 2) * 1.7;
  for (let i = 0; i < 9000; i++) {
    const l = r() < 0.4 ? g() * 38 * D : r() * 2 * Math.PI, b = g() * 7 * D * (r() < 0.2 ? 2.5 : 1);
    const [ra, dec] = galToEq(l, b); out.push([ra, dec, 0.5 + r() * r() * 1.6, 0.25 + r() * 0.6, r()]);
  }
  for (let i = 0; i < 1800; i++) out.push([r() * 360, Math.asin(2 * r() - 1) / D, 0.6 + r() * r() * 1.8, 0.3 + r() * 0.7, r()]);
  return out;
})();
const DUST: number[][] = (() => {
  const r = rng(7), out: number[][] = [], g = () => (r() + r() + r() + r() - 2) * 1.7;
  for (let i = 0; i < 700; i++) { const l = r() < 0.45 ? g() * 35 * D : r() * 2 * Math.PI; const [ra, dec] = galToEq(l, g() * 5 * D); out.push([ra, dec, 5 + r() * 14]); }
  return out;
})();

/* Stereographic projection, seen from INSIDE the sphere (looking out into space). East is left. */
export function project(v: View, W: number, H: number, ra: number, dec: number) {
  const l = (ra - v.ra) * D, sp = Math.sin(dec * D), cp = Math.cos(dec * D), cl = Math.cos(l);
  const s0 = Math.sin(v.dec * D), c0 = Math.cos(v.dec * D), cc = s0 * sp + c0 * cp * cl;
  if (cc < -0.92) return null;
  const k = 2 / (1 + cc);
  return { x: W / 2 - v.R * k * cp * Math.sin(l), y: H / 2 - v.R * k * (c0 * sp - s0 * cp * cl), k };
}
export function unproject(v: View, W: number, H: number, px: number, py: number) {
  const x = (W / 2 - px) / v.R, y = (H / 2 - py) / v.R, rho = Math.hypot(x, y);
  if (rho < 1e-9) return { ra: v.ra, dec: v.dec };
  const c = 2 * Math.atan(rho / 2), s0 = Math.sin(v.dec * D), c0 = Math.cos(v.dec * D);
  const dec = Math.asin(Math.cos(c) * s0 + (y * Math.sin(c) * c0) / rho);
  const ra = v.ra + Math.atan2(x * Math.sin(c), rho * c0 * Math.cos(c) - y * s0 * Math.sin(c)) / D;
  return { ra: wrap(ra), dec: dec / D };
}

type Props = {
  view: View; setView: (v: View) => void; visible: boolean; targets: TargetDef[]; activeId?: string;
  onSelect: (t: TargetDef) => void; onSelectCoords: (ra: number, dec: number) => void; grid: boolean;
  /** cursor position on the sky (null when the pointer leaves, drags or sits over the timeline) */
  onHover?: (h: { ra: number; dec: number; name?: string } | null) => void;
  patch: { img: HTMLCanvasElement; ra: number; dec: number; fovDeg: number } | null;
};
export function SkyMap({ view, setView, visible, targets, activeId, onSelect, onSelectCoords, grid, patch, onHover }: Props) {
  const cv = useRef<HTMLCanvasElement>(null), hits = useRef<{ t: TargetDef; x: number; y: number }[]>([]);
  const size = useRef({ W: 800, H: 600 }), vref = useRef(view), drag = useRef<{ x: number; y: number; moved: number } | null>(null);
  const ptrs = useRef(new Map<number, { x: number; y: number }>()), pinch = useRef(0);
  vref.current = view;
  const hoverRaf = useRef(0);

  const draw = () => {
    const c = cv.current; if (!c) return;
    const ctx = c.getContext('2d'); if (!ctx) return;
    const { W, H: Hf } = size.current, H = Hf - BOT, v = vref.current, dpr = window.devicePixelRatio || 1;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const bg = ctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, Math.max(W, Hf) * 0.75);
    bg.addColorStop(0, '#07231a'); bg.addColorStop(1, '#010a07'); ctx.fillStyle = bg; ctx.fillRect(0, 0, W, Hf);
    for (const d of DUST) { const p = project(v, W, H, d[0], d[1]); if (!p) continue; const rr = d[2] * Math.min(6, 0.5 + v.R / 380) * Math.min(2, p.k); if (rr > 900) continue; const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, rr); g.addColorStop(0, 'rgba(150,120,210,.07)'); g.addColorStop(1, 'rgba(150,120,210,0)'); ctx.fillStyle = g; ctx.fillRect(p.x - rr, p.y - rr, rr * 2, rr * 2); }
    const k = 0.7 + Math.min(2.6, v.R / 1200);
    for (const s of STARS) { const p = project(v, W, H, s[0], s[1]); if (!p || p.x < -4 || p.y < -4 || p.x > W + 4 || p.y > Hf + 4) continue; ctx.fillStyle = s[4] < 0.5 ? `rgba(215,230,255,${s[3]})` : `rgba(255,225,185,${s[3]})`; const z = s[2] * k; ctx.fillRect(p.x - z / 2, p.y - z / 2, z, z); }
    if (grid && v.R < 30000) {
      const step = v.R < 900 ? 30 : v.R < 4000 ? 10 : v.R < 12000 ? 2 : 0.5; ctx.strokeStyle = 'rgba(130,170,230,.16)'; ctx.lineWidth = 1; ctx.beginPath();
      const rng = v.R < 900 ? 360 : 40, fs = Math.max(0.25, step / 3);
      for (let d = Math.ceil((v.dec - rng / 2) / step) * step; d <= v.dec + rng / 2; d += step) { if (d <= -90 || d >= 90) continue; let on = false; for (let a = v.ra - rng; a <= v.ra + rng; a += fs) { const p = project(v, W, H, a, d); if (!p) { on = false; continue; } if (on) ctx.lineTo(p.x, p.y); else ctx.moveTo(p.x, p.y); on = true; } }
      for (let a = Math.ceil((v.ra - rng) / step) * step; a <= v.ra + rng; a += step) { let on = false; for (let d = Math.max(-90, v.dec - rng / 2); d <= Math.min(90, v.dec + rng / 2); d += fs) { const p = project(v, W, H, a, d); if (!p) { on = false; continue; } if (on) ctx.lineTo(p.x, p.y); else ctx.moveTo(p.x, p.y); on = true; } }
      ctx.stroke();
    }
    let imgA = 0;
    if (patch) {
      const p = project(v, W, H, patch.ra, patch.dec);
      if (p) { const sz = patch.fovDeg * D * v.R * p.k; imgA = Math.max(0, Math.min(1, (sz - 24) / 160)); if (imgA > 0) { ctx.save(); ctx.globalAlpha = imgA; ctx.imageSmoothingEnabled = false; ctx.drawImage(patch.img, p.x - sz / 2, p.y - sz / 2, sz, sz); ctx.restore(); } }
    }
    hits.current = [];
    ctx.font = '500 12.5px Outfit, system-ui, sans-serif';
    for (const t of targets) {
      if (v.R > 9000) break;
      const p = project(v, W, H, t.ra, t.dec); if (!p || p.x < -20 || p.y < -20 || p.x > W + 20 || p.y > H + 20) continue;
      hits.current.push({ t, x: p.x, y: p.y });
      const act = t.id === activeId, col = t.group === 'test' ? '#f3ebd6' : '#8ea8d4';
      ctx.strokeStyle = col; ctx.lineWidth = act ? 2.5 : 1.6; ctx.beginPath(); ctx.arc(p.x, p.y, act ? 10 : 7, 0, 7); ctx.stroke();
      ctx.fillStyle = col; ctx.beginPath(); ctx.arc(p.x, p.y, 2.2, 0, 7); ctx.fill();
      ctx.fillStyle = 'rgba(2,17,12,.82)'; const w = ctx.measureText(t.name).width; ctx.fillRect(p.x + 12, p.y - 9, w + 10, 18);
      ctx.fillStyle = '#f3ebd6'; ctx.fillText(t.name, p.x + 17, p.y + 4);
    }
  };
  useEffect(() => { if (visible) draw(); });
  useEffect(() => {
    const c = cv.current; if (!c) return;
    const ro = new ResizeObserver(() => {
      const r = c.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
      size.current = { W: r.width, H: r.height }; c.width = r.width * dpr; c.height = r.height * dpr; draw();
    });
    ro.observe(c); return () => ro.disconnect();
  }, []);

  return (
    <canvas ref={cv} className="sky-map" style={{ display: visible ? 'block' : 'none' }}
      onPointerDown={(e) => {
        cancelAnimationFrame(hoverRaf.current); onHover?.(null);
        (e.target as Element).setPointerCapture(e.pointerId); ptrs.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
        if (ptrs.current.size === 2) { const [a, b] = [...ptrs.current.values()]; pinch.current = Math.hypot(a.x - b.x, a.y - b.y); if (drag.current) drag.current.moved = 99; }
        else drag.current = { x: e.clientX, y: e.clientY, moved: 0 };
      }}
      onPointerMove={(e) => {
        const pt = ptrs.current.get(e.pointerId);
        if (!pt) { // plain hover: report the sky coordinates under the cursor (at most once per frame)
          if (!onHover) return;
          const cvEl = e.currentTarget, cx = e.clientX, cy = e.clientY; cancelAnimationFrame(hoverRaf.current);
          hoverRaf.current = requestAnimationFrame(() => {
            const r = cvEl.getBoundingClientRect(), px = cx - r.left, py = cy - r.top;
            if (py > size.current.H - BOT) return onHover(null);
            const q = unproject(vref.current, size.current.W, size.current.H - BOT, px, py), near = hits.current.find((h) => Math.hypot(h.x - px, h.y - py) < 16);
            onHover(near ? { ra: near.t.ra, dec: near.t.dec, name: near.t.name } : { ra: q.ra, dec: q.dec });
          });
          return;
        }
        pt.x = e.clientX; pt.y = e.clientY;
        if (ptrs.current.size >= 2) {
          const [a, b] = [...ptrs.current.values()], dist = Math.hypot(a.x - b.x, a.y - b.y), v = vref.current;
          if (pinch.current > 0) setView({ ...v, R: Math.max(GLOBE_R * 0.6, Math.min(2e6, v.R * (dist / pinch.current))) });
          pinch.current = dist; return;
        }
        const d = drag.current; if (!d) return;
        const dx = e.clientX - d.x, dy = e.clientY - d.y; d.x = e.clientX; d.y = e.clientY; d.moved += Math.abs(dx) + Math.abs(dy);
        const v = vref.current, c0 = Math.max(0.15, Math.cos(v.dec * D));
        setView({ ...v, ra: wrap(v.ra + dx / (v.R * c0) / D), dec: Math.max(-89, Math.min(89, v.dec + dy / v.R / D)) });
      }}
      onPointerLeave={() => { cancelAnimationFrame(hoverRaf.current); onHover?.(null); }}
      onPointerCancel={(e) => { ptrs.current.delete(e.pointerId); drag.current = null; }}
      onPointerUp={(e) => {
        ptrs.current.delete(e.pointerId); pinch.current = 0;
        const d = drag.current; drag.current = null; if (!d || d.moved > 5) return;
        const r = (e.target as Element).getBoundingClientRect(), px = e.clientX - r.left, py = e.clientY - r.top;
        const hit = hits.current.find((h) => Math.hypot(h.x - px, h.y - py) < 16);
        if (hit) return onSelect(hit.t);
        const q = unproject(vref.current, size.current.W, size.current.H - BOT, px, py);
        if (q) onSelectCoords(q.ra, q.dec);
      }}
      onWheel={(e) => { const v = vref.current; setView({ ...v, R: Math.max(GLOBE_R * 0.6, Math.min(2e6, v.R * Math.exp(-e.deltaY * 0.0016))) }); }}
    />
  );
}