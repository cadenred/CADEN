/**
 * Tangent-plane (gnomonic, "TAN") projection, the same projection a FITS WCS header with
 * CTYPE = RA---TAN / DEC--TAN describes. Offsets are in arcsec, East positive, North positive.
 * With real data, replace the crval below with the header's CRVAL1/CRVAL2 and add the CD matrix.
 */
const D = Math.PI / 180;

/** Sky position -> tangent-plane offset (xi East, eta North) in arcsec about (ra0, dec0). */
export function skyToTan(ra0: number, dec0: number, ra: number, dec: number) {
  const a = ra * D, d = dec * D, a0 = ra0 * D, d0 = dec0 * D;
  const cosc = Math.sin(d0) * Math.sin(d) + Math.cos(d0) * Math.cos(d) * Math.cos(a - a0);
  const xi = (Math.cos(d) * Math.sin(a - a0)) / cosc;
  const eta = (Math.cos(d0) * Math.sin(d) - Math.sin(d0) * Math.cos(d) * Math.cos(a - a0)) / cosc;
  return { e: (xi / D) * 3600, n: (eta / D) * 3600 };
}

/** Tangent-plane offset (arcsec) -> sky position, exact inverse of skyToTan. */
export function tanToSky(ra0: number, dec0: number, eArc: number, nArc: number) {
  const xi = (eArc / 3600) * D, eta = (nArc / 3600) * D, a0 = ra0 * D, d0 = dec0 * D;
  const rho = Math.hypot(xi, eta);
  if (rho < 1e-12) return { ra: ((ra0 % 360) + 360) % 360, dec: dec0 };
  const c = Math.atan(rho), sc = Math.sin(c), cc = Math.cos(c);
  const dec = Math.asin(cc * Math.sin(d0) + (eta * sc * Math.cos(d0)) / rho);
  const ra = a0 + Math.atan2(xi * sc, rho * Math.cos(d0) * cc - eta * Math.sin(d0) * sc);
  return { ra: (((ra / D) % 360) + 360) % 360, dec: dec / D };
}
