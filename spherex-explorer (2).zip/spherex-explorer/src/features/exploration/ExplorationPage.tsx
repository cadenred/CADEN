import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { ReactNode, CSSProperties } from 'react';
import { Layers, Database, Telescope, Crosshair, Share2, Code, Camera, Info, Plus, Minus, Search, Home, Play, Pause, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, X, Eye, EyeOff, Rocket, Activity, Orbit, Waypoints, Link2, Sparkles, ArrowLeft, LayoutGrid, Film } from 'lucide-react';
import { SkyMap, GLOBE_R, BOT, D, wrap } from './SkyMap';
import type { View } from './SkyMap';
import { SkyFrame } from './SkyFrame';
import type { Mark } from './SkyFrame';
import { TARGETS, MANIFEST, ARRAY_EDGES, BANDS, ALL_BANDS, bandsOfArray, buildScene, resolveName, pixelAt, toPixel, customTargetDef, catalogue, spectrumAt, flagMap, skyAt, pixelMean, targetBrightness, sizeEstimate, fmtBytes, FLAG_INFO, PIXEL_ARCSEC } from './demoData';
import type { TargetDef } from './demoData';
import { listChangeDetectors, baselineDetector, findResiduals } from './changeDetection';
import { readUrl } from './urlState';
import { Link } from 'react-router-dom';
import { requestFrame } from './engineClient';
import { frameToRgba, sceneKeyOf, blendInto } from './engine';
import type { FrameResult } from './engine';
import { fmtRA, fmtDec, fmtWV, MON, parseCoords, resolveRemote } from './format';
import { surveyOf } from './cadence';
import { usePrefs } from '../../app/prefs';
import { useManifest } from '../data/useManifest';
import { download } from '../analysis/candidates';
import '../../styles/screens.css';

/* ---------- helpers ---------- */
const endR = (fovArc: number) => Math.max(300, Math.min(window.innerHeight - BOT, window.innerWidth)) / ((fovArc / 60) * D);
const customTarget = customTargetDef;
const angDist = (a: View, ra: number, dec: number) => Math.acos(Math.min(1, Math.sin(a.dec * D) * Math.sin(dec * D) + Math.cos(a.dec * D) * Math.cos(dec * D) * Math.cos((a.ra - ra) * D))) / D;

/* ---------- tiny SVG plot ---------- */
type Pt = { x: number; y: number; e?: number; c?: string };
function Plot({ pts, xl, yl, color = '#f3ebd6', line = true }: { pts: Pt[]; xl: string; yl: string; color?: string; line?: boolean }) {
  const W = 290, H = 120, L = 38, B = 20, T = 8, Rr = 6;
  if (!pts.length) return null;
  const xs = pts.map((p) => p.x), ys = pts.flatMap((p) => [p.y - (p.e ?? 0), p.y + (p.e ?? 0)]);
  const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys), pad = (y1 - y0) * 0.1 || 1;
  const sx = (x: number) => L + ((x - x0) / (x1 - x0 || 1)) * (W - L - Rr), sy = (y: number) => T + (1 - (y - (y0 - pad)) / (y1 - y0 + 2 * pad)) * (H - T - B);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="plot" role="img" aria-label={`${yl} versus ${xl}`}>
      <line x1={L} y1={H - B} x2={W - Rr} y2={H - B} stroke="#667" /><line x1={L} y1={T} x2={L} y2={H - B} stroke="#667" />
      {line && <path d={pts.map((p, i) => `${i ? 'L' : 'M'}${sx(p.x)},${sy(p.y)}`).join('')} fill="none" stroke={color} strokeOpacity=".45" />}
      {pts.map((p, i) => (<g key={i}>{p.e ? <line x1={sx(p.x)} x2={sx(p.x)} y1={sy(p.y - p.e)} y2={sy(p.y + p.e)} stroke={p.c ?? color} strokeOpacity=".4" /> : null}<circle cx={sx(p.x)} cy={sy(p.y)} r="2.6" fill={p.c ?? color} /></g>))}
      <text x={W / 2} y={H - 4} className="pl" textAnchor="middle">{xl}</text><text x="8" y={H / 2} className="pl" textAnchor="middle" transform={`rotate(-90 8 ${H / 2})`}>{yl}</text>
      <text x={L - 3} y={T + 8} className="pl" textAnchor="end">{y1.toFixed(y1 - y0 < 10 ? 1 : 0)}</text><text x={L - 3} y={H - B} className="pl" textAnchor="end">{y0.toFixed(y1 - y0 < 10 ? 1 : 0)}</text>
    </svg>
  );
}
const ARR_COL = ['#7fd3ff', '#5ef2d0', '#b6f06b', '#f2d54a', '#ff9a55', '#ff6b8a'];

/* ---------- tutorial cards ---------- */
type Preset = Partial<{ op: 'single' | 'add' | 'sub'; bandMode: 'all' | 'array' | 'band'; arr: number; gaia: boolean; pm: boolean; fov: number }>;
type Card = { id: string; title: string; blurb: string; icon: ReactNode; pos: string; target?: string; preset?: Preset; steps: string[] };
const CARDS: Card[] = [
  { id: 'intro', title: 'Introduction to LumenX', blurb: 'Learn the globe, search and timeline.', icon: <Telescope size={22} />, pos: '10% 20%', steps: ['This globe is the whole sky. Drag to rotate it and scroll to zoom. Cyan rings are the challenge test targets.', 'Click a ring or any patch of sky, or type a name or “RA, Dec” in the search box (top right), and the view zooms into that patch.', 'The left panel chooses what you see: catalogue overlays, wavelength bands (all 102, one of the six arrays, or one band) and the field of view.', 'The timeline at the bottom steps through every SPHEREx visit. Press play (or Space) to blink through them like a little video and spot what moves.', 'Click any pixel for its spectrum. The share and embed buttons (top right) copy a link to exactly what you see.'] },
  { id: 'barnard', title: 'Barnard’s Star: a fast mover', blurb: 'Watch the star drift between visits.', icon: <Rocket size={22} />, pos: '50% 30%', target: 'barnard', preset: { op: 'single', gaia: true, pm: false }, steps: ['Barnard’s Star has the largest known proper motion, about 10″ a year.', 'Press play on the timeline. The white ring marks where the star is expected; the blue Gaia circles are the 2016 catalogue positions.', 'Turn on “Move catalogue to observation epoch” in the left panel and watch the Gaia circle catch up with the star.'] },
  { id: 'wise', title: 'WISE 0855: a faint brown dwarf', blurb: 'Co-add bands and subtract visits.', icon: <Orbit size={22} />, pos: '90% 70%', target: 'wise0855', preset: { op: 'sub', bandMode: 'all' }, steps: ['WISE 0855−0714 is extremely cold, so it is nearly invisible at short wavelengths.', 'Difference mode subtracts the previous visit from the current one: stars cancel, movers leave a teal and orange pair. Rings mark detections.', 'Switch Wavelength to “By array” and try array 5 or 6 (about 4–5 µm), where this object is brightest.'] },
  { id: 'var', title: 'Variable stars: R Draconis', blurb: 'Brightness curves across visits.', icon: <Activity size={22} />, pos: '30% 80%', target: 'rdra', preset: { op: 'single', bandMode: 'array', arr: 1 }, steps: ['R Draconis is a Mira variable that swells and fades over about 245 days.', 'Step through the timeline: the card at bottom left plots its brightness at each visit.', 'Pick a different array in the left panel to see how the amplitude changes with wavelength.'] },
  { id: 'spec', title: 'Spectra on the fly', blurb: 'Click a pixel, get 102 bands.', icon: <Waypoints size={22} />, pos: '70% 10%', target: 'epsindib', preset: { bandMode: 'all' }, steps: ['Epsilon Indi B is a brown dwarf pair, so its spectrum has molecular absorption dips.', 'Click the centre of the field. The spectrum card plots all 102 bands, coloured by detector array.', 'Switch on “Contamination flags” to see hot pixels, cosmic rays and bright-star halos before you trust a value.'] },
  { id: 'share', title: 'Share & embed', blurb: 'Every view lives in the URL.', icon: <Link2 size={22} />, pos: '20% 55%', target: 'rwaur', steps: ['Everything you set (position, field of view, bands, visit, overlays) is stored in the page address.', 'The share button copies a link; the code button copies an iframe snippet that hides the controls.', 'You can also type an address like ?ra=76.9565&dec=30.4014&fov=8 yourself.'] },
];

/* ---------- component ---------- */
type Op = 'single' | 'add' | 'sub';
export function ExplorationPage() {
  const prefs = usePrefs(), { isNew, markSeen } = useManifest();
  const [tools, setTools] = useState(false), [recording, setRecording] = useState(false);
  const url = useMemo(() => readUrl(window.location.search), []);
  const [mode, setMode] = useState<'sky' | 'cutout'>('sky');
  const [view, setView] = useState<View>({ ra: 100, dec: 15, R: GLOBE_R });
  const [target, setTarget] = useState<TargetDef | null>(null);
  const [fov, setFov] = useState(url.fov && url.fov >= 2 && url.fov <= 30 ? url.fov : prefs.dataSaver ? 6 : 10);
  const [ep, setEp] = useState(url.epochs?.[0] ?? 0);
  const [op, setOp] = useState<Op>(url.op === 'add' || url.op === 'sub' ? url.op : 'single');
  const [bandMode, setBandMode] = useState<'all' | 'array' | 'band'>(url.mode === 'array' ? 'array' : url.mode === 'band' ? 'band' : 'all');
  const [arr, setArr] = useState(url.arr ? url.arr - 1 : 3);
  const [band, setBand] = useState(url.band ?? 40);
  const [ov, setOv] = useState({ gaia: url.overlay.includes('gaia'), wise: url.overlay.includes('wise'), pm: url.pm, mask: url.mask, exp: true, grid: true });
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [smoothPref, setSmoothPref] = useState(true), [mix, setMix] = useState(0);
  const [pick, setPick] = useState<{ x: number; y: number } | null>(null);
  const [hover, setHover] = useState<{ x: number; y: number } | null>(null);
  const [skyHover, setSkyHover] = useState<{ ra: number; dec: number; name?: string } | null>(null);
  const [zoom, setZoom] = useState(1);
  const [tab, setTab] = useState<'layers' | 'targets' | 'data'>('layers');
  const [collapsed, setCollapsed] = useState(() => window.innerWidth < 820);
  const [welcome, setWelcome] = useState(() => { let skip = false; try { skip = !!localStorage.getItem('lumenx-skip'); } catch { /* ignore */ } return !skip && !url.target && url.ra === undefined; });
  const [about, setAbout] = useState(false);
  const [tour, setTour] = useState<{ card: Card; step: number } | null>(null);
  const [q, setQ] = useState('');
  const [toast, setToast] = useState('');
  const [detId, setDetId] = useState(baselineDetector.id);
  const wheelAcc = useRef(0), flyRef = useRef(0), viewRef = useRef(view);
  viewRef.current = view;
  const embed = url.embed;
  const say = (m: string) => { setToast(m); window.setTimeout(() => setToast(''), 2800); };

  /* fly-to: rotate the globe, dip out if far away, then zoom into the patch */
  const fly = useCallback((ra: number, dec: number, R1: number, done?: () => void) => {
    const id = ++flyRef.current, t0 = performance.now(), v0 = viewRef.current;
    const dist = angDist(v0, ra, dec), dur = prefs.reduceMotion ? 1 : Math.min(3400, 1300 + dist * 9 + Math.abs(Math.log(R1 / v0.R)) * 170), dRa = ((ra - v0.ra + 540) % 360) - 180;
    const lR0 = Math.log(v0.R), lR1 = Math.log(R1), dip = Math.min(1, dist / 25) * Math.max(2.1, (Math.max(lR0, lR1) - Math.log(GLOBE_R)) * 0.85);
    const step = (now: number) => {
      if (id !== flyRef.current) return;
      const k = Math.min(1, (now - t0) / dur), e = k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
      setView({ ra: wrap(v0.ra + dRa * e), dec: v0.dec + (dec - v0.dec) * e, R: Math.max(GLOBE_R * 0.8, Math.exp(lR0 + (lR1 - lR0) * e - dip * Math.sin(Math.PI * k))) });
      if (k < 1) requestAnimationFrame(step); else done?.();
    };
    requestAnimationFrame(step);
  }, []);

  const select = useCallback((t: TargetDef, preset?: Preset, instant = false) => {
    setPlaying(false); setPick(null); setEp(0); setZoom(1); setWelcome(false); if (window.innerWidth < 820) setCollapsed(true);
    if (preset) { if (preset.op) setOp(preset.op); if (preset.bandMode) setBandMode(preset.bandMode); if (preset.arr !== undefined) setArr(preset.arr); if (preset.fov) setFov(preset.fov); setOv((o) => ({ ...o, gaia: preset.gaia ?? o.gaia, pm: preset.pm ?? o.pm })); }
    setTarget(t);
    if (instant) { flyRef.current++; setView({ ra: t.ra, dec: t.dec, R: endR(preset?.fov ?? fov) }); setMode('cutout'); return; }
    setMode('sky'); fly(t.ra, t.dec, endR(preset?.fov ?? fov), () => setMode('cutout'));
  }, [fly, fov, prefs.reduceMotion]);
  const goHome = () => { setPlaying(false); setMode('sky'); setTour(null); fly(viewRef.current.ra, Math.max(-40, Math.min(60, viewRef.current.dec)), GLOBE_R); };
  const search = async (s: string) => {
    const t = resolveName(s); if (t) { setTour(null); return select(t); }
    const c = parseCoords(s); if (c) { setTour(null); return select(customTarget(c.ra, c.dec)); }
    say('Looking up the name at CDS…'); const r = await resolveRemote(s); if (r) { setTour(null); return select(customTarget(wrap(r.ra), r.dec)); }
    say('Not found. Try “WISE 0855”, “Barnard’s Star”, or coordinates like “133.795, −7.245” or “08h55m10.8s −07d14m42s”.');
  };
  const startCard = (c: Card) => {
    setWelcome(false); setTour({ card: c, step: 0 });
    const t = c.target ? TARGETS.find((x) => x.id === c.target) : undefined;
    if (t) select(t, c.preset);
  };

  useEffect(() => {
    const t = url.target ? TARGETS.find((x) => x.id === url.target) ?? resolveName(url.target) : undefined;
    if (t) select(t, undefined, true); else if (url.ra !== undefined && url.dec !== undefined) select(customTarget(wrap(url.ra), url.dec), undefined, true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---------- derived data ---------- */
  const sc = useMemo(() => (target ? buildScene(target, fov) : null), [target, fov]);
  const bands = useMemo(() => (bandMode === 'all' ? ALL_BANDS : bandMode === 'array' ? bandsOfArray(arr) : [band]), [bandMode, arr, band]);
  const nEp = sc?.years.length ?? 0;
  /* frames are computed in a Web Worker so the sliders and playback never block */
  const [frame, setFrame] = useState<FrameResult | null>(null), [, setTick] = useState(0);
  const store = useRef(new Map<string, FrameResult>()), epRef = useRef(ep);
  epRef.current = ep;
  const smooth = smoothPref && !prefs.reduceMotion;
  const gliding = playing && smooth && mode === 'cutout';
  const bandsSig = `${bands.length}|${bands[0]}|${bands[bands.length - 1]}`;
  const fkey = (k: number) => (target ? `${sceneKeyOf(target, fov)}|${op}|${bandsSig}|${k}` : '');
  const e1 = Math.min(ep, Math.max(0, nEp - 1)), e2 = Math.min(e1 + 1, Math.max(0, nEp - 1));
  useEffect(() => {
    if (!target || !sc) { setFrame(null); return; }
    let dead = false;
    const get = (k: number) => {
      const key = fkey(k), hit = store.current.get(key); if (hit) return Promise.resolve(hit);
      return requestFrame(target, { fov, bands, ep: k, op }).then((r) => { if (store.current.size > 24) store.current.delete(store.current.keys().next().value as string); store.current.set(key, r); return r; });
    };
    get(e1).then((r) => { if (!dead) setFrame(r); });
    if (playing || smooth) { get(e2).then(() => { if (!dead) setTick((t) => t + 1); }); if (playing && e2 + 1 < nEp) void get(e2 + 1); }
    return () => { dead = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [target, sc, fov, bands, e1, e2, op, nEp, playing, smooth]);
  const fr = target && sc ? store.current.get(fkey(e1)) ?? (frame && frame.sceneKey === sceneKeyOf(target, fov) ? frame : null) : null;
  const frB = gliding && target ? store.current.get(fkey(e2)) ?? null : null;
  const rgba = useMemo(() => (fr ? frameToRgba(fr, op, prefs.palette) : null), [fr, op, prefs.palette]);
  const rgbaB = useMemo(() => (frB && frB !== fr ? frameToRgba(frB, op, prefs.palette) : null), [frB, fr, op, prefs.palette]);
  const m = gliding && rgbaB ? mix : 0;

  const residuals = useMemo(() => {
    if (!sc || !fr || op !== 'sub' || !fr.a || gliding) return [];
    const det = listChangeDetectors().find((d) => d.id === detId) ?? baselineDetector;
    const prob = det.detect({ a: fr.a, b: fr.b, sigmaA: fr.sigmaA, sigmaB: fr.sigmaB, width: sc.w, height: sc.h });
    return findResiduals(prob, fr.a, fr.b, fr.sigma, sc.w, sc.h);
  }, [sc, fr, op, detId, gliding]);

  const patchCanvas = useMemo(() => { if (!rgba || !sc) return null; const c = document.createElement('canvas'); c.width = sc.w; c.height = sc.h; c.getContext('2d')?.putImageData(new ImageData(new Uint8ClampedArray(rgba), sc.w, sc.h), 0, 0); return c; }, [rgba, sc]);
  const rawMarks = useMemo(() => {
    if (!sc) return null;
    const build = (e: number) => {
      const yr = sc.years[e], cat = (w: 'gaia' | 'wise'): Mark[] => (ov[w] ? catalogue(sc, w, yr, ov.pm).map((c) => toPixel(sc, c.e, c.n)) : []);
      const exp: Mark[] = ov.exp ? sc.sources.filter((s) => s.label && !s.label.startsWith('Unlisted')).map((s) => { const q2 = pixelAt(sc, s, e); return { x: q2.x, y: q2.y, label: s.label }; }) : [];
      return { exp, gaia: cat('gaia'), wise: cat('wise') };
    };
    return { a: build(e1), b: build(e2) };
  }, [sc, e1, e2, ov]);
  /* markers slide between their positions at this visit and the next one, in step with the image */
  const marks = useMemo(() => {
    if (!sc || !rawMarks) return { exp: [] as Mark[], gaia: [] as Mark[], wise: [] as Mark[] };
    const inb = (p: Mark) => p.x >= -1 && p.y >= -1 && p.x <= sc.w && p.y <= sc.h;
    const mid = (A: Mark[], B: Mark[]) => A.map((p, i) => { const q = B[i]; return q && m > 0 ? { ...p, x: p.x + (q.x - p.x) * m, y: p.y + (q.y - p.y) * m } : p; }).filter(inb);
    return { exp: mid(rawMarks.a.exp, rawMarks.b.exp), gaia: mid(rawMarks.a.gaia, rawMarks.b.gaia), wise: mid(rawMarks.a.wise, rawMarks.b.wise) };
  }, [sc, rawMarks, m]);
  const mask = useMemo(() => (sc && ov.mask ? flagMap(sc, ep, bands) : null), [sc, ep, ov.mask, bands]);
  const spec = useMemo(() => (sc && pick ? spectrumAt(sc, ep, pick.x, pick.y) : null), [sc, ep, pick]);
  const curve = useMemo(() => {
    if (!sc || !sc.sources.some((s) => s.isTarget) || nEp < 3) return [];
    return sc.years.map((_, e) => { const b = targetBrightness(sc, e, bands); return b ? { x: sc.mjd[e] - sc.mjd[0], y: b.flux, e: b.err, c: e === ep ? '#ffffff' : undefined } : null; }).filter(Boolean) as Pt[];
  }, [sc, nEp, bands, ep]);
  const hov = sc && hover ? { ...skyAt(sc, hover.x, hover.y), v: pixelMean(sc, ep, hover.x, hover.y, bands), f: mask ? mask[hover.y * sc.w + hover.x] : 0 } : null;

  /* playback: with "smooth" on, time runs continuously and the picture glides from visit to visit; with it off it blinks like before */
  useEffect(() => {
    if (!playing || nEp < 2) return;
    if (!smooth) { const id = window.setInterval(() => setEp((e) => (e + 1) % nEp), 1000 / speed); return () => window.clearInterval(id); }
    let raf = 0, last = performance.now(), pos = epRef.current, seen = epRef.current, lastSet = epRef.current;
    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000); last = now;
      const cur = epRef.current; if (cur !== seen) { seen = cur; if (cur !== lastSet) pos = cur; } // the person stepped by hand
      pos += dt * speed; if (pos >= nEp) pos -= nEp;
      const e = Math.floor(pos);
      if (e !== cur) { lastSet = e; setEp(e); }
      setMix(e >= nEp - 1 ? 0 : pos - e);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [playing, speed, nEp, smooth]);
  useEffect(() => { if (!playing) setMix(0); }, [playing]);
  useEffect(() => {
    const k = (e: KeyboardEvent) => { if ((e.target as HTMLElement).tagName === 'INPUT') return; if (e.code === 'Space' && mode === 'cutout') { e.preventDefault(); setPlaying((p) => !p); }
      if (e.key === 'Escape') { if (welcome) setWelcome(false); else if (about) setAbout(false); else if (mode === 'cutout') goHome(); } };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, welcome, about]);

  useEffect(() => {
    if (mode !== 'cutout' || !target) return;
    const p = new URLSearchParams();
    if (TARGETS.some((t) => t.id === target.id)) p.set('target', target.id); else { p.set('ra', target.ra.toFixed(4)); p.set('dec', target.dec.toFixed(4)); }
    p.set('fov', String(fov)); p.set('mode', bandMode); if (bandMode === 'array') p.set('arr', String(arr + 1)); if (bandMode === 'band') p.set('band', BANDS[band].center.toFixed(2));
    p.set('epochs', String(ep + 1)); p.set('op', op);
    const o = [ov.gaia && 'gaia', ov.wise && 'wise'].filter(Boolean).join(','); if (o) p.set('overlay', o); if (ov.pm) p.set('pm', '1'); if (ov.mask) p.set('mask', '1'); if (embed) p.set('embed', '1');
    try { window.history.replaceState(null, '', `${window.location.pathname}?${p}`); } catch { /* ignore */ }
  }, [mode, target, fov, bandMode, arr, band, ep, op, ov, embed]);

  const copy = (text: string, msg: string) => navigator.clipboard?.writeText(text).then(() => say(msg), () => say('Copy failed. Copy the address bar instead.'));
  const embedCode = () => { const u = new URL(window.location.href); u.searchParams.set('embed', '1'); return `<iframe src="${u.toString()}" width="640" height="480" style="border:0" title="LumenX"></iframe>`; };
  const shot = () => {
    const src = (mode === 'cutout' ? document.querySelector('.sky-frame canvas') : document.querySelector('.sky-map')) as HTMLCanvasElement | null; if (!src) return;
    const c = document.createElement('canvas'); c.width = mode === 'cutout' ? 900 : src.width; c.height = mode === 'cutout' ? 900 : src.height;
    const x = c.getContext('2d'); if (!x) return; x.imageSmoothingEnabled = false; x.drawImage(src, 0, 0, c.width, c.height);
    if (mode === 'cutout' && target) { const e = target.epochs, line = `${target.name} · RA ${fmtRA(target.ra)} Dec ${fmtDec(target.dec)} · ${fov}′ field · visit ${cur + 1}/${e.length} (${e[cur]}) · ${e[0]} to ${e[e.length - 1]}`; x.fillStyle = 'rgba(0,0,0,.62)'; x.fillRect(0, c.height - 30, c.width, 30); x.fillStyle = '#f3ebd6'; x.font = '13px Outfit, sans-serif'; x.fillText(line, 10, c.height - 10); }
    const a = document.createElement('a'); a.download = `spherex-${target?.id ?? 'sky'}.png`; a.href = c.toDataURL('image/png'); a.click(); say('Image saved');
  };
  const recordMovie = async () => {
    if (!target || !sc || recording) return; const MR = (window as unknown as { MediaRecorder?: typeof MediaRecorder }).MediaRecorder;
    if (!MR) return say('Movie export is not supported by this browser.');
    setRecording(true); say('Rendering the movie…');
    try {
      const size = 640, cv = document.createElement('canvas'); cv.width = cv.height = size; const cx = cv.getContext('2d')!, tmp = document.createElement('canvas'); const tx = tmp.getContext('2d')!;
      const stream = cv.captureStream(30), rec = new MR(stream, { mimeType: MR.isTypeSupported('video/webm') ? 'video/webm' : '' }), chunks: Blob[] = []; rec.ondataavailable = (e) => chunks.push(e.data);
      const frames: FrameResult[] = []; for (let e = 0; e < nEp; e++) frames.push(await requestFrame(target, { fov, bands, ep: e, op }));
      const cols = frames.map((f) => frameToRgba(f, op, prefs.palette)), mixBuf = new Uint8ClampedArray(cols[0].length), STEPS = smooth ? 24 : 1, wait = 900 / STEPS;
      const isoMix = (e: number, k: number) => { const a0 = Date.parse(target.epochs[e] + 'T00:00:00Z'), b0 = Date.parse(target.epochs[Math.min(e + 1, nEp - 1)] + 'T00:00:00Z'); return new Date(a0 + (b0 - a0) * k).toISOString().slice(0, 10); };
      rec.start();
      for (let e = 0; e < nEp; e++) for (let st = 0; st < STEPS; st++) {
        const k = e >= nEp - 1 ? 0 : st / STEPS, f = frames[e], px = k > 0 ? blendInto(mixBuf, cols[e], cols[e + 1], k) : cols[e];
        tmp.width = f.w; tmp.height = f.h; tx.putImageData(new ImageData(px, f.w, f.h), 0, 0);
        cx.imageSmoothingEnabled = false; cx.drawImage(tmp, 0, 0, size, size); cx.fillStyle = 'rgba(0,0,0,.62)'; cx.fillRect(0, size - 34, size, 34); cx.fillStyle = '#f3ebd6'; cx.font = '15px Outfit, sans-serif';
        cx.fillText(`${target.name} · RA ${fmtRA(target.ra)} Dec ${fmtDec(target.dec)} · ${fov}′ · ${k > 0 ? isoMix(e, k) : target.epochs[e]} · visit ${e + 1}/${nEp}`, 10, size - 12);
        await new Promise((r) => setTimeout(r, wait));
      }
      await new Promise<void>((r) => { rec.onstop = () => r(); rec.stop(); });
      const a = document.createElement('a'); a.download = `spherex-${target.id}.webm`; a.href = URL.createObjectURL(new Blob(chunks, { type: 'video/webm' })); a.click(); say('Movie saved');
    } catch { say('Movie export failed in this browser.'); }
    setRecording(false);
  };
  const tq = target ? (TARGETS.some((t) => t.id === target.id) ? `target=${target.id}` : `ra=${target.ra.toFixed(4)}&dec=${target.dec.toFixed(4)}`) + `&fov=${fov}` : '';
  const TOOLS: [string, string, string][] = [['/measure', 'Measure motion', 'Proper motion + parallax, candidates'], ['/spectrum', 'Spectrum', 'Ice markers, temperature readout'], ['/exposures', 'Exposures', 'Time-ordered view of the 102 bands'], ['/candidates', 'My candidates', 'Saved leads, CSV export'], ['/inject', 'Injection test', 'Find hidden movers, sensitivity'], ['/compare', 'Real sky', 'Aladin Lite beside the cutout'], ['/tests', 'Test targets', 'The five challenge targets'], ['/about', 'About & coverage', 'Brief checklist, data pipeline'], ['/settings', 'Settings', 'Data saver, colours, language']];
  const eye = (k: 'gaia' | 'wise' | 'exp' | 'mask' | 'grid', label: string, sub: string) => (
    <button className={`layer ${ov[k] ? 'on' : ''}`} onClick={() => setOv({ ...ov, [k]: !ov[k] })} aria-pressed={ov[k]}>
      {ov[k] ? <Eye size={18} /> : <EyeOff size={18} />}<span className="ltxt"><b>{label}</b><i>{sub}</i></span>
    </button>
  );
  const tdate = (iso: string) => (Date.parse(iso) - Date.parse('2025-03-01')) / (Date.parse('2026-12-01') - Date.parse('2025-03-01'));
  const epochs = target?.epochs ?? TARGETS[0].epochs, cur = Math.min(ep, epochs.length - 1);
  const months = Array.from({ length: 21 }, (_, i) => { const d = new Date(Date.UTC(2025, 2 + i, 1)); return { t: tdate(d.toISOString().slice(0, 10)), y: d.getUTCFullYear(), m: d.getUTCMonth() }; });
  const est = sizeEstimate(fov, nEp || 6);
  const nxt = Math.min(cur + 1, epochs.length - 1), tm = gliding ? m : 0;
  const dateNow = tm > 0 ? new Date(Date.parse(epochs[cur] + 'T00:00:00Z') + (Date.parse(epochs[nxt] + 'T00:00:00Z') - Date.parse(epochs[cur] + 'T00:00:00Z')) * tm).toISOString().slice(0, 10) : epochs[cur];
  const headPos = tdate(epochs[cur]) + (tdate(epochs[nxt]) - tdate(epochs[cur])) * tm;

  return (
    <div className={`app ${embed ? 'embed' : ''} ${mode === 'cutout' ? 'cut' : ''}`}>
      <SkyMap onHover={setSkyHover} view={view} setView={(v) => { flyRef.current++; setView(v); }} visible={mode === 'sky'} targets={TARGETS} activeId={target?.id} grid={ov.grid} patch={patchCanvas && sc ? { img: patchCanvas, ra: sc.target.ra, dec: sc.target.dec, fovDeg: fov / 60 } : null}
        onSelect={(t) => { setTour(null); select(t); }} onSelectCoords={(ra, dec) => { setTour(null); select(customTarget(ra, dec)); }} />

      <div className={`cutout ${mode === 'cutout' ? 'in' : ''}`} onWheel={(e) => { if (zoom <= 1 && e.deltaY > 0) { wheelAcc.current += e.deltaY; if (wheelAcc.current > 260) { wheelAcc.current = 0; goHome(); return; } } else wheelAcc.current = 0; setZoom((z) => Math.max(1, Math.min(3, z - e.deltaY * 0.002))); }}>
        {sc && rgba && fr && (
          <div className="frame-wrap">
            <SkyFrame rgba={rgba} rgbaB={rgbaB} mix={m} w={fr.w} h={fr.h} mask={mask} zoom={zoom} pick={pick} onPick={(x, y) => setPick({ x, y })} onHover={setHover}
              expected={marks.exp} gaia={marks.gaia} wise={marks.wise} residuals={residuals} ariaLabel={`SPHEREx field around ${sc.target.name}, visit ${cur + 1}`} />
          </div>
        )}
      </div>

      <aside className={`side ${collapsed ? 'collapsed' : ''}`}>
        <header className="brand"><img src="/lumenx-symbol.png" alt="" /><div><h1>Lumen<span>X</span></h1><small>SPHEREx · the changing infrared sky</small></div></header>
        <nav className="tabs">
          {([['layers', <Layers size={16} key="l" />, 'Layers'], ['targets', <Telescope size={16} key="t" />, 'Targets'], ['data', <Database size={16} key="d" />, 'Data']] as const).map(([id, ic, label]) => (
            <button key={id} className={tab === id ? 'on' : ''} onClick={() => setTab(id)}>{ic}{label}</button>))}
          <button className="collapse" onClick={() => setCollapsed(true)} aria-label="Collapse panel"><ChevronsLeft size={18} /></button>
        </nav>
        <div className="scroll">
          {tab === 'layers' && (<>
            <h4>Reference</h4>
            {eye('grid', 'Sky grid', 'RA / Dec lines on the globe')}
            {eye('exp', 'Expected position', 'Where the target should be at this visit')}
            {eye('gaia', 'Gaia catalogue', 'Stars, epoch 2016.0')}
            {eye('wise', 'WISE catalogue', 'Infrared sources, epoch ≈ 2010')}
            <label className="check"><input type="checkbox" checked={ov.pm} onChange={(e) => setOv({ ...ov, pm: e.target.checked })} /> Move catalogue to observation epoch</label>
            {eye('mask', 'Contamination flags', 'Hot pixels, cosmic rays, halos, edges')}
            {ov.mask && <ul className="legend">{FLAG_INFO.map((f) => <li key={f.bit} title={f.text}><span style={{ background: f.color }} />{f.name}</li>)}</ul>}
            <h4>Wavelength · co-add</h4>
            <div className="seg">{(['all', 'array', 'band'] as const).map((m) => <button key={m} className={bandMode === m ? 'on' : ''} onClick={() => setBandMode(m)}>{m === 'all' ? 'All 102' : m === 'array' ? 'By array' : 'One band'}</button>)}</div>
            {bandMode === 'array' && <div className="arrs">{Array.from({ length: 6 }, (_, a) => <button key={a} className={arr === a ? 'on' : ''} style={{ '--c': ARR_COL[a] } as CSSProperties} onClick={() => setArr(a)}>{a + 1}<small>{ARRAY_EDGES[a].toFixed(1)}–{ARRAY_EDGES[a + 1].toFixed(1)} µm</small></button>)}</div>}
            {bandMode === 'band' && <><input type="range" min={0} max={101} value={band} onChange={(e) => setBand(+e.target.value)} aria-label="Band" /><p className="hint">Band {band + 1} of 102 · {BANDS[band].center.toFixed(2)} µm</p></>}
            <p className="hint">{bands.length} band{bands.length > 1 ? 's' : ''} added together; noise drops by √{bands.length}.</p>
            <h4>Time</h4>
            <div className="seg">{([['single', 'Single visit'], ['add', 'Co-add visits'], ['sub', 'Difference']] as const).map(([m, l]) => <button key={m} className={op === m ? 'on' : ''} onClick={() => setOp(m)}>{l}</button>)}</div>
            <p className="hint">{op === 'sub' ? 'Current visit minus the previous one. Movers show as a teal and orange pair.' : op === 'add' ? 'All visits stacked: deeper, but movers smear.' : 'Press play on the timeline to blink through visits.'}</p>
            {op === 'sub' && <select value={detId} onChange={(e) => setDetId(e.target.value)} aria-label="Detector">{listChangeDetectors().map((d) => <option key={d.id} value={d.id}>{d.label}</option>)}</select>}
            <h4>Field of view</h4>
            <input type="range" min={2} max={prefs.dataSaver ? 12 : 30} value={Math.min(fov, prefs.dataSaver ? 12 : 30)} onChange={(e) => setFov(+e.target.value)} aria-label="Field of view" />
            <p className="hint">{fov}′ × {fov}′ · {est.n}×{est.n} px · est. download {fmtBytes(est.total)}. Bigger fields catch faster movers.</p>
          </>)}
          {tab === 'targets' && (<>
            <h4>Challenge test targets</h4>
            {TARGETS.filter((t) => t.group === 'test').map((t) => <button key={t.id} className={`trow ${target?.id === t.id ? 'on' : ''}`} onClick={() => { setTour(null); select(t); }}><b>{t.name}</b><i>{t.description}</i></button>)}
            <h4>Sample fields</h4>
            {TARGETS.filter((t) => t.group === 'sample').map((t) => <button key={t.id} className="trow" onClick={() => { setTour(null); select(t); }}><b>{t.name}</b><i>{t.description}</i></button>)}
          </>)}
          {tab === 'data' && (<>
            <h4>Dataset</h4>
            {isNew && <p className="warn">A new data release is available. <button onClick={markSeen} style={{ textDecoration: 'underline' }}>Mark as seen</button></p>}
            <p className="hint"><b>{MANIFEST.source}</b><br />Version {MANIFEST.version} · updated {MANIFEST.updated}<br />Pixel scale {PIXEL_ARCSEC}″ · 102 bands · 6 arrays</p>
            <p className="warn">Explore the sky field across visits, bands and wavelength ranges.</p>
            <h4>Updating</h4>
            <p className="hint">Point <code>activeSource</code> in <code>data/dataSource.ts</code> at your data service (same shapes). New releases appear when the manifest version changes.</p>
          </>)}
        </div>
        <footer><button onClick={() => setAbout(true)}><Info size={15} /> About</button><button onClick={() => setWelcome(true)}><Sparkles size={15} /> Tutorials</button><button onClick={goHome}><Home size={15} /> All sky</button></footer>
      </aside>
      {collapsed && <button className="expand" onClick={() => setCollapsed(false)} aria-label="Expand panel"><ChevronsRight size={20} /></button>}

      <div className="top">
        {mode === 'cutout' && <button className="backbtn" onClick={goHome} aria-label="Back to all sky"><ArrowLeft size={17} /><span>All sky</span></button>}
        <form className="search" onSubmit={(e) => { e.preventDefault(); if (q.trim()) search(q); }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name or RA, Dec" aria-label="Search" list="names" />
          <datalist id="names">{TARGETS.map((t) => <option key={t.id} value={t.name} />)}</datalist>
          <button type="submit" aria-label="Go"><Search size={16} /></button>
        </form>
        <button className="ibtn blue" title="Fly to the current target" onClick={() => target && select(target)}><Crosshair size={18} /></button>
        <button className="ibtn" title="Copy link" onClick={() => copy(window.location.href, 'Link copied')}><Share2 size={18} /></button>
        <button className="ibtn hide-m" title="Copy embed code" onClick={() => copy(embedCode(), 'Embed code copied')}><Code size={18} /></button>
        <button className="ibtn hide-m" title="Save image (with coordinates and dates)" onClick={shot}><Camera size={18} /></button>
        <button className="ibtn hide-m" title="Save the blink movie (WebM)" onClick={recordMovie} disabled={mode !== 'cutout' || recording}><Film size={18} /></button>
        <button className="ibtn" title="Tools and other screens" aria-expanded={tools} onClick={() => setTools(!tools)}><LayoutGrid size={18} /></button>
        <button className="ibtn hide-m" title="Tutorials" onClick={() => setWelcome(true)}><Info size={18} /></button>
      </div>

      {tools && !embed && <nav className="tools-menu" aria-label="Tools">{TOOLS.map(([to, a, b]) => <Link key={to} to={`${to}?${tq}`} onClick={() => setTools(false)}><span><b>{a}</b><small>{b}</small></span></Link>)}</nav>}
      <div className="zoom"><button onClick={() => (mode === 'sky' ? setView({ ...view, R: Math.min(2e6, view.R * 1.5) }) : setZoom(Math.min(3, zoom + 0.5)))} aria-label="Zoom in"><Plus size={20} /></button>
        <button onClick={() => (mode === 'sky' ? setView({ ...view, R: Math.max(GLOBE_R * 0.7, view.R / 1.5) }) : zoom <= 1 ? goHome() : setZoom(Math.max(1, zoom - 0.5)))} aria-label={mode === 'cutout' && zoom <= 1 ? 'Zoom out to all sky' : 'Zoom out'}><Minus size={20} /></button></div>
      {mode === 'cutout' && sc && <div className="scale">{fov}′ field · {zoom.toFixed(1)}× · {PIXEL_ARCSEC}″ pixels</div>}
      {mode === 'sky' && skyHover && <div className="coords" aria-live="off" style={{ position: 'absolute', right: 16, bottom: 124, zIndex: 4, background: 'var(--panel)', border: '2px solid var(--ring)', borderRadius: 14, padding: '6px 14px', font: "12.5px 'IBM Plex Mono', monospace", color: 'var(--cream)', textAlign: 'right', pointerEvents: 'none', lineHeight: 1.5 }}>{skyHover.name && <div style={{ color: 'var(--mut)' }}>{skyHover.name}</div>}<div>RA&nbsp; {skyHover.ra.toFixed(3)}°</div><div>Dec {skyHover.dec >= 0 ? '+' : '−'}{Math.abs(skyHover.dec).toFixed(3)}°</div></div>}
      {mode === 'cutout' && <div className="readout">
        {hov ? <>RA {fmtRA(hov.ra)} · Dec {fmtDec(hov.dec)} · {hov.v.flux.toFixed(1)} ± {hov.v.err.toFixed(1)}{hov.f ? ` · ${FLAG_INFO.filter((f) => hov.f & f.bit).map((f) => f.name).join(', ')}` : ''}</> : target && <>{target.name} · RA {fmtRA(target.ra)} · Dec {fmtDec(target.dec)} </>}
      </div>}

      {mode === 'cutout' && (spec || curve.length > 0) && (
        <div className="cards-dock">
          {spec && pick && <div className="dcard"><h5>Spectrum · pixel {pick.x},{pick.y}<button onClick={() => setPick(null)} aria-label="Close"><X size={14} /></button></h5>
            <Plot pts={spec.map((s) => ({ x: s.lam, y: s.flux, e: s.err, c: ARR_COL[s.array] }))} xl="wavelength (µm)" yl="flux" />
              <div className="pickbar"><Link to={`/measure?${tq}&x=${pick.x}&y=${pick.y}&v=${cur + 1}`}>Track this object →</Link><Link to={`/spectrum?${tq}&x=${pick.x}&y=${pick.y}`}>Full spectrum page →</Link><button onClick={() => download(`spectrum-${target?.id}-${pick.x}-${pick.y}.csv`, ['band,array,wavelength_um,flux,error', ...spec.map((s) => `${s.band + 1},${s.array + 1},${s.lam.toFixed(4)},${s.flux.toFixed(4)},${s.err.toFixed(4)}`)].join('\n'))}>CSV</button></div></div>}
          {curve.length > 0 && <div className="dcard"><h5>Light curve · {target?.name}</h5><Plot pts={curve} xl="days since first visit" yl="brightness" color="#ffd37a" /></div>}
        </div>
      )}

      <div className="tl">
        <div className="datebox">
          <b>{fmtWV(dateNow)}</b>
          <div className="ctl">
            <button onClick={() => setEp((e) => (e + nEp - 1) % Math.max(1, nEp))} disabled={mode !== 'cutout'} aria-label="Previous visit"><ChevronLeft size={22} /></button>
            <button onClick={() => setPlaying(!playing)} disabled={mode !== 'cutout'} aria-label={playing ? 'Pause' : 'Play'}>{playing ? <Pause size={20} /> : <Play size={20} />}</button>
            <button onClick={() => setEp((e) => (e + 1) % Math.max(1, nEp))} disabled={mode !== 'cutout'} aria-label="Next visit"><ChevronRight size={22} /></button>
            <button className="spd" onClick={() => setSpeed(speed >= 2 ? 0.5 : speed * 2)} title="Playback speed">{speed}×</button>
            {!prefs.reduceMotion && <button className="spd" onClick={() => setSmoothPref(!smoothPref)} aria-pressed={smoothPref} title={smoothPref ? 'Smooth: the picture glides between visits. Click to blink instead.' : 'Blink: jumps from visit to visit. Click for smooth.'}>{smoothPref ? 'Smooth' : 'Blink'}</button>}
          </div>
          <small>Visit {mode === 'cutout' ? cur + 1 : '–'} / {epochs.length}{mode === 'cutout' ? ` · survey ${surveyOf(epochs[cur])}` : ''}</small>
        </div>
        <div className="strip" role="group" aria-label="Observation timeline">
          {months.map((m, i) => <span key={i} className={`mt ${m.m % 3 === 0 ? 'big' : ''}`} style={{ left: `${m.t * 100}%` }}>{m.m % 3 === 0 && <em>{MON[m.m]} {m.y}</em>}</span>)}
          {gliding && <span aria-hidden="true" style={{ position: 'absolute', top: 2, bottom: 2, width: 2, marginLeft: -1, borderRadius: 2, background: 'var(--teal)', boxShadow: '0 0 8px var(--teal)', pointerEvents: 'none', left: `${headPos * 100}%` }} />}
          {epochs.map((d, i) => <button key={d} className={`ep ${i === cur && mode === 'cutout' ? 'on' : ''}`} style={{ left: `${tdate(d) * 100}%` }} disabled={mode !== 'cutout'} onClick={() => { setEp(i); setPlaying(false); }} title={d} aria-label={`Visit ${i + 1}, ${d}`} />)}
        </div>
      </div>

      {tour && !embed && (
        <div className="tour"><header>{tour.card.icon}<h3>{tour.card.title}</h3><button onClick={() => setTour(null)} aria-label="Close"><X size={18} /></button></header>
          <p>{tour.card.steps[tour.step]}</p>
          <footer><button onClick={() => setTour({ ...tour, step: Math.max(0, tour.step - 1) })} disabled={tour.step === 0} aria-label="Previous step"><ChevronLeft size={22} /></button><span>Step {tour.step + 1}/{tour.card.steps.length}</span>
            <button onClick={() => (tour.step + 1 < tour.card.steps.length ? setTour({ ...tour, step: tour.step + 1 }) : setTour(null))} aria-label="Next step"><ChevronRight size={22} /></button></footer></div>
      )}

      {welcome && !embed && (
        <div className="modal-bg" onClick={() => setWelcome(false)}><div className="modal" role="dialog" aria-label="Welcome" onClick={(e) => e.stopPropagation()}>
          <header><h2>Welcome to LumenX</h2><button onClick={() => setWelcome(false)} aria-label="Close"><X size={20} /></button></header>
          <p>Since 2025, NASA’s SPHEREx has mapped the whole sky every six months in 102 infrared bands. Pick a story to learn the tools, or <a href="#start" onClick={(e) => { e.preventDefault(); setWelcome(false); }}>start exploring <span className="go">→</span></a></p>
          <div className="cards">{CARDS.map((c) => <button key={c.id} className="card" onClick={() => startCard(c)} style={{ backgroundPosition: c.pos }}><span className="ci">{c.icon}</span><b>{c.title}</b><i>{c.blurb}</i></button>)}</div>
          <label className="check"><input type="checkbox" onChange={(e) => { try { localStorage.setItem('lumenx-skip', e.target.checked ? '1' : ''); } catch { /* ignore */ } }} /> Don’t show this on startup</label>
        </div></div>
      )}
      {about && (
        <div className="modal-bg" onClick={() => setAbout(false)}><div className="modal narrow" role="dialog" aria-label="About" onClick={(e) => e.stopPropagation()}>
          <header><h2>About LumenX</h2><button onClick={() => setAbout(false)} aria-label="Close"><X size={20} /></button></header>
          <p>LumenX is a public tool for spotting how the infrared sky changes. Enter a patch of sky and watch it play back as a short movie: movers such as comets, asteroids and brown dwarfs shift between visits, while variable stars pulse.</p>
          <p className="warn">Browse the selected field, compare observations across visits and inspect its spectral measurements.</p>
          <p className="hint"><Link to="/about" style={{ color: 'var(--teal)' }}>Brief coverage, data pipeline and model notes →</Link></p>
          <p className="hint">Built for the NASA Space Apps Challenge “Planet X and SPHEREx”. Try Barnard’s Star, Epsilon Indi B, WISE 0855, RW Aurigae and R Draconis.</p>
        </div></div>
      )}
      {toast && <div className="toast" role="status">{toast}</div>}
    </div>
  );
}