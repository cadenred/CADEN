/**
 * Pixel engine shared by the main thread and the Web Worker: it builds the frame the viewer shows
 * (single visit, co-add of visits, or difference) and turns it into colours. The heavy loops live here
 * so that engine.worker.ts can run them off the main thread and the sliders stay smooth.
 */
import { buildScene, renderBands, stretchOf, applyStretch } from './demoData';
import type { Scene, TargetDef } from './demoData';

export type Op = 'single' | 'add' | 'sub';
export type Palette = 'default' | 'cvd';
export type FrameParams = { fov: number; bands: number[]; ep: number; op: Op };
export type FrameResult = {
  sceneKey: string; w: number; h: number;
  data: Float32Array; sigma: number;
  /** previous visit (difference mode only) and the current visit, both with their noise */
  a: Float32Array | null; sigmaA: number; b: Float32Array; sigmaB: number;
  ref: { lo: number; hi: number };
};
export const sceneKeyOf = (t: TargetDef, fov: number) => `${t.id}|${fov}|${t.epochs.length}|${t.epochs[t.epochs.length - 1] ?? ''}`;

type Held = { sc: Scene; renders: Map<string, ReturnType<typeof renderBands>> };
export class FrameEngine {
  private held = new Map<string, Held>();
  private hold(t: TargetDef, fov: number): Held {
    const k = sceneKeyOf(t, fov);
    let h = this.held.get(k);
    if (!h) { if (this.held.size > 5) this.held.clear(); h = { sc: buildScene(t, fov), renders: new Map() }; this.held.set(k, h); }
    return h;
  }
  scene(t: TargetDef, fov: number) { return this.hold(t, fov).sc; }
  private render(h: Held, ep: number, bands: number[]) {
    const k = `${ep}|${bands.length}|${bands[0]}|${bands[bands.length - 1]}`;
    let r = h.renders.get(k);
    if (!r) { if (h.renders.size > 120) h.renders.clear(); r = renderBands(h.sc, ep, bands); h.renders.set(k, r); }
    return r;
  }
  frame(t: TargetDef, p: FrameParams): FrameResult {
    const h = this.hold(t, p.fov), sc = h.sc, nEp = sc.years.length, n = sc.w * sc.h;
    const ep = Math.min(p.ep, nEp - 1), cur = this.render(h, ep, p.bands), base = { sceneKey: sceneKeyOf(t, p.fov), w: sc.w, h: sc.h };
    if (p.op === 'single') return { ...base, data: cur.data.slice(), sigma: cur.sigma, a: null, sigmaA: 0, b: cur.data.slice(), sigmaB: cur.sigma, ref: stretchOf(this.render(h, 0, p.bands).data) };
    if (p.op === 'add') {
      const s = new Float32Array(n);
      for (let e = 0; e < nEp; e++) { const d = this.render(h, e, p.bands).data; for (let i = 0; i < n; i++) s[i] += d[i] / nEp; }
      return { ...base, data: s, sigma: cur.sigma / Math.sqrt(nEp), a: null, sigmaA: 0, b: cur.data.slice(), sigmaB: cur.sigma, ref: stretchOf(s) };
    }
    const prev = this.render(h, ep > 0 ? ep - 1 : Math.min(1, nEp - 1), p.bands), d = new Float32Array(n);
    for (let i = 0; i < n; i++) d[i] = cur.data[i] - prev.data[i];
    return { ...base, data: d, sigma: Math.hypot(cur.sigma, prev.sigma), a: prev.data.slice(), sigmaA: prev.sigma, b: cur.data.slice(), sigmaB: cur.sigma, ref: { lo: 0, hi: 1 } };
  }
}

/** Colours for a frame. 'cvd' uses a blue-to-yellow ramp and a blue/orange difference map that stay distinct for colour-blind viewers. */
export function frameToRgba(f: { data: Float32Array; sigma: number; ref: { lo: number; hi: number } }, op: Op, palette: Palette = 'default') {
  const n = f.data.length, out = new Uint8ClampedArray(n * 4);
  for (let i = 0; i < n; i++) {
    if (op === 'sub') {
      const z = f.data[i] / f.sigma, t = Math.min(1, Math.abs(z) / 8), p = z >= 0;
      if (palette === 'cvd') { out[i * 4] = (p ? 0 : 230) * t; out[i * 4 + 1] = (p ? 114 : 159) * t; out[i * 4 + 2] = (p ? 178 : 0) * t; if (t > 0.6) { out[i * 4] += 60 * (t - 0.6); out[i * 4 + 1] += 90 * (t - 0.6); out[i * 4 + 2] += 90 * (t - 0.6); } }
      else { out[i * 4] = (p ? 70 : 255) * t; out[i * 4 + 1] = (p ? 255 : 150) * t; out[i * 4 + 2] = (p ? 220 : 60) * t; }
    } else {
      const v = applyStretch(f.data[i], f.ref.lo, f.ref.hi);
      if (palette === 'cvd') { out[i * 4] = 255 * Math.min(1, Math.max(0, (v - 0.35) * 1.8)); out[i * 4 + 1] = 255 * Math.min(1, v * 1.1); out[i * 4 + 2] = 255 * Math.min(1, Math.max(0, 0.45 + v * 0.55 - v * v * 0.9)); }
      else { out[i * 4] = 255 * Math.min(1, v * 1.5); out[i * 4 + 1] = 255 * Math.min(1, Math.max(0, v * 1.25 - 0.1)); out[i * 4 + 2] = 255 * Math.min(1, Math.max(0, v * 1.5 - 0.45)); }
    }
    out[i * 4 + 3] = 255;
  }
  return out;
}

/** Cross-fade two colour frames into `out` (a straight blend, m = 0 gives `a`, m = 1 gives `b`). Used for smooth playback between visits. */
export function blendInto<T extends Uint8ClampedArray>(out: T, a: Uint8ClampedArray, b: Uint8ClampedArray, m: number): T {
  const k = 1 - m;
  for (let i = 0; i < out.length; i++) out[i] = a[i] * k + b[i] * m;
  return out;
}