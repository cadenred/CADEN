import { useEffect, useRef } from 'react';
import type { KeyboardEvent, PointerEvent } from 'react';
import { FLAG_INFO } from './demoData';
import { blendInto } from './engine';
import type { Residual } from './changeDetection';

export type Mark = { x: number; y: number; label?: string; dashed?: boolean; color?: string };
export type SkyFrameProps = {
  rgba: Uint8ClampedArray; w: number; h: number; mask: Uint8Array | null; zoom: number;
  pick: { x: number; y: number } | null; onPick: (x: number, y: number) => void; onHover: (p: { x: number; y: number } | null) => void;
  expected: Mark[]; gaia: Mark[]; wise: Mark[]; residuals: Residual[]; ariaLabel: string;
  /** optional next-visit colours and 0..1 blend, used to animate smoothly between visits */
  rgbaB?: Uint8ClampedArray | null; mix?: number;
};

export function SkyFrame(p: SkyFrameProps) {
  const img = useRef<HTMLCanvasElement>(null), msk = useRef<HTMLCanvasElement>(null), buf = useRef<ImageData | null>(null);
  useEffect(() => {
    const c = img.current; if (!c) return;
    const ctx = c.getContext('2d'); if (!ctx) return;
    const m = p.rgbaB && p.rgbaB.length === p.rgba.length ? Math.min(1, Math.max(0, p.mix ?? 0)) : 0;
    if (m < 0.002 || !p.rgbaB) { ctx.putImageData(new ImageData(new Uint8ClampedArray(p.rgba), p.w, p.h), 0, 0); return; }
    let id = buf.current; if (!id || id.width !== p.w || id.height !== p.h) { id = new ImageData(p.w, p.h); buf.current = id; }
    blendInto(id.data, p.rgba, p.rgbaB, m); ctx.putImageData(id, 0, 0);
  }, [p.rgba, p.rgbaB, p.mix, p.w, p.h]);
  useEffect(() => {
    const c = msk.current; if (!c) return;
    const ctx = c.getContext('2d'); if (!ctx) return;
    ctx.clearRect(0, 0, p.w, p.h);
    if (!p.mask) return;
    const out = ctx.createImageData(p.w, p.h);
    const order = [...FLAG_INFO].reverse(); // earlier entries win
    for (let i = 0; i < p.mask.length; i++) {
      const m = p.mask[i]; if (!m) continue;
      const f = order.filter((o) => m & o.bit).pop(); if (!f) continue;
      out.data[i * 4] = parseInt(f.color.slice(1, 3), 16); out.data[i * 4 + 1] = parseInt(f.color.slice(3, 5), 16); out.data[i * 4 + 2] = parseInt(f.color.slice(5, 7), 16); out.data[i * 4 + 3] = 150;
    }
    ctx.putImageData(out, 0, 0);
  }, [p.mask, p.w, p.h]);

  const at = (e: PointerEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    const x = Math.floor(((e.clientX - r.left) / r.width) * p.w), y = Math.floor(((e.clientY - r.top) / r.height) * p.h);
    return x >= 0 && y >= 0 && x < p.w && y < p.h ? { x, y } : null;
  };
  const key = (e: KeyboardEvent<HTMLDivElement>) => {
    const d: Record<string, [number, number]> = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] };
    const v = d[e.key]; if (!v) return;
    e.preventDefault();
    const c = p.pick ?? { x: Math.floor(p.w / 2), y: Math.floor(p.h / 2) };
    p.onPick(Math.min(p.w - 1, Math.max(0, c.x + v[0])), Math.min(p.h - 1, Math.max(0, c.y + v[1])));
  };
  const u = p.w / 100, ring = Math.max(2.6, p.w * 0.035), cat = Math.max(1.3, p.w * 0.012), fs = Math.max(2.2, p.w * 0.03);
  return (
    <div className="sky-frame" style={{ transform: `scale(${p.zoom})` }} tabIndex={0} role="application" aria-label={`${p.ariaLabel}. Click or use arrow keys to choose a pixel and plot its spectrum.`}
      onPointerDown={(e) => { const c = at(e); if (c) p.onPick(c.x, c.y); }} onPointerMove={(e) => p.onHover(at(e))} onPointerLeave={() => p.onHover(null)} onKeyDown={key}>
      <canvas ref={img} width={p.w} height={p.h} className="sky-canvas" />
      <canvas ref={msk} width={p.w} height={p.h} className="sky-canvas" />
      <svg className="sky-overlay" viewBox={`0 0 ${p.w} ${p.h}`} aria-hidden="true">
        {p.wise.map((m, i) => (<rect key={'w' + i} x={m.x + 0.5 - cat} y={m.y + 0.5 - cat} width={cat * 2} height={cat * 2} fill="none" stroke="#ffb86b" strokeWidth="1.3" vectorEffect="non-scaling-stroke" />))}
        {p.gaia.map((m, i) => (<circle key={'g' + i} cx={m.x + 0.5} cy={m.y + 0.5} r={cat * 1.15} fill="none" stroke="#7fd3ff" strokeWidth="1.3" vectorEffect="non-scaling-stroke" />))}
        {p.residuals.map((r, i) => (<g key={'r' + i}><circle cx={r.x + 0.5} cy={r.y + 0.5} r={ring * 0.8} fill="none" stroke={r.z >= 0 ? '#5ef2d0' : '#ff9a55'} strokeWidth="1.8" vectorEffect="non-scaling-stroke" /></g>))}
        {p.expected.map((m, i) => (<g key={'e' + i}><circle cx={m.x + 0.5} cy={m.y + 0.5} r={ring} fill="none" stroke={m.color ?? '#ffffff'} strokeWidth="1.6" strokeDasharray={m.dashed ? '3 3' : undefined} vectorEffect="non-scaling-stroke" />{m.label && <text x={m.x + 0.5 + ring + u * 0.4} y={m.y + 0.5 - ring * 0.6} fontSize={fs} fill={m.color ?? '#ffffff'} className="sky-label">{m.label}</text>}</g>))}
        {p.pick && <rect x={p.pick.x} y={p.pick.y} width="1" height="1" fill="none" stroke="#c7e7df" strokeWidth="2" vectorEffect="non-scaling-stroke" />}
      </svg>
    </div>
  );
}