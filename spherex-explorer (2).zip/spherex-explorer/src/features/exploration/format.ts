/** Coordinate formatting / parsing shared by every screen. */
export const wrap360 = (a: number) => ((a % 360) + 360) % 360;
export const fmtRA = (ra: number) => { const h = ra / 15, hh = Math.floor(h), m = (h - hh) * 60, mm = Math.floor(m); return `${hh}h${String(mm).padStart(2, '0')}m${((m - mm) * 60).toFixed(1)}s`; };
export const fmtDec = (d: number) => { const a = Math.abs(d), dd = Math.floor(a), m = (a - dd) * 60, mm = Math.floor(m); return `${d < 0 ? '−' : '+'}${dd}°${String(mm).padStart(2, '0')}′${((m - mm) * 60).toFixed(0)}″`; };
export const MON = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
export const fmtWV = (iso: string) => { const [y, m, d] = iso.split('-'); return `${y} ${MON[+m - 1]} ${d}`; };

export function parseCoords(s: string): { ra: number; dec: number } | null {
  const t = s.trim();
  const m = t.match(/^(\d+(?:\.\d+)?)\s*[h: ]\s*(\d+(?:\.\d+)?)\s*[m: ]\s*(\d+(?:\.\d+)?)\s*s?\s*,?\s*([+\-−]?)\s*(\d+(?:\.\d+)?)\s*[d°: ]\s*(\d+(?:\.\d+)?)\s*['′m: ]\s*(\d+(?:\.\d+)?)/i);
  if (m) { const dec = (+m[5] + +m[6] / 60 + +m[7] / 3600) * (m[4] === '-' || m[4] === '−' ? -1 : 1); return { ra: (+m[1] + +m[2] / 60 + +m[3] / 3600) * 15, dec }; }
  const p = t.replace('−', '-').split(/[\s,]+/).map(Number);
  if (p.length === 2 && p.every(Number.isFinite) && p[1] >= -90 && p[1] <= 90) return { ra: wrap360(p[0]), dec: p[1] };
  return null;
}

/** Name lookup through CDS Sesame (SIMBAD/NED/VizieR). Returns null when offline or not found. */
export async function resolveRemote(name: string): Promise<{ ra: number; dec: number; name: string } | null> {
  try {
    const r = await fetch(`https://cds.unistra.fr/cgi-bin/nph-sesame/-oI/SNV?${encodeURIComponent(name.trim())}`);
    if (!r.ok) return null;
    const txt = await r.text(), line = txt.split('\n').find((l) => l.startsWith('%J'));
    const m = line?.match(/^%J\s+([\d.]+)\s+([+-]?[\d.]+)/);
    return m ? { ra: +m[1], dec: +m[2], name: name.trim() } : null;
  } catch { return null; }
}
