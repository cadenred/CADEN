/**
 * Demo SURVEY CADENCE model (still synthetic, but shaped like the real mission).
 *  - SPHEREx scans along great circles through the ecliptic poles; the orbit precesses ~1°/day, so
 *    the whole sky is covered once per ~6 months (four surveys in the 25-month prime mission).
 *  - A patch near the ecliptic plane is therefore seen about once per survey, so only ~3 passes exist
 *    by late 2026. Patches near the ecliptic poles (the deep fields) are revisited much more often.
 * TODO(verify): the survey start date, 182.6-day length and visit counts are approximations; replace with
 * the real exposure table from IRSA when the backend exists.
 */
const D = Math.PI / 180;
export const OBLIQUITY = 23.4392911;
export const SURVEY_LEN_DAYS = 182.62;
export const SURVEY_START = '2025-05-01';
export const MISSION_START_MJD = Date.UTC(2025, 4, 1) / 86400000 + 40587;
export const isoOfMjd = (mjd: number) => new Date((mjd - 40587) * 86400000).toISOString().slice(0, 10);
export const mjdOfIso = (iso: string) => Date.parse(iso + 'T00:00:00Z') / 86400000 + 40587;
export const todayIso = () => new Date().toISOString().slice(0, 10);

/** Equatorial -> ecliptic (degrees). */
export function eclipticOf(ra: number, dec: number) {
  const a = ra * D, d = dec * D, e = OBLIQUITY * D;
  const lat = Math.asin(Math.sin(d) * Math.cos(e) - Math.cos(d) * Math.sin(e) * Math.sin(a));
  const lon = Math.atan2(Math.sin(a) * Math.cos(e) * Math.cos(d) + Math.sin(d) * Math.sin(e), Math.cos(a) * Math.cos(d));
  return { lon: (((lon / D) % 360) + 360) % 360, lat: lat / D };
}

/** Sun's ecliptic longitude (degrees), low-precision almanac formula (good to ~0.01°). */
export function sunLongitude(mjd: number) {
  const n = mjd - 51544.5, L = 280.46 + 0.9856474 * n, g = (357.528 + 0.9856003 * n) * D;
  return (((L + 1.915 * Math.sin(g) + 0.02 * Math.sin(2 * g)) % 360) + 360) % 360;
}
/** Unit vector toward the Sun in equatorial coordinates. */
export function sunVector(mjd: number): [number, number, number] {
  const l = sunLongitude(mjd) * D, e = OBLIQUITY * D;
  return [Math.cos(l), Math.sin(l) * Math.cos(e), Math.sin(l) * Math.sin(e)];
}
/** Parallax displacement (East, North) per unit parallax, seen from Earth at `mjd`. Multiply by parallax in arcsec. */
export function parallaxFactor(ra: number, dec: number, mjd: number) {
  const s = sunVector(mjd), a = ra * D, d = dec * D;
  const east = [-Math.sin(a), Math.cos(a), 0], north = [-Math.sin(d) * Math.cos(a), -Math.sin(d) * Math.sin(a), Math.cos(d)];
  return { e: s[0] * east[0] + s[1] * east[1] + s[2] * east[2], n: s[0] * north[0] + s[1] * north[1] + s[2] * north[2] };
}

/** How many visits one survey makes to a patch at this ecliptic latitude (1 near the ecliptic, many at the poles). */
export function visitsPerSurvey(lat: number) {
  const c = Math.max(0.02, Math.cos(lat * D));
  return Math.min(40, Math.max(1, Math.round(1.1 / c)));
}

export type VisitInfo = { iso: string; survey: number };
/** Visit dates (ISO) of a patch up to `now`, oldest first, each tagged with its survey number (1-4). */
export function surveyVisits(ra: number, dec: number, now = todayIso()): VisitInfo[] {
  const { lon, lat } = eclipticOf(ra, dec), c = Math.max(0.05, Math.cos(lat * D));
  const sun0 = sunLongitude(MISSION_START_MJD);
  const days = ((((lon - 90 - sun0) % 180) + 180) % 180) / 0.9856;
  const n = visitsPerSurvey(lat), half = n === 1 ? 0 : Math.min(25, 1.8 / (0.9856 * c));
  const out: VisitInfo[] = [], nowM = mjdOfIso(now);
  for (let s = 0; s < 4; s++) for (let i = 0; i < n; i++) {
    const m = MISSION_START_MJD + s * SURVEY_LEN_DAYS + days + (n === 1 ? 0 : (i / (n - 1) - 0.5) * 2 * half);
    if (m <= nowM && m >= MISSION_START_MJD) out.push({ iso: isoOfMjd(m), survey: s + 1 });
  }
  const seen = new Set<string>();
  return out.filter((v) => (seen.has(v.iso) ? false : (seen.add(v.iso), true))).sort((a, b) => a.iso.localeCompare(b.iso));
}
export const surveyEpochs = (ra: number, dec: number, now = todayIso()) => surveyVisits(ra, dec, now).map((v) => v.iso);
/** Survey number (1-4) for any date. */
export const surveyOf = (iso: string) => Math.min(4, Math.max(1, Math.floor((mjdOfIso(iso) - MISSION_START_MJD) / SURVEY_LEN_DAYS) + 1));

/**
 * Time-ordered EXPOSURE model for one survey pass over a patch. Each exposure samples only a small slice of
 * wavelengths at a given position (the arrays carry linear-variable filters), so the 102-band spectrum of one
 * position is assembled from many exposures taken over days to weeks. In this demo the six arrays step through
 * their 17 channels one after another across `spanDays`.
 * TODO(verify): the true ordering and spacing come from the mission's exposure table, not from this model.
 */
export function exposureSchedule(visitIso: string, spanDays = 16) {
  const out: { band: number; array: number; dayOffset: number; mjd: number }[] = [], m0 = mjdOfIso(visitIso);
  for (let a = 0; a < 6; a++) for (let k = 0; k < 17; k++) {
    const dayOffset = ((a % 3) * 17 + k) * (spanDays / 51); // short- and long-wavelength mosaics look at the field at the same time
    out.push({ band: a * 17 + k, array: a, dayOffset, mjd: m0 + dayOffset });
  }
  return out;
}
