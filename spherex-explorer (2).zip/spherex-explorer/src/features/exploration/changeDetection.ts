/**
 * Change-detection hook.
 *
 * To plug in your ML model: implement ChangeDetector and call
 * registerChangeDetector(yourDetector). It receives two ALIGNED epochs (same
 * grid, same size) plus their noise levels and must return a probability
 * map (0..1, one value per pixel) that the pixel changed between epoch A and B.
 * The UI lists every registered detector in the "Detector" dropdown.
 *
 *   registerChangeDetector({
 *     id: 'my-model', label: 'My ML model',
 *     detect: ({ a, b, width, height }) => myModel(a, b, width, height), // Float32Array
 *   });
 */
export type AlignedEpochs = { a: Float32Array; b: Float32Array; sigmaA: number; sigmaB: number; width: number; height: number };
export interface ChangeDetector { id: string; label: string; detect(input: AlignedEpochs): Float32Array }

/** Non-ML baseline: significance of (B − A) squashed to a probability. */
export const baselineDetector: ChangeDetector = {
  id: 'baseline',
  label: 'Baseline: difference ÷ noise',
  detect({ a, b, sigmaA, sigmaB }) {
    const s = Math.hypot(sigmaA, sigmaB), out = new Float32Array(a.length);
    for (let i = 0; i < a.length; i++) out[i] = 1 / (1 + Math.exp(-(Math.abs(b[i] - a[i]) / s - 4.5) * 1.6));
    return out;
  },
};

const registry: ChangeDetector[] = [baselineDetector];
export const listChangeDetectors = () => registry.slice();
export function registerChangeDetector(d: ChangeDetector) {
  const i = registry.findIndex((r) => r.id === d.id);
  if (i >= 0) registry[i] = d; else registry.push(d);
}

export type Residual = { x: number; y: number; z: number; p: number };
/** Local maxima of the probability map, strongest first. */
export function findResiduals(prob: Float32Array, a: Float32Array, b: Float32Array, sigma: number, w: number, h: number, minP = 0.5, max = 12): Residual[] {
  const out: Residual[] = [];
  for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) {
    const i = y * w + x, p = prob[i];
    if (p < minP) continue;
    let top = true;
    for (let dy = -1; dy <= 1 && top; dy++) for (let dx = -1; dx <= 1; dx++) if ((dx || dy) && Math.abs(b[i + dy * w + dx] - a[i + dy * w + dx]) > Math.abs(b[i] - a[i])) { top = false; break; }
    if (top) out.push({ x, y, z: (b[i] - a[i]) / sigma, p });
  }
  return out.sort((m, n) => n.p - m.p || Math.abs(n.z) - Math.abs(m.z)).slice(0, max);
}