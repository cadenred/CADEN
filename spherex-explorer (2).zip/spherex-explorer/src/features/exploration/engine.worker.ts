/// Web Worker: builds scenes and frames off the main thread (see engine.ts).
import { FrameEngine } from './engine';
import type { FrameParams } from './engine';
import type { TargetDef } from './demoData';

type Req = { id: number; target: TargetDef; params: FrameParams };
const ctx = self as unknown as { postMessage(m: unknown, t?: Transferable[]): void; onmessage: ((e: MessageEvent<Req>) => void) | null };
const engine = new FrameEngine();
ctx.onmessage = (e) => {
  const { id, target, params } = e.data;
  try {
    const result = engine.frame(target, params);
    const t: Transferable[] = [result.data.buffer, result.b.buffer];
    if (result.a) t.push(result.a.buffer);
    ctx.postMessage({ id, result }, t);
  } catch (err) { ctx.postMessage({ id, error: String(err) }); }
};
