import { ScreenShell } from './ScreenShell';
import { usePrefs, setPrefs } from '../../app/prefs';
import type { Lang } from '../../app/prefs';
import { useT } from '../../app/i18n';

export function SettingsPage() {
  const p = usePrefs(), t = useT();
  const Toggle = ({ k, label, hint }: { k: 'dataSaver' | 'reduceMotion'; label: string; hint: string }) => <label className="panel" style={{ display: 'flex', gap: 12, alignItems: 'center', cursor: 'pointer' }}><input type="checkbox" checked={p[k]} onChange={(e) => setPrefs({ [k]: e.target.checked })} /><span><b>{label}</b><br /><span className="note">{hint}</span></span></label>;
  return (
    <ScreenShell title={t('settings')} lead="Saved on this device.">
      <Toggle k="dataSaver" label={t('dataSaver')} hint="Starts with a small 6′ field and caps the explorer’s field at 12′, so each view downloads far less. Combined with the offline cache (install the app from your browser menu), repeated views cost nothing." />
      <Toggle k="reduceMotion" label={t('motion')} hint="Turns off fly-to animation and autoplay. Follows your system setting by default." />
      <div className="panel"><div className="row"><label>{t('palette')}<select value={p.palette} onChange={(e) => setPrefs({ palette: e.target.value as 'default' | 'cvd' })}><option value="default">Default (warm images, teal/orange differences)</option><option value="cvd">Colour-blind safe (blue→yellow, blue/orange differences)</option></select></label>
        <label>{t('language')}<select value={p.lang} onChange={(e) => setPrefs({ lang: e.target.value as Lang })}><option value="en">English</option><option value="fr">Français</option><option value="es">Español</option></select></label></div>
        <p className="note">Translations cover navigation and settings; the rest of the interface is English for now.</p></div>
    </ScreenShell>
  );
}
