import type { ReactNode } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { useT } from '../../app/i18n';
import { useManifest } from '../data/useManifest';
import '../../styles/screens.css';

export const NAV: [string, string][] = [['/', 'explorer'], ['/measure', 'measure'], ['/spectrum', 'spectrum'], ['/exposures', 'exposures'], ['/candidates', 'candidates'], ['/inject', 'inject'], ['/compare', 'compare'], ['/tests', 'tests'], ['/about', 'about'], ['/settings', 'settings']];

export function ScreenShell({ title, lead, children, wide }: { title: string; lead?: string; children: ReactNode; wide?: boolean }) {
  const t = useT(), { manifest, isNew, markSeen } = useManifest();
  return (
    <div className="screen">
      <header className="screen-top">
        <Link className="screen-brand" to="/" aria-label="LumenX explorer"><img src="/lumenx-symbol.png" alt="" /><span>LUMEN<b>X</b></span></Link>
        <nav aria-label="Screens">{NAV.map(([to, k]) => <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => (isActive ? 'on' : '')}>{t(k)}</NavLink>)}</nav>
        {manifest && <button className={`chip ${isNew ? 'new' : ''}`} onClick={markSeen} title="Dataset version">{isNew ? 'New data release · ' : ''}{manifest.version}</button>}
      </header>
      <main className={`screen-body ${wide ? 'wide' : ''}`}>
        <h1>{title}</h1>
        {lead && <p className="lead">{lead}</p>}
        {children}
      </main>
    </div>
  );
}
