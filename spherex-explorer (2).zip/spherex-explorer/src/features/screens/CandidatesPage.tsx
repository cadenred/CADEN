import { Link } from 'react-router-dom';
import { ScreenShell } from './ScreenShell';
import { useCandidates, removeCandidate, clearCandidates, updateNote, candidatesCsv, download } from '../analysis/candidates';
import { fmtRA, fmtDec } from '../exploration/format';
import { useT } from '../../app/i18n';

export function CandidatesPage() {
  const list = useCandidates(), t = useT();

  return (
    <ScreenShell
      title="My candidates"
      lead="Objects you flagged in the Measure screen. A candidate is a lead, not a discovery: check it against other surveys before claiming anything. Saved in this browser only; export the CSV to keep or share them."
    >
      <div className="row">
        <button
          className="btn pri"
          disabled={!list.length}
          onClick={() => download('lumenx-candidates.csv', candidatesCsv(list))}
        >
          {t('export')}
        </button>

        <button
          className="btn warn"
          disabled={!list.length}
          onClick={() => {
            if (window.confirm('Delete all saved candidates?')) clearCandidates();
          }}
        >
          Clear all
        </button>

        <span className="note">{list.length} saved</span>
      </div>

      {!list.length && (
        <div className="panel">
          <p>
            Nothing here yet. Open{' '}
            <Link to="/measure?target=wise0855&auto=1">Measure</Link>,
            track an object and press “Save as candidate”, or try the{' '}
            <Link to="/inject">injection test</Link> first.
          </p>
        </div>
      )}

      <div className="cands">
        {list.map((c) => (
          <article className="cand" key={c.id}>
            <h3>{c.name}</h3>

            <p><span className="badge">{c.cls}</span></p>

            <p className="mono note">
              RA {fmtRA(c.ra)} · Dec {fmtDec(c.dec)}
              <br />
              {c.ra.toFixed(5)}°, {c.dec.toFixed(5)}° · saved {c.created}
            </p>

            <div className="stat">
              <div>
                <b>{c.pm.toFixed(3)}″/yr</b>
                <span>motion ± {c.pmErr.toFixed(3)}, towards {c.pa.toFixed(0)}°</span>
              </div>

              <div>
                <b>{Math.abs(c.plx).toFixed(3)}″</b>
                <span>parallax ± {c.plxErr.toFixed(3)}</span>
              </div>
            </div>

            <p className="note">
              {c.visits} visits · {c.inGaia ? 'listed in Gaia' : 'not in Gaia'} ·{' '}
              {c.inWise ? 'listed in WISE' : 'not in WISE'}
              {c.flux ? ` · brightness ${c.flux.pct.toFixed(0)}% (${c.flux.z.toFixed(1)}σ)` : ''}
            </p>

            <textarea
              rows={2}
              placeholder="Notes"
              defaultValue={c.note}
              onBlur={(e) => updateNote(c.id, e.target.value)}
              aria-label="Notes"
            />

            <div className="row">
              <Link className="btn" to={c.link}>Open</Link>

              <button
                className="btn"
                onClick={() => navigator.clipboard?.writeText(window.location.origin + c.link)}
              >
                Copy link
              </button>

              <button className="btn warn" onClick={() => removeCandidate(c.id)}>
                Delete
              </button>
            </div>
          </article>
        ))}
      </div>
    </ScreenShell>
  );
}