import { useEffect, useRef, useState } from 'react';
import { ScreenShell } from './ScreenShell';
import { Thumb } from './Thumb';
import { useTarget } from './useTarget';
import { TARGETS, ALL_BANDS } from '../exploration/demoData';
import { loadCuts } from '../analysis/pipeline';
import { tanToSky } from '../exploration/wcs';
import { fmtRA, fmtDec } from '../exploration/format';
import { usePrefs } from '../../app/prefs';

/* eslint-disable @typescript-eslint/no-explicit-any */

const SRC = 'https://aladin.cds.unistra.fr/AladinLite/api/v3/latest/aladin.js';
let loading: Promise<any> | null = null;

function loadAladin(): Promise<any> {
  const w = window as any;

  if (w.A?.init) return w.A.init.then(() => w.A);

  loading ??= new Promise((ok, fail) => {
    const s = document.createElement('script');
    s.src = SRC;
    s.async = true;

    s.onload = () => (
      w.A?.init ? w.A.init.then(() => ok(w.A)) : ok(w.A)
    );

    s.onerror = () => {
      loading = null;
      fail(new Error('Aladin Lite could not be loaded (offline?)'));
    };

    document.head.appendChild(s);
  });

  return loading;
}

const SURVEYS: [string, string][] = [
  ['P/DSS2/color', 'DSS2 colour (optical)'],
  ['P/2MASS/color', '2MASS (near-infrared)'],
  ['P/allWISE/color', 'AllWISE (mid-infrared)']
];

export function ComparePage() {
  const { def, ref, fov, set, pick } = useTarget('barnard'), { palette } = usePrefs();

  const box = useRef<HTMLDivElement>(null);
  const al = useRef<any>(null);
  const mk = useRef<any>(null);

  const [view, setView] = useState<Awaited<ReturnType<typeof loadCuts>> | null>(null);
  const [visit, setVisit] = useState(0);

  const [hover, setHover] = useState<{ ra: number; dec: number } | null>(null);
  const [err, setErr] = useState('');
  const [survey, setSurvey] = useState(SURVEYS[0][0]);

  useEffect(() => {
    let dead = false;

    loadCuts(ref, fov, ALL_BANDS).then((d) => {
      if (!dead) setView(d);
    });

    return () => { dead = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [def.id, fov]);

  useEffect(() => {
    let dead = false;
    setErr('');

    loadAladin().then((A) => {
      if (dead || !box.current) return;

      box.current.innerHTML = '';

      const a = A.aladin(box.current, {
        target: `${def.ra} ${def.dec}`,
        fov: (fov / 60) * 2.2,
        survey,
        showReticle: true,
        showZoomControl: true,
        showFullscreenControl: false,
        showLayersControl: false,
        showCooGridControl: true
      });

      const cat = A.catalog({
        name: 'LumenX cursor',
        shape: 'cross',
        sourceSize: 26,
        color: '#5ef2d0'
      });

      a.addCatalog(cat);
      al.current = a;
      mk.current = { A, cat };
    }).catch((e) => !dead && setErr(String(e.message ?? e)));

    return () => { dead = true; };
  }, [def.id, fov, survey]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const m = mk.current;

    if (!m || !hover) return;

    try {
      m.cat.removeAll();
      m.cat.addSources([m.A.source(hover.ra, hover.dec)]);
    } catch {
      /* ignore */
    }
  }, [hover]);

  const cut = view?.cuts[Math.min(visit, (view?.cuts.length ?? 1) - 1)];

  return (
    <ScreenShell
      title="Real sky beside the cutout"
      lead="Left: the LumenX cutout. Right: the corresponding sky region in the Aladin Lite viewer (CDS). Move over the cutout and a cross follows on the real sky."
      wide
    >
      <div className="panel">
        <div className="row">
          <label>
            Target
            <select
              value={def.id}
              onChange={(e) => pick(TARGETS.find((x) => x.id === e.target.value)!)}
            >
              {TARGETS.map((x) => (
                <option key={x.id} value={x.id}>{x.name}</option>
              ))}
            </select>
          </label>

          <label>
            Field
            <select value={fov} onChange={(e) => set({ fov: e.target.value })}>
              {[6, 10, 15, 20].map((f) => (
                <option key={f} value={f}>{f}′</option>
              ))}
            </select>
          </label>

          <label>
            Visit
            <select value={visit} onChange={(e) => setVisit(+e.target.value)}>
              {view?.cuts.map((c, i) => (
                <option key={i} value={i}>{i + 1} · {c.iso}</option>
              ))}
            </select>
          </label>

          <label>
            Survey
            <select value={survey} onChange={(e) => setSurvey(e.target.value)}>
              {SURVEYS.map(([id, l]) => (
                <option key={id} value={id}>{l}</option>
              ))}
            </select>
          </label>
        </div>
      </div>

      <div className="grid2">
        <div className="panel">
          {cut && view && (
            <Thumb
              cut={cut}
              stretch={view.stretch}
              palette={palette}
              size={Math.min(520, Math.max(300, Math.floor(window.innerWidth * 0.4)))}
              onHover={(p) => {
                if (p && cut) {
                  const w = cut.wcs;

                  setHover(
                    tanToSky(
                      w.ra0,
                      w.dec0,
                      (w.cx - p.x) * w.pix,
                      (w.cy - p.y) * w.pix
                    )
                  );
                }
              }}
              caption={hover
                ? `RA ${fmtRA(hover.ra)} · Dec ${fmtDec(hover.dec)}`
                : 'move the pointer over the field'}
            />
          )}

          <p className="note">
            The real sky shows the object’s catalogue epoch position; fast movers like Barnard’s Star sit away from the centre in old survey images.
          </p>
        </div>

        <div className="panel">
          {err ? <p className="warnbox">{err}</p> : null}
          <div className="aladin-box" ref={box} />
        </div>
      </div>
    </ScreenShell>
  );
}