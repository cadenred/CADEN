import type { ReactNode } from 'react';

export type PlotPt = { x: number; y: number; ex?: number; ey?: number };
export type Series = { pts: PlotPt[]; color: string; line?: boolean; dash?: string; dots?: boolean; r?: number; label?: string; width?: number };
export type VLine = { x: number; label: string; color?: string };

const nice = (lo: number, hi: number, n = 5) => {
  const span = hi - lo || 1, raw = span / n, mag = Math.pow(10, Math.floor(Math.log10(raw))), f = raw / mag, step = (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10) * mag;
  const out: number[] = []; for (let v = Math.ceil(lo / step) * step; v <= hi + step * 1e-6; v += step) out.push(+v.toFixed(10)); return { ticks: out, step };
};
const fmt = (v: number, step: number) => (Math.abs(v) >= 1e5 ? v.toExponential(0) : step >= 1 ? v.toFixed(0) : v.toFixed(Math.min(4, Math.max(0, -Math.floor(Math.log10(step))))));

/** Small dependency-free SVG plot: scatter + lines + error bars + labelled vertical markers. */
export function XYPlot({ series, vlines = [], xl, yl, w = 640, h = 360, invertX = false, equal = false, title, children }:
  { series: Series[]; vlines?: VLine[]; xl: string; yl: string; w?: number; h?: number; invertX?: boolean; equal?: boolean; title?: string; children?: ReactNode }) {
  const L = 58, R = 16, T = 18, B = 44, all = series.flatMap((s) => s.pts);
  if (!all.length) return <div className="plot-empty">No data to plot yet</div>;
  const xs = all.flatMap((p) => [p.x - (p.ex ?? 0), p.x + (p.ex ?? 0)]), ys = all.flatMap((p) => [p.y - (p.ey ?? 0), p.y + (p.ey ?? 0)]);
  let x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
  const px = (x1 - x0) * 0.06 || 1, py = (y1 - y0) * 0.08 || 1; x0 -= px; x1 += px; y0 -= py; y1 += py;
  if (equal) { const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, k = (w - L - R) / (h - T - B), sx = x1 - x0, sy = y1 - y0; const half = Math.max(sx / k, sy) / 2; x0 = cx - half * k; x1 = cx + half * k; y0 = cy - half; y1 = cy + half; }
  const X = (x: number) => L + ((invertX ? x1 - x : x - x0) / (x1 - x0)) * (w - L - R), Y = (y: number) => T + (1 - (y - y0) / (y1 - y0)) * (h - T - B);
  const tx = nice(x0, x1, 6), ty = nice(y0, y1, 5);
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="xyplot" role="img" aria-label={title ?? `${yl} versus ${xl}`}>
      {ty.ticks.map((v) => <g key={'y' + v}><line x1={L} x2={w - R} y1={Y(v)} y2={Y(v)} className="grid" /><text x={L - 8} y={Y(v) + 3.5} textAnchor="end" className="tick">{fmt(v, ty.step)}</text></g>)}
      {tx.ticks.map((v) => <g key={'x' + v}><line x1={X(v)} x2={X(v)} y1={T} y2={h - B} className="grid" /><text x={X(v)} y={h - B + 16} textAnchor="middle" className="tick">{fmt(v, tx.step)}</text></g>)}
      <rect x={L} y={T} width={w - L - R} height={h - T - B} className="frame" />
      {vlines.map((v, i) => (v.x >= x0 && v.x <= x1) && <g key={'v' + i}><line x1={X(v.x)} x2={X(v.x)} y1={T} y2={h - B} stroke={v.color ?? '#ffd37a'} strokeDasharray="4 4" opacity=".75" /><text x={X(v.x) + 4} y={T + 12 + (i % 3) * 12} className="vlab" fill={v.color ?? '#ffd37a'}>{v.label}</text></g>)}
      {series.map((s, si) => (
        <g key={si}>
          {s.line && s.pts.length > 1 && <path d={s.pts.map((p, i) => `${i ? 'L' : 'M'}${X(p.x).toFixed(1)},${Y(p.y).toFixed(1)}`).join('')} fill="none" stroke={s.color} strokeWidth={s.width ?? 1.6} strokeDasharray={s.dash} opacity=".9" />}
          {s.dots !== false && s.pts.map((p, i) => (
            <g key={i}>
              {p.ey ? <line x1={X(p.x)} x2={X(p.x)} y1={Y(p.y - p.ey)} y2={Y(p.y + p.ey)} stroke={s.color} opacity=".45" /> : null}
              {p.ex ? <line x1={X(p.x - p.ex)} x2={X(p.x + p.ex)} y1={Y(p.y)} y2={Y(p.y)} stroke={s.color} opacity=".45" /> : null}
              <circle cx={X(p.x)} cy={Y(p.y)} r={s.r ?? 3} fill={s.color} />
            </g>))}
        </g>))}
      {children}
      <text x={(L + w - R) / 2} y={h - 6} textAnchor="middle" className="axl">{xl}</text>
      <text x={14} y={(T + h - B) / 2} textAnchor="middle" className="axl" transform={`rotate(-90 14 ${(T + h - B) / 2})`}>{yl}</text>
    </svg>
  );
}
export function Legend({ items }: { items: { color: string; label: string; dash?: boolean }[] }) {
  return <ul className="plegend">{items.map((i) => <li key={i.label}><span style={{ background: i.dash ? 'transparent' : i.color, borderTop: i.dash ? `2px dashed ${i.color}` : undefined }} />{i.label}</li>)}</ul>;
}
