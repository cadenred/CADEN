import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ScreenShell } from './ScreenShell';
import { TARGETS } from '../exploration/demoData';
import { refOf } from '../data/dataSource';
import { KNOWN, lookFor, totalPm } from '../data/knownValues';
import { autoMeasure } from '../analysis/pipeline';
import { fmtRA, fmtDec } from '../exploration/format';

type Row = Awaited<ReturnType<typeof autoMeasure>> | null;
const REQUIRED = ['barnard', 'epsindib', 'wise0855', 'rwaur', 'rdra'];

export function TestsPage() {
  const [rows, setRows] = useState<Record<string, Row>>({});
  const [running, setRunning] = useState(false);

  const run = async () => {
    setRunning(true);
    setRows({});

    for (const id of REQUIRED) {
      const t = TARGETS.find((x) => x.id === id)!;
      const r = await autoMeasure(refOf(t), id);

      setRows((p) => ({ ...p, [id]: r }));
      await new Promise((ok) => setTimeout(ok, 0));
    }

    setRunning(false);
  };

  useEffect(() => { void run(); }, []);

  const verdict = (id: string, r: Row) => {
    if (!r?.lin) return { ok: false, text: 'could not track' };

    const k = KNOWN[id];
    const lin = r.lin;

    if (k) {
      const d = Math.abs(lin.pm - totalPm(k));
      const s = d / Math.max(lin.errPm, 1e-6);

      return {
        ok: s < 3,
        text: `${lin.pm.toFixed(2)} ± ${lin.errPm.toFixed(2)} vs ${totalPm(k).toFixed(2)} (${s.toFixed(1)}σ)`
      };
    }

    return {
      ok: lin.pm < Math.max(0.05, 3 * lin.errPm),
      text: `${lin.pm.toFixed(3)} ± ${lin.errPm.toFixed(3)} (consistent with no motion)`
    };
  };

  return (
    <ScreenShell
      title="The five test targets"
      lead="Everything the challenge asks you to try, one click each, with what to look for and an automatic check that the motion LumenX measures matches the literature value."
    >
      <div className="row">
        <button className="btn pri" onClick={run} disabled={running}>
          {running ? 'Measuring…' : 'Re-run all checks'}
        </button>
      </div>

      <div className="grid3" style={{ gridTemplateColumns: 'repeat(auto-fill,minmax(320px,1fr))' }}>
        {REQUIRED.map((id) => {
          const t = TARGETS.find((x) => x.id === id)!;
          const r = rows[id];
          const v = r ? verdict(id, r) : null;

          return (
            <article className="cand" key={id}>
              <h3>{t.name}</h3>

              <p className="mono note">
                RA {fmtRA(t.ra)} · Dec {fmtDec(t.dec)}
              </p>

              <p>{t.description}</p>
              <p className="verdict">{lookFor(id)}</p>

              <p className="note">
                {r ? `${r.visits} visits · tracked in ${r.marks.length}` : 'measuring…'}
              </p>

              {v && (
                <p>
                  Proper motion (″/yr):
                  <span className={v.ok ? 'ok' : 'bad'}>{v.ok ? '✓' : '✗'}</span>
                  {' '}
                  <span className="mono">{v.text}</span>
                </p>
              )}

              {r?.phot && (
                <p className="note">
                  Brightness change first → last visit: {r.phot.pct.toFixed(0)}%
                  ({r.phot.z.toFixed(1)}σ)
                  {Math.abs(r.phot.z) > 5 ? ' · variable' : ''}
                </p>
              )}

              <div className="row">
                <Link className="btn pri" to={`/?target=${id}&fov=10`}>Explorer</Link>
                <Link className="btn" to={`/measure?target=${id}&auto=1`}>Measure</Link>
                <Link className="btn" to={`/spectrum?target=${id}`}>Spectrum</Link>
              </div>
            </article>
          );
        })}
      </div>

      <p className="note" style={{ marginTop: 16 }}>
        The test checks whether the pipeline recovers the expected motion. WISE 0855 uses the 3.8–5 µm arrays because it is nearly invisible at shorter wavelengths.
      </p>
    </ScreenShell>
  );
}