import { useEffect, useRef } from 'react';
import type { PointerEvent } from 'react';
import { applyStretch } from '../exploration/demoData';
import type { Cutout } from '../data/dataSource';

export type Ring = { x: number; y: number; color: string; r?: number; dashed?: boolean; label?: string };
type Props = {
  cut: Cutout; stretch: { lo: number; hi: number }; palette: 'default' | 'cvd'; size?: number; crop?: { x0: number; y0: number; n: number };
  rings?: Ring[]; onPick?: (x: number, y: number) => void; onHover?: (p: { x: number; y: number } | null) => void; caption?: string; active?: boolean;
};
/** One cutout drawn to a canvas, optionally cropped, with ring markers in pixel coordinates. Click -> pixel coordinates in the cutout. */
export function Thumb({ cut, stretch, palette, size = 168, crop, rings = [], onPick, onHover, caption, active }: Props) {
  const cv = useRef<HTMLCanvasElement>(null);
  const c0 = crop ?? { x0: 0, y0: 0, n: Math.max(cut.w, cut.h) };
  useEffect(() => {
    const c = cv.current, ctx = c?.getContext('2d'); if (!c || !ctx) return;
    const img = ctx.createImageData(c0.n, c0.n);
    for (let y = 0; y < c0.n; y++) for (let x = 0; x < c0.n; x++) {
      const sx = c0.x0 + x, sy = c0.y0 + y, o = (y * c0.n + x) * 4;
      if (sx < 0 || sy < 0 || sx >= cut.w || sy >= cut.h) { img.data[o + 3] = 255; img.data[o] = 6; img.data[o + 1] = 10; img.data[o + 2] = 18; continue; }
      const v = applyStretch(cut.data[sy * cut.w + sx], stretch.lo, stretch.hi);
      if (palette === 'cvd') { img.data[o] = 255 * Math.min(1, Math.max(0, (v - 0.35) * 1.8)); img.data[o + 1] = 255 * Math.min(1, v * 1.1); img.data[o + 2] = 255 * Math.min(1, Math.max(0, 0.45 + v * 0.55 - v * v * 0.9)); }
      else { img.data[o] = 255 * Math.min(1, v * 1.5); img.data[o + 1] = 255 * Math.min(1, Math.max(0, v * 1.25 - 0.1)); img.data[o + 2] = 255 * Math.min(1, Math.max(0, v * 1.5 - 0.45)); }
      img.data[o + 3] = 255;
    }
    ctx.putImageData(img, 0, 0);
  }, [cut, stretch, palette, c0.x0, c0.y0, c0.n]);
  const at = (e: PointerEvent<HTMLDivElement>) => { const r = e.currentTarget.getBoundingClientRect(); return { x: c0.x0 + ((e.clientX - r.left) / r.width) * c0.n, y: c0.y0 + ((e.clientY - r.top) / r.height) * c0.n }; };
  const k = size / c0.n;
  return (
    <figure className={`thumb ${active ? 'on' : ''}`} style={{ width: size }}>
      <div className="thumb-box" style={{ width: size, height: size }} onPointerDown={(e) => onPick?.(at(e).x, at(e).y)} onPointerMove={(e) => onHover?.(at(e))} onPointerLeave={() => onHover?.(null)}>
        <canvas ref={cv} width={c0.n} height={c0.n} style={{ width: size, height: size }} />
        <svg viewBox={`0 0 ${size} ${size}`} width={size} height={size} aria-hidden="true">
          {rings.map((r, i) => { const cx = (r.x - c0.x0 + 0.5) * k, cy = (r.y - c0.y0 + 0.5) * k; return cx < -10 || cy < -10 || cx > size + 10 || cy > size + 10 ? null : <g key={i}><circle cx={cx} cy={cy} r={(r.r ?? 3.2) * k} fill="none" stroke={r.color} strokeWidth="1.6" strokeDasharray={r.dashed ? '3 3' : undefined} />{r.label && <text x={cx + (r.r ?? 3.2) * k + 3} y={cy - 3} fontSize="10" fill={r.color}>{r.label}</text>}</g>; })}
        </svg>
      </div>
      {caption && <figcaption>{caption}</figcaption>}
    </figure>
  );
}
