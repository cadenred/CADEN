import { ScreenShell } from './ScreenShell';
import { useManifest } from '../data/useManifest';
import { activeSource } from '../data/dataSource';

const COVER: [string, string, string][] = [
  ['Enter RA/Dec and see a series of images like a video', 'Search by name or coordinates, play/step/speed controls, timeline of every visit', 'Explorer'],
  ['Test on the five named targets', 'One-click cards with what to look for and an automatic literature check', 'Test targets'],
  ['Easy to update with new data releases', 'DataSource adapter + versioned manifest + “new data release” badge', 'About (below)'],
  ['Show the 102 bands creatively; per-array co-adds; spectra on the fly', 'All / per-array / single-band co-add, click-a-pixel spectrum with ice/molecule markers and blackbody readout', 'Explorer, Spectrum'],
  ['Add or subtract images from different times', 'Single / co-add / difference modes with detections', 'Explorer, Inject test'],
  ['Choose the field of view', '2′–30′ slider with download-size estimate and a data-saver preset', 'Explorer, Settings'],
  ['Overlay Gaia and WISE', 'Catalogue overlays with proper-motion propagation to the observation date', 'Explorer'],
  ['Query by URL and embed', 'Every view lives in the address; embed=1 hides controls; copy-iframe button', 'Explorer'],
  ['Display metadata like contamination flags', 'Flag layer (hot pixels, cosmic rays, halos, edges) and visit/survey cadence', 'Explorer, Exposures'],
  ['Use Aladin / astronomy tools', 'Aladin Lite real-sky panel with synced cursor, CDS Sesame name lookup, tangent-plane (TAN) projection', 'Real sky'],
  ['Find new moving objects (the point of the challenge)', 'Proper-motion + parallax fit, candidate cards with CSV export, distant-object (Planet X-like) search, injection tests', 'Measure, Candidates, Inject test'],
];
export function AboutPage() {
  const { manifest, isNew, markSeen } = useManifest();
  return (
    <ScreenShell title="About LumenX" lead="A public tool for spotting how the infrared sky changes, built for the NASA Space Apps Challenge “Planet X and SPHEREx”.">
      <div className="panel"><h3>Status</h3>
        <p>Data pipeline{manifest && <> · version <span className="mono">{manifest.version}</span> · updated {manifest.updated}</>} {isNew && <button className="btn pri" onClick={markSeen}>New data release — mark as seen</button>}</p></div>
      <h2>How this answers the brief</h2>
      <div className="panel tbl-wrap"><table className="tbl"><thead><tr><th>Challenge text</th><th>What LumenX does</th><th>Where</th></tr></thead><tbody>{COVER.map((c) => <tr key={c[0]}><td>{c[0]}</td><td>{c[1]}</td><td>{c[2]}</td></tr>)}</tbody></table></div>
      <h2>Updating with new releases</h2>
      <div className="panel release-panel">
        <div className="release-flow" aria-label="Release pipeline">
          <article className="release-stage">
            <span className="release-index">01</span>
            <h3>Data source</h3>
            <p>Observation files and release manifest</p>
          </article>
          <span className="release-arrow" aria-hidden="true">→</span>
          <article className="release-stage">
            <span className="release-index">02</span>
            <h3>Data adapter</h3>
            <p>Visits, image cutouts, catalogues and spectra</p>
          </article>
          <span className="release-arrow" aria-hidden="true">→</span>
          <article className="release-stage">
            <span className="release-index">03</span>
            <h3>Frame engine</h3>
            <p>Co-adds, difference images and colour output</p>
          </article>
          <span className="release-arrow" aria-hidden="true">→</span>
          <article className="release-stage">
            <span className="release-index">04</span>
            <h3>LumenX screens</h3>
            <p>Explorer, Measure, Spectrum and analysis tools</p>
          </article>
        </div>
        <p className="note release-note">A release updates the manifest and the files served through the adapter. Viewers can see when a newer release is available.</p>
      </div>
      <h2>Model notes</h2>
      <div className="panel"><ul className="note">
        <li><b>Cadence.</b> Visit dates follow a survey model: one pass per six months near the ecliptic (so about three by late 2026), many more near the ecliptic poles.</li>
        <li><b>Exposures.</b> Each exposure samples a thin slice of wavelengths; see the Exposures screen. The ordering follows the survey cadence model.</li>
        <li><b>Projection.</b> Pixel↔sky uses a tangent-plane (TAN) projection like a FITS WCS header, not a flat approximation.</li>
        <li><b>Real sky references.</b> Aladin Lite and Sesame come from CDS Strasbourg and need an internet connection.</li>
      </ul></div>
    </ScreenShell>
  );
}
