import { useEffect, useMemo, useState } from 'react';
import { ScreenShell } from './ScreenShell';
import { Thumb } from './Thumb';
import { XYPlot, Legend } from './plots';
import type { Series } from './plots';
import { useTarget } from './useTarget';
import { TARGETS, ARRAY_EDGES, sourceFlux, BANDS } from '../exploration/demoData';
import type { SpectrumPoint } from '../exploration/demoData';
import { activeSource } from '../data/dataSource';
import { FEATURES, fitBlackbody, bbShape, readout } from '../data/spectralFeatures';
import { download } from '../analysis/candidates';
import { loadCuts } from '../analysis/pipeline';
import { fmtWV } from '../exploration/format';
import { usePrefs } from '../../app/prefs';

const ARR_COL = ['#7fd3ff', '#5ef2d0', '#b6f06b', '#f2d54a', '#ff9a55', '#ff6b8a'];
const TEMPLATE = TARGETS.find((t) => t.id === 'epsindib')!.spec;

export function SpectrumPage() {
  const { def, ref, fov, sp, set, pick } = useTarget('epsindib'), { palette } = usePrefs();
  const [visits, setVisits] = useState<string[]>([]);
  const [visit, setVisit] = useState(0);
  const [view, setView] = useState<Awaited<ReturnType<typeof loadCuts>> | null>(null);
  const [spec, setSpec] = useState<SpectrumPoint[] | null>(null);
  const [show, setShow] = useState({ markers: true, bb: true, tmpl: true });

  const px = sp.get('x') !== null ? Number(sp.get('x')) : null;
  const py = sp.get('y') !== null ? Number(sp.get('y')) : null;

  const [xy, setXy] = useState<{ x: number; y: number } | null>(
    px !== null && py !== null ? { x: px, y: py } : null
  );

  useEffect(() => { setXy(null); }, [def.id]);

  useEffect(() => {
    let dead = false;
    const all = BANDS.map((b) => b.index);

    loadCuts(ref, fov, all).then((d) => {
      if (dead) return;
      setView(d);
      setVisits(d.vis.map((v) => v.iso));
      setVisit((v) => Math.min(v, d.cuts.length - 1));
      setXy((p) => p ?? { x: d.cuts[0].wcs.cx, y: d.cuts[0].wcs.cy });
    });

    return () => { dead = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [def.id, fov]);

  useEffect(() => {
    if (!xy) return;

    let dead = false;

    activeSource.spectrum(ref, fov, visit, Math.round(xy.x), Math.round(xy.y))
      .then((s) => { if (!dead) setSpec(s); });

    return () => { dead = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [def.id, fov, visit, xy?.x, xy?.y]);

  const pts = useMemo(
    () => (spec ?? []).map((s) => ({ lam: s.lam, flux: s.flux, err: s.err, array: s.array })),
    [spec]
  );

  const bb = useMemo(() => (pts.length ? fitBlackbody(pts) : null), [pts]);
  const snr = pts.length ? Math.max(...pts.map((p) => p.flux / p.err)) : 0;

  const tmpl = useMemo(() => {
    if (!pts.length) return null;

    const mk = {
      e0: 0, n0: 0, pmE: 0, pmN: 0, amp: 1,
      spec: TEMPLATE, isTarget: false, gaia: false, wise: false
    };

    const m = pts.map((p) => sourceFlux(mk, p.lam, 2026));
    let num = 0, den = 0;

    pts.forEach((p, i) => {
      const w = 1 / (p.err * p.err);
      num += w * p.flux * m[i];
      den += w * m[i] * m[i];
    });

    const k = den > 0 ? num / den : 0;
    return pts.map((p, i) => ({ x: p.lam, y: k * m[i] }));
  }, [pts]);

  const series: Series[] = [];

  for (let a = 0; a < 6; a++) {
    series.push({
      color: ARR_COL[a],
      r: 3,
      pts: pts.filter((p) => p.array === a).map((p) => ({
        x: p.lam,
        y: p.flux,
        ey: p.err
      }))
    });
  }

  if (show.bb && bb && bb.T) {
    series.push({
      color: '#ffffff',
      line: true,
      dots: false,
      dash: '5 4',
      pts: pts.map((p) => ({ x: p.lam, y: bb.scale * bbShape(p.lam, bb.T) }))
    });
  }

  if (show.tmpl && tmpl) {
    series.push({
      color: '#ffd37a',
      line: true,
      dots: false,
      pts: tmpl
    });
  }

  const csv = () => download(
    `spectrum-${def.id}-${xy?.x}-${xy?.y}.csv`,
    [
      'band,array,wavelength_um,flux,error',
      ...(spec ?? []).map((s) =>
        `${s.band + 1},${s.array + 1},${s.lam.toFixed(4)},${s.flux.toFixed(4)},${s.err.toFixed(4)}`
      )
    ].join('\n')
  );

  return (
    <ScreenShell
      title="Spectrum"
      lead="Click a pixel for its 102-band spectrum. SPHEREx was built to find ices and molecules, so the known features are marked; a blackbody fit turns the shape into a plain-language temperature estimate."
      wide
    >
      <div className="panel">
        <div className="row">
          <label>
            Target
            <select value={def.id} onChange={(e) => pick(TARGETS.find((x) => x.id === e.target.value)!)}>
              {TARGETS.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
            </select>
          </label>

          <label>
            Visit
            <select value={visit} onChange={(e) => setVisit(+e.target.value)}>
              {visits.map((v, i) => <option key={v} value={i}>{i + 1} · {fmtWV(v)}</option>)}
            </select>
          </label>

          <label>
            Field
            <select value={fov} onChange={(e) => set({ fov: e.target.value })}>
              {[6, 10, 15].map((f) => <option key={f} value={f}>{f}′</option>)}
            </select>
          </label>

          {(['markers', 'bb', 'tmpl'] as const).map((k) => (
            <label key={k} style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <input
                type="checkbox"
                checked={show[k]}
                onChange={(e) => setShow({ ...show, [k]: e.target.checked })}
              />
              {k === 'markers' ? 'Ice / molecule markers' : k === 'bb' ? 'Blackbody fit' : 'Brown-dwarf template'}
            </label>
          ))}

          <button className="btn" onClick={csv} disabled={!spec}>Download CSV</button>
        </div>
      </div>

      <div className="grid2">
        <div className="panel">
          <XYPlot
            series={series}
            vlines={show.markers ? FEATURES.map((f) => ({ x: f.um, label: `${f.label} ${f.um}` })) : []}
            xl="wavelength (µm)"
            yl="flux"
            h={400}
          />

          <Legend items={[
            ...ARR_COL.map((c, a) => ({
              color: c,
              label: `Array ${a + 1} (${ARRAY_EDGES[a].toFixed(2)}–${ARRAY_EDGES[a + 1].toFixed(2)} µm)`
            })),
            { color: '#fff', label: 'Blackbody', dash: true },
            { color: '#ffd37a', label: 'Brown-dwarf template (illustrative)' }
          ]} />
        </div>

        <div>
          <div className="panel">
            <h3>Choose a pixel</h3>
            {view && xy && (
              <Thumb
                cut={view.cuts[Math.min(visit, view.cuts.length - 1)]}
                stretch={view.stretch}
                palette={palette}
                size={300}
                rings={[{ x: Math.round(xy.x), y: Math.round(xy.y), color: '#fff', r: 2.5 }]}
                onPick={(x, y) => {
                  setXy({ x: Math.floor(x), y: Math.floor(y) });
                  set({ x: String(Math.floor(x)), y: String(Math.floor(y)) });
                }}
                caption={`pixel ${Math.round(xy.x)}, ${Math.round(xy.y)}`}
              />
            )}
          </div>

          <div className="panel">
            <h3>What it says</h3>
            {bb && snr > 5
              ? <p className="verdict">{readout(bb.T)}</p>
              : <p className="warnbox">This pixel is mostly background (peak S/N {snr.toFixed(1)}). Click on a source.</p>}

            {bb && (
              <p className="note">
                Blackbody χ²/dof {(bb.chi2 / bb.dof).toFixed(1)}: real objects are not perfect blackbodies, so treat the temperature as a rough guide.
              </p>
            )}

            <ul className="note">
              {FEATURES.map((f) => (
                <li key={f.id}><b>{f.label} ({f.um} µm)</b>: {f.text}</li>
              ))}
            </ul>

            <p className="note">Feature markers indicate approximate band centres for the selected molecular signatures.</p>
          </div>
        </div>
      </div>
    </ScreenShell>
  );
}