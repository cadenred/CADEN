import { useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { targetFromKey, customTargetDef, ALL_TARGETS, TARGETS } from '../exploration/demoData';
import type { TargetDef } from '../exploration/demoData';
import { refOf } from '../data/dataSource';
import { usePrefs } from '../../app/prefs';

/** Target + field of view from the page address (?target=barnard or ?ra=&dec=, &fov=). Shared by every screen. */
export function useTarget(defaultKey: string, opts: { sim?: boolean; fieldsOnly?: boolean } = {}) {
  const [sp, setSp] = useSearchParams(), { dataSaver } = usePrefs();
  const key = sp.get('target'), ra = Number(sp.get('ra')), dec = Number(sp.get('dec'));
  const def: TargetDef = useMemo(() => {
    const t = key ? targetFromKey(key) : sp.get('ra') !== null && Number.isFinite(ra) && Number.isFinite(dec) ? customTargetDef(ra, dec) : null;
    return (t && (opts.sim || !ALL_TARGETS.slice(TARGETS.length).includes(t)) ? t : null) ?? targetFromKey(defaultKey) ?? TARGETS[0];
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, sp.get('ra'), sp.get('dec')]);
  const fovParam = Number(sp.get('fov')), fov = Number.isFinite(fovParam) && fovParam >= 2 && fovParam <= 30 ? fovParam : def.id === 'planetx-sim' ? 30 : dataSaver ? 6 : 10;
  const set = (patch: Record<string, string | null>) => { const n = new URLSearchParams(sp); for (const [k, v] of Object.entries(patch)) { if (v === null) n.delete(k); else n.set(k, v); } setSp(n, { replace: true }); };
  const pick = (t: TargetDef) => set({ target: TARGETS.some((x) => x.id === t.id) || ALL_TARGETS.some((x) => x.id === t.id) ? t.id : null, ra: null, dec: null, x: null, y: null, v: null });
  return { def, ref: refOf(def), fov, sp, set, pick };
}
