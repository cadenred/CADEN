import { useEffect, useMemo, useRef, useState } from 'react';
import { ScreenShell } from './ScreenShell';
import { Thumb } from './Thumb';
import type { Ring } from './Thumb';
import { useTarget } from './useTarget';
import { TARGETS, customTargetDef, PIXEL_ARCSEC, pixelAt, renderBands, stretchOf, ALL_BANDS } from '../exploration/demoData';
import type { TargetDef, Scene } from '../exploration/demoData';
import { makeMover, withInjected, rng, detectorRecovers, sensitivityGrid, SPEEDS, FLUXES } from '../analysis/injection';
import type { Injected, Cell } from '../analysis/injection';
import type { Cutout } from '../data/dataSource';
import { fmtWV } from '../exploration/format';
import { usePrefs } from '../../app/prefs';

const FIELDS: TargetDef[] = [customTargetDef(200, 30), ...TARGETS.filter((t) => t.kind === 'field')];
const LEVELS = [['Easy', 2.4], ['Medium', 1.2], ['Hard', 0.6]] as const;
type Guess = { visit: number; x: number; y: number };
const cutOf = (sc: Scene, ep: number): Cutout => { const r = renderBands(sc, ep, ALL_BANDS); return { iso: sc.target.epochs[ep], mjd: sc.mjd[ep], w: sc.w, h: sc.h, data: r.data, sigma: r.sigma, flags: new Uint8Array(sc.w * sc.h), wcs: { ra0: sc.target.ra, dec0: sc.target.dec, cx: sc.cx, cy: sc.cy, pix: PIXEL_ARCSEC } }; };

export function InjectPage() {
  const { def, fov, set } = useTarget(FIELDS[0].id, { fieldsOnly: true }), { palette } = usePrefs();
  const field = FIELDS.find((f) => f.id === def.id) ?? FIELDS[0];
  const [level, setLevel] = useState(1), [n, setN] = useState(4), [seed, setSeed] = useState(() => 1 + Math.floor(Math.random() * 9999));
  const [visit, setVisit] = useState(0), [diff, setDiff] = useState(true), [guesses, setGuesses] = useState<Guess[]>([]), [reveal, setReveal] = useState(false);
  const [grid, setGrid] = useState<Cell[] | null>(null), [prog, setProg] = useState(0), running = useRef(false);
  const fovUse = Math.min(fov, 12);
  const { sc, movers } = useMemo(() => {
    const base = withInjected(field, fovUse, []), rnd = rng(seed), ms: Injected[] = [];
    const sp = [3, 6, 10, 16, 24];
    for (let i = 0; i < n; i++) ms.push(makeMover(rnd, base.w, sp[Math.floor(rnd() * sp.length)], LEVELS[level][1] * (0.8 + rnd() * 0.5), i));
    return { sc: withInjected(field, fovUse, ms), movers: ms };
  }, [field, fovUse, n, seed, level]);
  useEffect(() => { setGuesses([]); setReveal(false); setVisit(0); }, [field.id, fovUse, n, seed, level]);
  const nEp = sc.years.length, v = Math.min(visit, nEp - 1);
  const cut = useMemo(() => {
    const cur = cutOf(sc, v); if (!diff || nEp < 2) return cur;
    const prev = cutOf(sc, v > 0 ? v - 1 : 1), d = new Float32Array(cur.data.length); for (let i = 0; i < d.length; i++) d[i] = cur.data[i] - prev.data[i];
    return { ...cur, data: d, sigma: Math.hypot(cur.sigma, prev.sigma) };
  }, [sc, v, diff, nEp]);
  const stretch = useMemo(() => (diff ? { lo: 0, hi: cut.sigma * 7 } : stretchOf(cutOf(sc, 0).data)), [sc, diff, cut.sigma]);
  const shown = useMemo(() => { if (!diff) return cut; const d = new Float32Array(cut.data.length); for (let i = 0; i < d.length; i++) d[i] = Math.abs(cut.data[i]); return { ...cut, data: d }; }, [cut, diff]);

  const user = movers.map((m) => guesses.some((g) => { const p = pixelAt(sc, m.src, g.visit); return Math.hypot(g.x - p.x, g.y - p.y) <= 2.5; }));
  const bands = ALL_BANDS, det = useMemo(() => (reveal ? movers.map((m) => detectorRecovers(sc, m, bands)) : []), [reveal, sc, movers, bands]);
  const falsePos = guesses.filter((g) => !movers.some((m) => { const p = pixelAt(sc, m.src, g.visit); return Math.hypot(g.x - p.x, g.y - p.y) <= 2.5; })).length;
  const click = (x: number, y: number) => {
    if (reveal) return; const gx = Math.floor(x), gy = Math.floor(y), hit = guesses.findIndex((g) => g.visit === v && Math.hypot(g.x - gx, g.y - gy) <= 2);
    setGuesses(hit >= 0 ? guesses.filter((_, i) => i !== hit) : [...guesses, { visit: v, x: gx, y: gy }]);
  };
  const rings: Ring[] = [...guesses.filter((g) => g.visit === v).map((g) => ({ x: g.x, y: g.y, color: '#ffffff', r: 3 }))];
  if (reveal) movers.forEach((m, i) => { const p = pixelAt(sc, m.src, v); rings.push({ x: p.x, y: p.y, color: user[i] ? '#5ef2d0' : '#ff9a55', r: 4.5, dashed: true, label: `#${i + 1}` }); });

  const runGrid = async () => {
    if (running.current) return; running.current = true; setGrid(null); setProg(0);
    const g = await sensitivityGrid(FIELDS[0], 6, bands, 4, setProg); setGrid(g); running.current = false;
  };
  const sentence = useMemo(() => {
    if (!grid) return ''; const ok = (c: Cell) => c.hit / c.n >= 0.75, fast = grid.filter((c) => c.speed === SPEEDS[SPEEDS.length - 1] && ok(c)).map((c) => c.flux), bright = grid.filter((c) => c.flux === FLUXES[FLUXES.length - 1] && ok(c)).map((c) => c.speed);
    return `With all 102 bands co-added, the baseline detector recovers at least 75% of movers ${fast.length ? `as faint as ${Math.min(...fast)} (flux units) when they move ${SPEEDS[SPEEDS.length - 1]}″/yr` : 'only at the brightest levels tested when they move fast'}, and ${bright.length ? `as slow as ${Math.min(...bright)}″/yr at the brightest level` : 'no speed at the brightest level'}.`;
  }, [grid]);

  return (
    <ScreenShell title="Injection test" lead="Moving sources with known speeds and brightness levels are hidden in the field. Find them by blinking through the visits or switching to the difference view, then compare your results with the detector. It doubles as a sensitivity measurement." wide>
      <div className="panel"><div className="row">
        <label>Field<select value={field.id} onChange={(e) => set({ target: e.target.value, ra: null, dec: null })}>{FIELDS.map((f) => <option key={f.id} value={f.id}>{f.id.startsWith('custom') ? 'Empty field' : f.name}</option>)}</select></label>
        <label>Difficulty<select value={level} onChange={(e) => setLevel(+e.target.value)}>{LEVELS.map((l, i) => <option key={l[0]} value={i}>{l[0]}</option>)}</select></label>
        <label>Hidden movers<select value={n} onChange={(e) => setN(+e.target.value)}>{[2, 3, 4, 6, 8].map((k) => <option key={k}>{k}</option>)}</select></label>
        <label>Challenge code<input type="number" value={seed} onChange={(e) => setSeed(+e.target.value || 1)} style={{ width: 100 }} /></label>
        <button className="btn" onClick={() => setSeed(1 + Math.floor(Math.random() * 9999))}>New challenge</button>
      </div></div>
      <div className="grid2">
        <div className="panel">
          <div className="row"><button className={`btn ${diff ? 'pri' : ''}`} onClick={() => setDiff(!diff)}>{diff ? 'Difference view' : 'Image view'}</button>
            <label style={{ flex: 1 }}>Visit {v + 1} of {nEp} · {fmtWV(sc.target.epochs[v])}<input type="range" min={0} max={nEp - 1} value={v} onChange={(e) => setVisit(+e.target.value)} /></label></div>
          <Thumb cut={shown} stretch={stretch} palette={palette} size={Math.min(640, Math.max(320, Math.floor(window.innerWidth * 0.42)))} rings={rings} onPick={click} caption={diff ? 'brightness of (this visit − previous visit): movers appear as pairs' : 'click to mark a suspected mover'} />
          <div className="row"><button className="btn pri" onClick={() => setReveal(true)} disabled={reveal || !guesses.length}>Check my guesses</button><span className="note">{guesses.length} marked · click a mark again to remove it</span></div>
        </div>
        <div className="panel">
          <h3>Score</h3>
          {!reveal ? <p className="note">Mark every spot where something looks like it moved. Marks are checked against the hidden positions at the visit you marked them.</p> : (<>
            <div className="stat"><div><b>{user.filter(Boolean).length} / {n}</b><span>found by you</span></div><div><b>{det.filter((d) => d.found).length} / {n}</b><span>found by the detector</span></div><div><b>{falsePos}</b><span>false marks</span></div></div>
            <div className="tbl-wrap"><table className="tbl"><thead><tr><th>#</th><th className="num">Speed</th><th className="num">Flux</th><th>You</th><th>Detector</th></tr></thead><tbody>
              {movers.map((m, i) => <tr key={i}><td>{i + 1}</td><td className="num">{m.speed}″/yr</td><td className="num">{m.meanFlux.toFixed(2)}</td><td className={user[i] ? 'ok' : 'bad'}>{user[i] ? 'found' : 'missed'}</td><td className={det[i]?.found ? 'ok' : 'bad'}>{det[i]?.found ? 'found' : 'missed'}</td></tr>)}
            </tbody></table></div>
            <button className="btn" onClick={() => setSeed(1 + Math.floor(Math.random() * 9999))}>Try another</button></>)}
        </div>
      </div>
      <div className="panel"><h3>Detector sensitivity</h3>
        <p className="note">Injects one mover at a time on a 6′ empty field (4 trials per cell, all 102 bands) and asks whether the baseline difference-over-noise detector finds it. This measures detector sensitivity across the selected noise and brightness settings.</p>
        <button className="btn pri" onClick={runGrid} disabled={prog > 0 && prog < 1}>{prog > 0 && prog < 1 ? `Running… ${(prog * 100).toFixed(0)}%` : 'Measure sensitivity'}</button>
        {grid && <><div className="heat" style={{ gridTemplateColumns: `90px repeat(${SPEEDS.length}, 1fr)`, marginTop: 12 }}>
          <div />{SPEEDS.map((s) => <div key={s}>{s}″/yr</div>)}
          {[...FLUXES].reverse().map((f) => [<div key={'l' + f}>flux {f}</div>, ...SPEEDS.map((s) => { const c = grid.find((g) => g.speed === s && g.flux === f)!, p = c.hit / c.n; return <div key={f + '-' + s} style={{ background: `rgba(94,242,208,${0.08 + p * 0.7})`, color: p > 0.5 ? '#04121a' : '#cfe0f5' }}>{(p * 100).toFixed(0)}%</div>; })])}
        </div><p className="verdict">{sentence}</p></>}
      </div>
    </ScreenShell>
  );
}