import { useEffect, useMemo, useState } from 'react';
import { ScreenShell } from './ScreenShell';
import { XYPlot, Legend } from './plots';
import type { Series } from './plots';
import { useTarget } from './useTarget';
import { TARGETS, PIXEL_ARCSEC, ARRAY_EDGES } from '../exploration/demoData';
import { activeSource } from '../data/dataSource';
import { exposureSchedule, visitsPerSurvey, eclipticOf, surveyOf } from '../exploration/cadence';
import { fmtWV } from '../exploration/format';

const ARR_COL = ['#7fd3ff', '#5ef2d0', '#b6f06b', '#f2d54a', '#ff9a55', '#ff6b8a'];

const PRESETS: { name: string; rate: number; note: string }[] = [
  { name: 'Barnard’s Star', rate: 10.4 / 365.25, note: '10.4″/yr' },
  { name: 'WISE 0855−0714', rate: 8.15 / 365.25, note: '8.2″/yr' },
  { name: 'Planet X-like at 500 AU (parallax)', rate: (412 * 2 * Math.PI) / 365.25, note: 'up to ≈7″/day' },
  { name: 'Main-belt asteroid', rate: 600, note: '≈600″/day' },
];

export function ExposuresPage() {
  const { def, ref, pick } = useTarget('barnard');

  const [visits, setVisits] = useState<{ iso: string; survey: number }[]>([]);
  const [vi, setVi] = useState(0);
  const [rate, setRate] = useState(Math.log10(8.15 / 365.25));

  useEffect(() => {
    let dead = false;

    activeSource.visits(ref).then((v) => {
      if (!dead) {
        setVisits(v);
        setVi(0);
      }
    });

    return () => { dead = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [def.id]);

  const iso = visits[vi]?.iso ?? '2025-05-01';
  const sched = useMemo(() => exposureSchedule(iso), [iso]);
  const span = Math.max(...sched.map((s) => s.dayOffset));

  const ecl = eclipticOf(def.ra, def.dec);
  const perSurvey = visitsPerSurvey(ecl.lat);
  const v = Math.pow(10, rate);

  const timeline: Series[] = ARR_COL.map((c, a) => ({
    color: c,
    r: 3.4,
    pts: sched
      .filter((s) => s.array === a)
      .map((s) => ({
        x: s.dayOffset,
        y: ARRAY_EDGES[a] * Math.pow(
          ARRAY_EDGES[a + 1] / ARRAY_EDGES[a],
          ((s.band % 17) + 0.5) / 17
        )
      }))
  }));

  const drift: Series[] = [
    {
      color: '#5ef2d0',
      line: true,
      r: 2.4,
      pts: sched.map((s) => ({
        x: s.dayOffset,
        y: v * s.dayOffset
      }))
    },
    {
      color: '#ffb86b',
      line: true,
      dots: false,
      dash: '5 4',
      pts: [
        { x: 0, y: PIXEL_ARCSEC },
        { x: span, y: PIXEL_ARCSEC }
      ]
    }
  ];

  return (
    <ScreenShell
      title="Exposures in time order"
      lead="The viewer blinks whole visits, but SPHEREx does not see all 102 bands at once. Each exposure samples a thin slice of wavelengths, so one position’s spectrum is assembled over days. That barely matters for a star, and matters a lot for something fast."
      wide
    >
      <div className="panel">
        <div className="row">
          <label>
            Target
            <select
              value={def.id}
              onChange={(e) => pick(TARGETS.find((x) => x.id === e.target.value)!)}
            >
              {TARGETS.map((x) => (
                <option key={x.id} value={x.id}>{x.name}</option>
              ))}
            </select>
          </label>

          <label>
            Visit
            <select value={vi} onChange={(e) => setVi(+e.target.value)}>
              {visits.map((x, i) => (
                <option key={x.iso} value={i}>
                  {i + 1} · {fmtWV(x.iso)} · survey {surveyOf(x.iso)}
                </option>
              ))}
            </select>
          </label>
        </div>

        <p className="note">
          Ecliptic latitude {ecl.lat.toFixed(1)}° → about {perSurvey} visit
          {perSurvey > 1 ? 's' : ''} per six-month survey (near the ecliptic poles
          the deep fields are revisited far more often). The sequence below
          illustrates how the exposure order determines wavelength coverage across visits.
        </p>
      </div>

      <div className="grid2">
        <div className="panel">
          <h3>Which wavelength is seen when (one pass)</h3>

          <XYPlot
            series={timeline}
            xl="days since the first exposure of this pass"
            yl="wavelength (µm)"
            h={340}
          />

          <Legend items={ARR_COL.map((c, a) => ({
            color: c,
            label: `Array ${a + 1}`
          }))} />

          <p className="note">
            Arrays 1–3 and 4–6 look at the field together; each steps through its
            17 channels. The full spectrum needs the whole {span.toFixed(0)}-day window.
          </p>
        </div>

        <div className="panel">
          <h3>How far a mover travels during that pass</h3>

          <div className="row">
            <label style={{ flex: 1 }}>
              Speed: {v >= 1 ? v.toFixed(1) : v.toFixed(3)}″ per day
              <input
                type="range"
                min={-3}
                max={3.2}
                step={0.05}
                value={rate}
                onChange={(e) => setRate(+e.target.value)}
              />
            </label>
          </div>

          <XYPlot
            series={drift}
            xl="days since the first exposure"
            yl="distance moved (″)"
            h={300}
          />

          <p className={v * span > PIXEL_ARCSEC ? 'warnbox' : 'verdict'}>
            {v * span > PIXEL_ARCSEC
              ? `It moves ${(v * span).toFixed(0)}″ (${((v * span) / PIXEL_ARCSEC).toFixed(1)} pixels) during the pass, so different bands land on different pixels: a single pixel cannot give its spectrum.`
              : `It moves only ${(v * span).toFixed(2)}″ during the pass (under one ${PIXEL_ARCSEC}″ pixel), so all bands see it in the same pixel.`}
          </p>

          <p className="note">Dashed line = one pixel.</p>
        </div>
      </div>

      <div className="panel tbl-wrap">
        <h3>Typical objects</h3>

        <table className="tbl">
          <thead>
            <tr>
              <th>Object</th>
              <th className="num">Rate</th>
              <th className="num">Moved in pass</th>
              <th>Consequence</th>
            </tr>
          </thead>

          <tbody>
            {PRESETS.map((p) => {
              const d = p.rate * span;

              return (
                <tr key={p.name}>
                  <td>{p.name}</td>
                  <td className="num">{p.note}</td>
                  <td className="num">
                    {d.toFixed(2)}″ ({(d / PIXEL_ARCSEC).toFixed(2)} px)
                  </td>
                  <td>
                    {d < PIXEL_ARCSEC
                      ? 'Stays in one pixel for the whole pass.'
                      : 'Spectrum is smeared across pixels; track it exposure by exposure.'}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </ScreenShell>
  );
}