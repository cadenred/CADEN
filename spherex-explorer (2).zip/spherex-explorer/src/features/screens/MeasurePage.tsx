import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { ScreenShell } from './ScreenShell';
import { Thumb } from './Thumb';
import type { Ring } from './Thumb';
import { XYPlot, Legend } from './plots';
import type { Series } from './plots';
import { useTarget } from './useTarget';
import { TARGETS, SIM_TARGETS, buildScene, pixelAt } from '../exploration/demoData';
import { fmtRA, fmtDec, fmtWV } from '../exploration/format';
import { activeSource } from '../data/dataSource';
import { KNOWN, totalPm } from '../data/knownValues';
import { bandsOf, bandSetLabel, loadCuts, photometryChange, fluxCurve } from '../analysis/pipeline';
import type { BandSet } from '../analysis/pipeline';
import { centroidAt, findPeak, trackFrom, scanDistances, fitMotion, marksToPoints, modelAt, dominance } from '../analysis/astrometry';
import type { Mark } from '../analysis/astrometry';
import { addCandidate, classify } from '../analysis/candidates';
import type { Candidate } from '../analysis/candidates';
import { usePrefs } from '../../app/prefs';
import { useT } from '../../app/i18n';

const mjdOfYear = (y: number) => 51544.5 + (y - 2000) * 365.25;

export function MeasurePage() {
  const { def, ref, fov, sp, set, pick } = useTarget('wise0855', { sim: true }), { palette } = usePrefs(), t = useT();
  const [bandSet, setBandSet] = useState<BandSet>(KNOWN[def.id]?.bands === 'long' ? 'long' : 'all');
  const [data, setData] = useState<Awaited<ReturnType<typeof loadCuts>> | null>(null);
  const [marks, setMarks] = useState<Mark[]>([]);
  const [mode, setMode] = useState<'local' | 'distant'>(def.id === 'planetx-sim' ? 'distant' : 'local');
  const [wide, setWide] = useState(def.id === 'planetx-sim');
  const [dist, setDist] = useState<number | null>(null);
  const [cat, setCat] = useState({ gaia: false, wise: false });
  const [toast, setToast] = useState(''), [busy, setBusy] = useState(false);

  useEffect(() => {
    setBandSet(KNOWN[def.id]?.bands === 'long' ? 'long' : 'all');
    setMode(def.id === 'planetx-sim' ? 'distant' : 'local');
    setWide(def.id === 'planetx-sim');
  }, [def.id]);

  const bands = useMemo(() => bandsOf(bandSet), [bandSet]);

  useEffect(() => {
    let dead = false;
    setData(null);
    setMarks([]);
    setDist(null);
    setBusy(true);

    loadCuts(ref, fov, bands).then((d) => {
      if (!dead) {
        setData(d);
        setBusy(false);
      }
    });

    return () => { dead = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [def.id, fov, bandSet]);

  const startTrack = (visit: number, x: number, y: number, m = mode) => {
    if (!data) return;

    if (m === 'distant') {
      const r = scanDistances(data.cuts, { visit, x, y });
      setMarks(r.marks);
      setDist(r.distAU);

      if (r.found < data.cuts.length) {
        setToast(`Distance scan found the object in ${r.found} of ${data.cuts.length} visits only.`);
      }
    } else {
      setDist(null);
      setMarks(trackFrom(data.cuts, { visit, x, y }));
    }
  };

  useEffect(() => {
    if (!data || marks.length) return;

    const x = Number(sp.get('x'));
    const y = Number(sp.get('y'));
    const v = Number(sp.get('v') ?? 1) - 1;

    if (sp.get('x') !== null && Number.isFinite(x) && Number.isFinite(y)) {
      startTrack(Math.max(0, Math.min(data.cuts.length - 1, v)), x, y, 'local');
    } else if (sp.get('auto') === '1') {
      startTrack(0, data.cuts[0].wcs.cx, data.cuts[0].wcs.cy, 'local');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data]);

  const onPick = (visit: number, x: number, y: number) => {
    if (!data) return;
    if (!marks.length) return startTrack(visit, x, y);

    const pk = findPeak(data.cuts[visit], x, y, 2);
    const ce = pk ? centroidAt(data.cuts[visit], pk.x, pk.y) : null;

    if (!ce) return setToast('No source found there.');

    const m: Mark = {
      visit,
      x: ce.x,
      y: ce.y,
      sx: ce.sx,
      sy: ce.sy,
      snr: ce.snr,
      manual: true
    };

    setMarks([...marks.filter((k) => k.visit !== visit), m].sort((a, b) => a.visit - b.visit));
  };

  const pts = useMemo(() => (data ? marksToPoints(data.cuts, marks) : []), [data, marks]);
  const lin = useMemo(() => fitMotion(pts, false), [pts]);
  const par = useMemo(() => (pts.length >= 3 ? fitMotion(pts, true) : null), [pts]);
  const dom = lin ? dominance(lin, par) : null;
  const best = par && pts.length >= 3 ? par : lin;
  const phot = useMemo(() => (data && marks.length > 1 ? photometryChange(data.cuts, marks) : null), [data, marks]);
  const flux = useMemo(() => (data ? fluxCurve(data.cuts, marks) : []), [data, marks]);
  const cls = classify(par ?? lin);
  const known = KNOWN[def.id];

  useEffect(() => {
    if (!data || !marks.length) {
      setCat({ gaia: false, wise: false });
      return;
    }

    const last = marks[marks.length - 1];
    let dead = false;

    Promise.all(
      (['gaia', 'wise'] as const).map((w) =>
        activeSource.catalogue(ref, fov, w, last.visit, true)
      )
    ).then(([g, w]) => {
      const near = (l: { x: number; y: number }[]) =>
        l.some((c) => Math.hypot(c.x - last.x, c.y - last.y) < 2);

      if (!dead) setCat({ gaia: near(g), wise: near(w) });
    });

    return () => { dead = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, marks]);

  const series: Series[] = useMemo(() => {
    if (!pts.length || !best) return [];

    const y0 = pts[0].year;
    const y1 = pts[pts.length - 1].year + 2;

    const line = (f: typeof best, extra: boolean) => {
      const out: { x: number; y: number }[] = [];

      for (let y = y0; y <= (extra ? y1 : y1 - 2); y += 0.03) {
        const m = modelAt(f, y, mjdOfYear(y), pts[0].ra, pts[0].dec);
        out.push({ x: m.e, y: m.n });
      }

      return out;
    };

    const s: Series[] = [{
      pts: pts.map((p) => ({ x: p.e, y: p.n, ex: p.se, ey: p.sn })),
      color: '#5ef2d0',
      r: 4,
      label: 'Measured positions'
    }];

    if (lin) {
      s.push({
        pts: line(lin, true),
        color: '#ffb86b',
        line: true,
        dots: false,
        dash: '6 5',
        label: 'Straight-line fit, extended 2 yr'
      });
    }

    if (par) {
      s.push({
        pts: line(par, false),
        color: '#b6f06b',
        line: true,
        dots: false,
        label: 'Motion + parallax fit'
      });
    }

    return s;
  }, [pts, lin, par, best]);

  const first = marks[0];

  const crop = data && first
    ? (wide
      ? { x0: 0, y0: 0, n: Math.max(data.cuts[0].w, data.cuts[0].h) }
      : { x0: Math.round(first.x) - 20, y0: Math.round(first.y) - 20, n: 41 })
    : undefined;

  const ringsFor = (v: number): Ring[] => {
    const r: Ring[] = [];
    const m = marks.find((k) => k.visit === v);

    if (m) {
      r.push({
        x: m.x,
        y: m.y,
        color: m.manual ? '#ffffff' : '#5ef2d0',
        r: wide ? 5 : 3
      });
    }

    if (best && data && pts.length) {
      const c = data.cuts[v];
      const p = modelAt(
        best,
        2000 + (c.mjd - 51544.5) / 365.25,
        c.mjd,
        pts[0].ra,
        pts[0].dec
      );

      r.push({
        x: c.wcs.cx - p.e / c.wcs.pix,
        y: c.wcs.cy - p.n / c.wcs.pix,
        color: '#ffb86b',
        dashed: true,
        r: wide ? 7 : 4.5
      });
    }

    return r;
  };

  const save = () => {
    if (!best || !data || !first) return;

    const p0 = pts[0];
    const id = `${def.id}-${Math.round(p0.ra * 1e4)}-${Math.round(p0.dec * 1e4)}`;
    const link = `/measure?target=${def.id}&fov=${fov}&x=${first.x.toFixed(2)}&y=${first.y.toFixed(2)}&v=${first.visit + 1}`;

    const c: Candidate = {
      id,
      created: new Date().toISOString().slice(0, 10),
      targetKey: def.id,
      name: `${def.name} @ ${fmtRA(p0.ra)} ${fmtDec(p0.dec)}`,
      ra: p0.ra,
      dec: p0.dec,
      fov,
      visits: marks.length,
      pm: best.pm,
      pmErr: best.errPm,
      pmE: best.pmE,
      pmN: best.pmN,
      pa: best.pa,
      plx: par?.plx ?? 0,
      plxErr: par?.errPlx ?? 0,
      cls,
      inGaia: cat.gaia,
      inWise: cat.wise,
      flux: phot,
      link,
      note: ''
    };

    addCandidate(c);
    setToast('Saved to your candidates.');
  };

  const copy = () => {
    navigator.clipboard?.writeText(
      window.location.origin +
      `/measure?target=${def.id}&fov=${fov}${first ? `&x=${first.x.toFixed(2)}&y=${first.y.toFixed(2)}&v=${first.visit + 1}` : ''}`
    ).then(
      () => setToast('Link copied'),
      () => setToast('Copy failed')
    );
  };

  const simStart = () => {
    if (!data) return;

    const sc = buildScene(def, fov);
    const tg = sc.sources.find((x) => x.isTarget);

    if (tg) {
      const q = pixelAt(sc, tg, 0);
      startTrack(0, q.x, q.y, 'distant');
    }
  };

  return (
    <ScreenShell
      title="Measure motion"
      lead="Click the object once: the tool follows it through every visit, fits a straight line and a parallax ellipse, and compares the result with the catalogue. Click a visit again to correct its position."
      wide
    >
      <div className="panel">
        <div className="row">
          <label>
            Target
            <select
              value={def.id}
              onChange={(e) => pick([...TARGETS, ...SIM_TARGETS].find((x) => x.id === e.target.value)!)}
            >
              {[...TARGETS.filter((x) => x.group === 'test'), ...SIM_TARGETS].map((x) => (
                <option key={x.id} value={x.id}>{x.name}</option>
              ))}
            </select>
          </label>

          <label>
            Field of view
            <select value={fov} onChange={(e) => set({ fov: e.target.value })}>
              {[6, 10, 15, 20, 30].map((f) => (
                <option key={f} value={f}>{f}′</option>
              ))}
            </select>
          </label>

          <label>
            Bands co-added
            <select value={bandSet} onChange={(e) => setBandSet(e.target.value as BandSet)}>
              {(['all', 'long', 'a0', 'a1', 'a2', 'a3', 'a4', 'a5'] as BandSet[]).map((b) => (
                <option key={b} value={b}>{bandSetLabel(b)}</option>
              ))}
            </select>
          </label>

          <label>
            Search
            <select value={mode} onChange={(e) => setMode(e.target.value as 'local' | 'distant')}>
              <option value="local">Nearby mover (local search)</option>
              <option value="distant">Distant object (parallax scan)</option>
            </select>
          </label>

          <label>
            View
            <select value={wide ? 'wide' : 'tight'} onChange={(e) => setWide(e.target.value === 'wide')}>
              <option value="tight">Close-up (41 px)</option>
              <option value="wide">Whole field</option>
            </select>
          </label>

          <button className="btn" onClick={() => { setMarks([]); setDist(null); }}>Clear</button>
        </div>

        {def.id === 'planetx-sim' && (
          <p className="note">
            Planet X scenario: a body at 500 AU is placed at a known starting position. Press the button to start from its injected position in the first visit (a real search would start from a candidate click); the tool then scans 20–5000 AU for the parallax track that lands on a source in every visit.
          </p>
        )}

        {def.id === 'planetx-sim' && (
          <button className="btn pri" onClick={simStart} disabled={!data}>
            Start from injected position and scan distances
          </button>
        )}

        <p className="note">
          {data
            ? `${data.cuts.length} visits · ${bandSetLabel(bandSet)} · ${data.cuts[0]?.w}×${data.cuts[0]?.h} px at ${data.cuts[0]?.wcs.pix}″`
            : busy ? 'Loading visits…' : ''}
          {!marks.length && data ? ' · Click the object in any visit to start.' : ''}
        </p>
      </div>

      <div className="thumbs">
        {data?.cuts.map((c, v) => (
          <Thumb
            key={v}
            cut={c}
            stretch={data.stretch}
            palette={palette}
            size={wide ? 220 : 176}
            crop={crop}
            rings={ringsFor(v)}
            onPick={(x, y) => onPick(v, x, y)}
            caption={`${v + 1}. ${fmtWV(c.iso)}${marks.some((m) => m.visit === v) ? ' ●' : ''}`}
          />
        ))}
      </div>

      <p className="note">
        Teal ring = measured centroid (white = corrected by you). Dashed amber ring = where the fit says the object should be.
      </p>

      {best && lin && (
        <div className="grid2">
          <div>
            <div className="panel">
              <h3>Result</h3>

              <div className="stat">
                <div><b>{best.pm.toFixed(3)}″/yr</b><span>total proper motion ± {best.errPm.toFixed(3)}</span></div>
                <div><b>{best.pa.toFixed(0)}°</b><span>direction (N through E)</span></div>
                <div><b>{best.pmE.toFixed(3)} / {best.pmN.toFixed(3)}</b><span>μα* / μδ (″/yr)</span></div>

                {par && (
                  <div>
                    <b>{Math.abs(par.plx).toFixed(3)}″ ± {par.errPlx.toFixed(3)}</b>
                    <span>
                      parallax
                      {Math.abs(par.plx) > 1
                        ? ` · ≈ ${(206265 / Math.abs(par.plx)).toFixed(0)} AU away`
                        : par.plx > 0.01 ? ` · ≈ ${(1 / par.plx).toFixed(1)} pc` : ''}
                    </span>
                  </div>
                )}

                {dist && <div><b>{dist.toFixed(0)} AU</b><span>best-scan distance</span></div>}
              </div>

              {dom && <p className="verdict">{dom.verdict}</p>}

              <p>
                <span className="badge">{cls}</span>
                {cat.gaia && <span className="badge">in Gaia</span>}
                {cat.wise && <span className="badge">in WISE</span>}
                {!cat.gaia && !cat.wise && <span className="badge amber">not listed in Gaia or WISE</span>}
              </p>

              {phot && (
                <p className="note">
                  Brightness, first → last visit: {phot.first.toFixed(2)} → {phot.last.toFixed(2)}
                  (ΔF {phot.dF.toFixed(2)}, {phot.pct.toFixed(0)}%, {phot.z.toFixed(1)}σ). Aperture photometry.
                </p>
              )}

              <p className="note">
                Fit: {pts.length} positions · χ²/dof {Number.isFinite(best.chi2r) ? best.chi2r.toFixed(2) : 'n/a (no spare points)'} · baseline {best.baseline.toFixed(2)} yr. Uncertainties are inflated when the fit is poorer than the errors allow.
              </p>

              <div className="row">
                <button className="btn pri" onClick={save}>{t('save')}</button>
                <button className="btn" onClick={copy}>Copy link</button>
                <Link className="btn" to="/candidates">My candidates</Link>
              </div>
            </div>

            {known && (
              <div className="panel">
                <h3>Check against the catalogue</h3>
                <table className="tbl">
                  <thead>
                    <tr><th /><th className="num">Measured</th><th className="num">Catalogue</th><th className="num">Difference</th></tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Proper motion (″/yr)</td>
                      <td className="num">{best.pm.toFixed(3)} ± {best.errPm.toFixed(3)}</td>
                      <td className="num">{totalPm(known).toFixed(3)}</td>
                      <td className="num">{(((best.pm - totalPm(known)) / totalPm(known)) * 100).toFixed(1)}% · {(Math.abs(best.pm - totalPm(known)) / Math.max(best.errPm, 1e-6)).toFixed(1)}σ</td>
                    </tr>
                    {par && (
                      <tr>
                        <td>Parallax (″)</td>
                        <td className="num">{par.plx.toFixed(3)} ± {par.errPlx.toFixed(3)}</td>
                        <td className="num">{known.plx.toFixed(3)}</td>
                        <td className="num">{(Math.abs(par.plx - known.plx) / Math.max(par.errPlx, 1e-6)).toFixed(1)}σ</td>
                      </tr>
                    )}
                  </tbody>
                </table>
                <p className="note">Catalogue: {known.source}. The comparison reports how closely the measured motion agrees with the reference catalogue values.</p>
              </div>
            )}
          </div>

          <div className="panel">
            <h3>Track on the sky (arcsec, East to the left)</h3>
            <XYPlot series={series} xl="East offset (″)" yl="North offset (″)" invertX equal h={380} />
            <Legend items={series.map((s) => ({ color: s.color, label: s.label ?? '', dash: !!s.dash }))} />
          </div>
        </div>
      )}

      {marks.length > 0 && (
        <div className="panel tbl-wrap">
          <h3>Positions</h3>
          <table className="tbl">
            <thead>
              <tr>
                <th>Visit</th><th>Date</th><th className="num">x, y (px)</th>
                <th className="num">E, N (″)</th><th className="num">± (″)</th>
                <th className="num">S/N</th><th className="num">Flux</th>
              </tr>
            </thead>
            <tbody>
              {marks.map((m, i) => (
                <tr key={m.visit}>
                  <td>{m.visit + 1}{m.manual ? ' ✎' : ''}</td>
                  <td>{data ? fmtWV(data.cuts[m.visit].iso) : ''}</td>
                  <td className="num">{m.x.toFixed(2)}, {m.y.toFixed(2)}</td>
                  <td className="num">{pts[i]?.e.toFixed(1)}, {pts[i]?.n.toFixed(1)}</td>
                  <td className="num">{pts[i]?.se.toFixed(2)}</td>
                  <td className="num">{m.snr.toFixed(0)}</td>
                  <td className="num">{flux[i]?.flux.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {toast && <div className="warnbox" role="status" onClick={() => setToast('')}>{toast}</div>}
    </ScreenShell>
  );
}