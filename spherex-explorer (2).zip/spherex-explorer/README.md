# LumenX — NASA Space Apps 2026, "Planet X and SPHEREx"

The app opens into the explorer: a rotatable all-sky globe. Click a target or any patch of sky, or search a name / coordinates, and the view flies in to a cutout you can play back as a movie. Other tools live on their own screens (Tools button, top right).

## Run

```bash
npm install
npm run dev