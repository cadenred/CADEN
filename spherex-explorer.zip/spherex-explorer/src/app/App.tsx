import { ExplorationPage } from '../features/exploration/ExplorationPage';
import { AppProviders } from './providers';

export function App() {
  return (
    <AppProviders>
      <ExplorationPage />
    </AppProviders>
  );
}
