import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { AppProviders } from './providers';
import { LandingPage } from '../features/landing/LandingPage';
import { ExplorationPage } from '../features/exploration/ExplorationPage';

export function App() {
  return (
    <AppProviders>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/explore" element={<ExplorationPage />} />
          <Route path="*" element={<LandingPage />} />
        </Routes>
      </BrowserRouter>
    </AppProviders>
  );
}
