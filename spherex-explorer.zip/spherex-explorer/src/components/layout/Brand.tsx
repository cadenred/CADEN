import { Link } from 'react-router-dom';

export function Brand() {
  return (
    <Link className="brand" to="/" aria-label="LumenX home">
      <img className="brand-symbol-img" src="/lumenx-symbol.png" alt="" />
      <span className="brand-word">
        LUMEN<span>X</span>
      </span>
    </Link>
  );
}
