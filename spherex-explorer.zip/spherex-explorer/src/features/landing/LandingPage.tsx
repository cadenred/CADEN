import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  Orbit,
  ScanEye,
  Telescope,
  Moon,
  Sun,
} from 'lucide-react';

import { Link } from 'react-router-dom';
import { Brand } from '../../components/layout/Brand';
import { useTheme } from '../../app/providers';

export function LandingPage() {
  const { theme, toggleTheme } = useTheme();

  return (
    <div className={`landing-page theme-${theme}`}>
      <header className="site-header page-shell">
        <Brand />

        <nav className="main-nav" aria-label="Main navigation">
          <a href="#about">Overview</a>
          <a href="#workflow">How to explore</a>
        </nav>

        <div className="header-actions">
          <button
            className="theme-toggle"
            type="button"
            onClick={toggleTheme}
            aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
            title={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
          >
            {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
          </button>

          <Link className="header-cta" to="/explore">
            Open LumenX <ArrowUpRight size={15} />
          </Link>
        </div>
      </header>

      <main>
        <section className="hero page-shell">
          <div
            className="hero-backdrop"
            role="img"
            aria-label="Deep-space scene with stars, planets and a distant galaxy"
          />

          <div className="hero-vignette" />

          <div className="hero-content">
            <div className="eyebrow">
              <span className="eyebrow-line" />
              THE SKY, SEEN THROUGH TIME
            </div>

            <h1>
              Time leaves
              <br />
              traces in the <em>stars.</em>
            </h1>

            <p className="hero-description">
              The universe is never still. Explore infrared observations of
              the same region across different moments, compare what changed,
              and follow the objects that moved.
            </p>

            <div className="hero-actions">
              <Link className="button button-primary" to="/explore">
                Explore the sky <ArrowRight size={17} />
              </Link>

              <a className="quiet-link" href="#about">
                Discover the project <ArrowDown size={15} />
              </a>
            </div>
          </div>

          <div className="hero-orbit-card">
            <div className="orbit-card-top">
              THE SPHEREx SURVEY
            </div>

            <div className="orbit-stat">
              <strong>0.75–5.0</strong>
              <span>µm · infrared wavelength coverage</span>
            </div>

            <div className="orbit-rule" />

            <div className="orbit-stat">
              <strong>102</strong>
              <span>spectral bands across the survey</span>
            </div>

            <div className="orbit-rule" />

            <div className="orbit-stat orbit-stat-compact">
              <strong>6 months</strong>
              <span>between full-sky survey passes</span>
            </div>

            <p>
              Mission specifications · near-infrared all-sky survey.
            </p>
          </div>
        </section>

        <section className="intro-section page-shell" id="about">
          <div className="intro-grid">
            <h2>
              One region.
              <br />
              <em>Many moments.</em>
            </h2>

            <div className="intro-copy">
              <p>
                SPHEREx surveys the entire sky every six months in 102
                near-infrared bands. A single image captures one moment;
                comparing repeated observations can reveal objects that
                move or change brightness.
              </p>

              <p>
                LumenX makes that process easier to understand — from a
                first look at a region to a closer investigation of motion
                and changing brightness.
              </p>
            </div>
          </div>

          <div className="discovery-intro">
            <span className="section-label">
              THE LUMENX EXPERIENCE <span> / </span> THREE WAYS TO EXPLORE
            </span>

            <p>
              From a sky position to a possible discovery, every tool is
              built around one simple question: <em>what changed?</em>
            </p>
          </div>

          <div className="feature-strip">
            <article>
              <span className="feature-icon">
                <ScanEye size={19} />
              </span>

              <h3>See the observations</h3>

              <p>
                Open an infrared view of a selected region and inspect
                its wavelength bands.
              </p>
            </article>

            <article>
              <span className="feature-icon">
                <Orbit size={19} />
              </span>

              <h3>Follow time</h3>

              <p>
                Move between survey visits to see how the same patch
                of sky evolves.
              </p>
            </article>

            <article>
              <span className="feature-icon">
                <Telescope size={19} />
              </span>

              <h3>Investigate changes</h3>

              <p>
                Compare images to investigate moving asteroids, comets,
                changing stars and other possible candidates.
              </p>
            </article>
          </div>
        </section>

        <section className="workflow-section" id="workflow">
          <div className="page-shell workflow-inner">
            <div className="workflow-heading">
              <h2>
                From coordinates
                <br />
                to <em>discovery.</em>
              </h2>

              <p>
                Start with a position in the sky. LumenX brings the
                observations, time navigation and comparison tools into
                one public-facing workspace.
              </p>
            </div>

            <div className="workflow-steps">
              <div>
                <b>Choose a region</b>
                <p>
                  Enter a position in the sky or select a known
                  astronomical target.
                </p>
              </div>

              <div>
                <b>Explore observations</b>
                <p>
                  Browse available dates and the infrared wavelength bands.
                </p>
              </div>

              <div>
                <b>Compare and inspect</b>
                <p>
                  Move through time, compare images, and examine
                  observation details.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="mission-section page-shell" id="mission">
          <div className="mission-copy">
            <h2>
              A new perspective
              <br />
              on the
              <br />
              <em>infrared universe.</em>
            </h2>

            <p>
              SPHEREx is NASA’s Spectro-Photometer for the History of the
              Universe, Epoch of Reionization and Ices Explorer. LumenX
              makes its observations easier for more people to explore.
            </p>

            <a
              className="text-arrow"
              href="https://science.nasa.gov/mission/spherex/"
              target="_blank"
              rel="noreferrer"
            >
              Learn about SPHEREx at NASA <ArrowUpRight size={15} />
            </a>
          </div>

          <div className="mission-visual">
            <img
              src="/lumenx-cosmos.jpg"
              alt="A dramatic view of a spiral galaxy, planets and a black hole in deep space"
            />

            <div className="mission-visual-caption">
              <span>EXPLORE THE COSMOS</span>
              <span>LUMENX</span>
            </div>
          </div>
        </section>

        <section className="closing-section page-shell">
          <h2>
            Start with a place.
            <br />
            <em>Follow what changes.</em>
          </h2>

          <Link className="button button-primary" to="/explore">
            Open LumenX <ArrowRight size={17} />
          </Link>
        </section>
      </main>

      <footer className="site-footer page-shell">
        <Brand />
        <p>Exploring the infrared universe</p>
        <span>A LUMEN X PROJECT</span>
      </footer>
    </div>
  );
}