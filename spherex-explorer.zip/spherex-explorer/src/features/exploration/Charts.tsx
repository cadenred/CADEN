import { ARRAY_EDGES, BANDS } from './demoData';
import type { SpectrumPoint } from './demoData';

const W = 640, H = 270, L = 52, Rm = 14, T = 22, B = 38;
const niceTicks = (lo: number, hi: number, n = 4) => {
  const raw = (hi - lo) / n, mag = Math.pow(10, Math.floor(Math.log10(raw || 1))), step = [1, 2, 5, 10].map((m) => m * mag).find((s) => s >= raw) ?? raw;
  const out: number[] = [];
  for (let v = Math.ceil(lo / step) * step; v <= hi + 1e-9; v += step) out.push(+v.toFixed(6));
  return out;
};
const fmt = (v: number) => (Math.abs(v) >= 100 ? v.toFixed(0) : Math.abs(v) >= 10 ? v.toFixed(1) : v.toFixed(2));

export function SpectrumChart({ points, marked }: { points: SpectrumPoint[]; marked: number[] }) {
  const lo = Math.min(...points.map((p) => p.flux - p.err)), hi = Math.max(...points.map((p) => p.flux + p.err));
  const pad = (hi - lo) * 0.08 || 1, y0 = lo - pad, y1 = hi + pad;
  const X = (l: number) => L + ((l - 0.75) / (5 - 0.75)) * (W - L - Rm);
  const Y = (v: number) => T + (1 - (v - y0) / (y1 - y0)) * (H - T - B);
  const line = points.map((p, i) => `${i ? 'L' : 'M'}${X(p.lam).toFixed(1)},${Y(p.flux).toFixed(1)}`).join('');
  const band = points.map((p) => `${X(p.lam).toFixed(1)},${Y(p.flux + p.err).toFixed(1)}`).join(' ') + ' ' + [...points].reverse().map((p) => `${X(p.lam).toFixed(1)},${Y(p.flux - p.err).toFixed(1)}`).join(' ');
  const mk = marked.length ? { a: BANDS[Math.min(...marked)].lo, b: BANDS[Math.max(...marked)].hi } : null;
  return (
    <svg className="chart" viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Spectrum: brightness against wavelength, with uncertainty band">
      {ARRAY_EDGES.slice(0, 6).map((e, i) => (
        <g key={i}>
          <rect x={X(e)} y={T} width={X(ARRAY_EDGES[i + 1]) - X(e)} height={H - T - B} fill={i % 2 ? 'rgba(200,225,220,.045)' : 'transparent'} />
          <text x={(X(e) + X(ARRAY_EDGES[i + 1])) / 2} y={T - 8} textAnchor="middle" className="chart-small">D{i + 1}</text>
        </g>
      ))}
      {mk && <rect x={X(mk.a)} y={T} width={Math.max(2, X(mk.b) - X(mk.a))} height={H - T - B} fill="rgba(199,231,223,.2)" />}
      {niceTicks(y0, y1).map((v) => (<g key={v}><line x1={L} x2={W - Rm} y1={Y(v)} y2={Y(v)} stroke="rgba(200,225,220,.1)" /><text x={L - 8} y={Y(v) + 3} textAnchor="end" className="chart-text">{fmt(v)}</text></g>))}
      {[1, 2, 3, 4, 5].map((v) => (<g key={v}><line x1={X(v)} x2={X(v)} y1={H - B} y2={H - B + 4} stroke="#6d838a" /><text x={X(v)} y={H - B + 17} textAnchor="middle" className="chart-text">{v}</text></g>))}
      <text x={(L + W - Rm) / 2} y={H - 6} textAnchor="middle" className="chart-text">Wavelength (µm)</text>
      <text transform={`rotate(-90 13 ${(T + H - B) / 2})`} x={13} y={(T + H - B) / 2} textAnchor="middle" className="chart-text">Brightness (demo units)</text>
      <polygon points={band} fill="rgba(199,231,223,.22)" />
      <path d={line} fill="none" stroke="#c7e7df" strokeWidth="1.6" />
      {points.map((p) => (<circle key={p.band} cx={X(p.lam)} cy={Y(p.flux)} r="1.8" fill="#e9f6f1" />))}
    </svg>
  );
}

export type LCPoint = { mjd: number; flux: number; err: number; date: string };
export function LightCurve({ points }: { points: LCPoint[] }) {
  const w = 640, h = 230, l = 52, r = 16, t = 14, b = 40;
  const x0 = Math.min(...points.map((p) => p.mjd)), x1 = Math.max(...points.map((p) => p.mjd));
  const lo = Math.min(...points.map((p) => p.flux - p.err)), hi = Math.max(...points.map((p) => p.flux + p.err)), pad = (hi - lo) * 0.12 || 1;
  const X = (m: number) => l + ((m - x0) / (x1 - x0 || 1)) * (w - l - r), Y = (v: number) => t + (1 - (v - (lo - pad)) / (hi - lo + 2 * pad)) * (h - t - b);
  return (
    <svg className="chart" viewBox={`0 0 ${w} ${h}`} role="img" aria-label="Light curve: brightness of the target at each observation date">
      {niceTicks(lo - pad, hi + pad).map((v) => (<g key={v}><line x1={l} x2={w - r} y1={Y(v)} y2={Y(v)} stroke="rgba(200,225,220,.1)" /><text x={l - 8} y={Y(v) + 3} textAnchor="end" className="chart-text">{fmt(v)}</text></g>))}
      <path d={points.map((p, i) => `${i ? 'L' : 'M'}${X(p.mjd).toFixed(1)},${Y(p.flux).toFixed(1)}`).join('')} fill="none" stroke="rgba(199,231,223,.5)" strokeWidth="1.2" />
      {points.map((p) => (<g key={p.mjd}><line x1={X(p.mjd)} x2={X(p.mjd)} y1={Y(p.flux + p.err)} y2={Y(p.flux - p.err)} stroke="#c7e7df" /><circle cx={X(p.mjd)} cy={Y(p.flux)} r="3.2" fill="#e9f6f1" /><text x={X(p.mjd)} y={h - 20} textAnchor="middle" className="chart-small">{p.date.slice(2, 7)}</text></g>))}
      <text x={(l + w - r) / 2} y={h - 4} textAnchor="middle" className="chart-text">Observation date (yy-mm)</text>
      <text transform={`rotate(-90 13 ${(t + h - b) / 2})`} x={13} y={(t + h - b) / 2} textAnchor="middle" className="chart-text">Brightness (demo units)</text>
    </svg>
  );
}