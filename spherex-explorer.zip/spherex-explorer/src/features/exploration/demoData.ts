/**
 * Demo-data engine for the LumenX explorer (UI only, no backend, no Python).
 * Everything here is SYNTHETIC. It mimics the *shape* of SPHEREx products
 * (102 bands, six arrays, 6.2" pixels, flags, uncertainties) so the interface
 * can be built and tested. When the real backend exists, replace buildScene /
 * renderBands / spectrumAt with fetch() calls that return the same shapes.
 */

export const PIXEL_ARCSEC = 6.2;
export const MANIFEST = { version: 'demo-1', updated: '2026-11-14', source: 'synthetic demo data' };

/* ---------- bands & arrays ---------- */
// TODO(verify): array edges are approximate demo values; confirm against IRSA/SPHEREx docs before real data.
export const ARRAY_EDGES = [0.75, 1.11, 1.64, 2.42, 3.82, 4.42, 5.0];
export type Band = { index: number; array: number; lo: number; hi: number; center: number };
export const BANDS: Band[] = [];
for (let a = 0; a < 6; a++) {
  const lo = ARRAY_EDGES[a], hi = ARRAY_EDGES[a + 1];
  for (let k = 0; k < 17; k++) {
    const l = lo * Math.pow(hi / lo, k / 17), h = lo * Math.pow(hi / lo, (k + 1) / 17);
    BANDS.push({ index: a * 17 + k, array: a, lo: l, hi: h, center: Math.sqrt(l * h) });
  }
}
export const ALL_BANDS = BANDS.map((b) => b.index);
export const bandsOfArray = (a: number) => BANDS.filter((b) => b.array === a).map((b) => b.index);
export const bandsInRange = (lo: number, hi: number) => {
  const found = BANDS.filter((b) => b.center >= lo && b.center <= hi).map((b) => b.index);
  if (found.length) return found;
  const mid = (lo + hi) / 2;
  return [BANDS.reduce((best, b) => (Math.abs(b.center - mid) < Math.abs(BANDS[best].center - mid) ? b.index : best), 0)];
};
export const nearestBand = (um: number) =>
  BANDS.reduce((best, b) => (Math.abs(b.center - um) < Math.abs(BANDS[best].center - um) ? b.index : best), 0);

/* ---------- flags ---------- */
// TODO(verify): real SPHEREx flag names/bits differ; these four are illustrative stand-ins.
export const FLAG = { HOT: 1, CR: 2, HALO: 4, EDGE: 8 } as const;
export const FLAG_INFO = [
  { bit: FLAG.HOT, name: 'Hot pixel', color: '#e06bd6', text: 'A detector pixel that reads too bright in every exposure. Treat its value with caution.' },
  { bit: FLAG.CR, name: 'Cosmic-ray hit', color: '#f2d54a', text: 'A one-off spike from a charged particle striking the detector. It appears in a single band only.' },
  { bit: FLAG.HALO, name: 'Bright-star contamination', color: '#f0914f', text: 'Pixels close to a very bright star, where its glare can leak into neighbouring measurements.' },
  { bit: FLAG.EDGE, name: 'Cutout edge', color: '#9aa8ad', text: 'The outermost ring of the cutout, where coverage can be incomplete.' },
];

/* ---------- maths helpers ---------- */
function mulberry(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function hash4(a: number, b: number, c: number, d: number) {
  let h = Math.imul(a + 0x9e3779b9, 0x85ebca6b) ^ Math.imul(b + 0x7f4a7c15, 0xc2b2ae35);
  h = Math.imul(h ^ (h >>> 13), 0x27d4eb2f) ^ Math.imul(c + 0x165667b1, 0x85ebca6b);
  h = Math.imul(h ^ (h >>> 15), 0x2c1b3c6d) ^ Math.imul(d + 0x1b873593, 0xc2b2ae35);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}
const strSeed = (s: string) => [...s].reduce((a, c) => (Math.imul(a, 31) + c.charCodeAt(0)) >>> 0, 7);
const bb = (l: number, T: number) => 1 / (Math.pow(l, 5) * (Math.exp(14388 / (l * T)) - 1));
export const yearOf = (iso: string) => 2000 + (Date.parse(iso + 'T00:00:00Z') - Date.UTC(2000, 0, 1)) / (365.25 * 86400000);
export const mjdOf = (iso: string) => Date.parse(iso + 'T00:00:00Z') / 86400000 + 40587;

/* ---------- targets ---------- */
export type SpecModel = { T: number; ref: number; dips?: [number, number, number][]; bumps?: [number, number, number][] };
export type TargetDef = {
  id: string; name: string; group: 'test' | 'sample'; kind: 'mover' | 'variable' | 'static' | 'field';
  ra: number; dec: number; description: string; aliases: string[]; epochs: string[];
  amp: number; spec: SpecModel; pm?: { e: number; n: number }; inGaia: boolean; inWise: boolean;
  variability?: { period: number; amp: number; irregular?: number }; note?: string; noteTitle?: string;
};
const IRREG = undefined;
export const TARGETS: TargetDef[] = [
  { id: 'barnard', name: "Barnard's Star", group: 'test', kind: 'mover', ra: 269.4521, dec: 4.6934,
    description: 'A nearby red dwarf with the largest known proper motion, so it drifts visibly between observations.',
    aliases: ["barnard's star", 'barnards star', 'barnard star', 'barnard', 'gj 699'],
    epochs: ['2025-06-02', '2025-09-14', '2025-12-08', '2026-03-20', '2026-06-11', '2026-09-27'],
    amp: 520, spec: { T: 3250, ref: 1.6 }, pm: { e: -0.80, n: 10.33 }, inGaia: true, inWise: true,
    noteTitle: 'A fast mover', note: 'Barnard’s Star moves roughly 10″ per year (demo value). Turn on Gaia and “Move to observation epoch” to see the catalogue position catch up with the star.' },
  { id: 'epsindib', name: 'Epsilon Indi B', group: 'test', kind: 'mover', ra: 330.8700, dec: -56.7800,
    description: 'A pair of brown dwarfs (Ba and Bb) orbiting the star Epsilon Indi A.',
    aliases: ['epsilon indi b', 'eps indi b', 'eps ind b', 'epsilon indi', 'epsilon indi ba', 'eps indi'],
    epochs: ['2025-06-20', '2025-10-02', '2026-01-18', '2026-05-09', '2026-08-30'],
    amp: 14, spec: { T: 1300, ref: 2.5, dips: [[2.3, 0.12, 0.4], [3.3, 0.18, 0.5]], bumps: [[4.55, 0.2, 0.7]] }, pm: { e: 3.96, n: -2.54 }, inGaia: true, inWise: true,
    noteTitle: 'Two objects, one blob', note: 'Epsilon Indi Ba and Bb are far closer together than one 6.2″ SPHEREx pixel, so they appear as a single blended source here. This view cannot separate them.' },
  { id: 'wise0855', name: 'WISE 0855−0714', group: 'test', kind: 'mover', ra: 133.7951, dec: -7.2452,
    description: 'One of the coldest known brown dwarfs. It is faint and moves quickly across the sky.',
    aliases: ['wise 0855-0714', 'wise 0855', 'wise0855', 'wise 0855−0714', 'wise j0855-0714'],
    epochs: ['2025-05-28', '2025-08-30', '2025-12-14', '2026-03-02', '2026-06-25', '2026-10-05'],
    amp: 7, spec: { T: 285, ref: 4.6 }, pm: { e: -8.1, n: 0.68 }, inGaia: false, inWise: true,
    noteTitle: 'Faint and cold', note: 'This object is almost invisible in the short-wavelength bands. Try an all-band co-add, or look near 4.5 µm, then follow the expected-position ring across epochs.' },
  { id: 'rwaur', name: 'RW Aurigae', group: 'test', kind: 'variable', ra: 76.9565, dec: 30.4014,
    description: 'A young, irregularly variable star whose brightness changes unpredictably.',
    aliases: ['rw aurigae', 'rw aur', 'rwaur'],
    epochs: ['2025-07-08', '2025-12-21', '2026-04-03', '2026-09-12'],
    amp: 260, spec: { T: 4200, ref: 1.6, bumps: [[3.2, 1.4, 0.35]] }, inGaia: true, inWise: true, variability: { period: 0, amp: 0.8, irregular: 0.5 },
    noteTitle: 'A variable star', note: 'Only a few epochs are available in this demo, so a full light curve may not be possible.' },
  { id: 'rdra', name: 'R Draconis', group: 'test', kind: 'variable', ra: 248.1670, dec: 66.7550,
    description: 'A Mira variable: a pulsating giant star that swells and fades over many months.',
    aliases: ['r draconis', 'r dra', 'rdra'],
    epochs: ['2025-06-05', '2025-07-29', '2025-09-30', '2025-11-26', '2026-01-24', '2026-03-31', '2026-06-02', '2026-08-04', '2026-10-06'],
    amp: 380, spec: { T: 2800, ref: 1.6, dips: [[1.4, 0.09, 0.35], [1.9, 0.12, 0.4], [2.7, 0.2, 0.45]] }, inGaia: true, inWise: true, variability: { period: 245, amp: 2.2 },
    noteTitle: 'A pulsating giant', note: 'Brightness swings on a cycle of roughly 245 days (demo value). Look at the light curve below once several epochs are available.' },
  { id: 'orion', name: 'Orion Nebula', group: 'sample', kind: 'field', ra: 83.8221, dec: -5.3911, description: 'A nearby stellar nursery in the constellation Orion.',
    aliases: ['orion nebula', 'orion', 'm42'], epochs: ['2025-03-12', '2025-03-18', '2025-04-02', '2025-04-21'],
    amp: 0, spec: { T: 5000, ref: 1.6 }, inGaia: false, inWise: false },
  { id: 'andromeda', name: 'Andromeda Galaxy', group: 'sample', kind: 'field', ra: 10.6847, dec: 41.269, description: 'A spiral galaxy visible in the northern sky.',
    aliases: ['andromeda galaxy', 'andromeda', 'm31'], epochs: ['2025-03-12', '2025-03-18', '2025-04-02', '2025-04-21'],
    amp: 0, spec: { T: 5000, ref: 1.6 }, inGaia: false, inWise: false },
  { id: 'pleiades', name: 'Pleiades', group: 'sample', kind: 'field', ra: 56.75, dec: 24.1167, description: 'An open star cluster surrounded by reflection nebulosity.',
    aliases: ['pleiades', 'm45', 'seven sisters'], epochs: ['2025-03-12', '2025-03-18', '2025-04-02', '2025-04-21'],
    amp: 0, spec: { T: 5000, ref: 1.6 }, inGaia: false, inWise: false },
];
void IRREG;
export const targetById = (id: string) => TARGETS.find((t) => t.id === id);

/** Demo name resolver. Real SIMBAD/Sesame resolution needs the backend (TODO). */
export function resolveName(q: string): TargetDef | null {
  const s = q.trim().toLowerCase().replace(/[’']/g, "'").replace(/\s+/g, ' ');
  if (!s) return null;
  return TARGETS.find((t) => t.id === s || t.aliases.includes(s) || t.name.toLowerCase() === s) ?? null;
}
export function nearestTarget(ra: number, dec: number) {
  let best: TargetDef | null = null, bd = 1e9;
  for (const t of TARGETS) {
    const dx = ((ra - t.ra + 540) % 360 - 180) * Math.cos((dec * Math.PI) / 180), dy = dec - t.dec;
    const d = Math.hypot(dx, dy);
    if (d < bd) { bd = d; best = t; }
  }
  return { target: best as TargetDef, distDeg: bd };
}

/* ---------- download-size estimate ---------- */
export function sizeEstimate(fovArcmin: number, nEpochs: number) {
  const n = Math.max(8, Math.round((fovArcmin * 60) / PIXEL_ARCSEC));
  const perCutout = n * n * 4 * 3; // assumption: image + variance + flags, 4 bytes each
  const total = perCutout * 102 * nEpochs;
  return { n, perCutout, total };
}
export const fmtBytes = (b: number) => (b >= 1e9 ? (b / 1e9).toFixed(2) + ' GB' : b >= 1e6 ? (b / 1e6).toFixed(b >= 1e8 ? 0 : 1) + ' MB' : Math.max(1, Math.round(b / 1e3)) + ' kB');

/* ---------- scene ---------- */
export type Source = {
  e0: number; n0: number; pmE: number; pmN: number; amp: number; spec: SpecModel;
  isTarget: boolean; gaia: boolean; wise: boolean; label?: string;
  variability?: { period: number; amp: number; irregular?: number };
};
export type Stamp = { idx: Int32Array; w: Float32Array };
export type Scene = {
  target: TargetDef; fov: number; w: number; h: number; cx: number; cy: number;
  sources: Source[]; years: number[]; mjd: number[]; t0: number; bg: Float32Array | null;
  stamps: Map<number, Stamp[]>; pixmaps: Map<number, Map<number, [number, number][]>>;
};
export const GAIA_EPOCH = 2016.0;
export const WISE_EPOCH = 2010.6; // demo value for the AllWISE reference epoch

const fieldCache = new Map<string, Source[]>();
function fieldSources(t: TargetDef, t0: number): Source[] {
  const hit = fieldCache.get(t.id);
  if (hit) return hit;
  const rnd = mulberry(strSeed(t.id));
  const out: Source[] = [];
  if (t.kind !== 'field') {
    out.push({ e0: 0, n0: 0, pmE: t.pm?.e ?? 0, pmN: t.pm?.n ?? 0, amp: t.amp, spec: t.spec, isTarget: true, gaia: t.inGaia, wise: t.inWise, label: t.name, variability: t.variability });
  }
  if (t.id === 'epsindib') {
    // Epsilon Indi A: much brighter, a few arcmin away (illustrative placement).
    out.push({ e0: -95, n0: 388, pmE: 3.96, pmN: -2.54, amp: 900, spec: { T: 4600, ref: 1.6 }, isTarget: false, gaia: true, wise: true, label: 'Epsilon Indi A' });
  }
  const density = t.kind === 'field' ? 1.5 : 1.0; // sources per arcmin^2
  const count = Math.round(density * 3600);
  for (let i = 0; i < count; i++) {
    const amp = 1.6 * Math.pow(1 - rnd() * 0.998, -0.75);
    const T = 3000 + rnd() * 6500;
    out.push({ e0: (rnd() - 0.5) * 1800, n0: (rnd() - 0.5) * 1800, pmE: 0, pmN: 0, amp: Math.min(amp, 700), spec: { T, ref: 1.6 },
      isTarget: false, gaia: amp > 2.6 && rnd() < 0.9, wise: amp > 5 && T < 6500 && rnd() < 0.8 });
  }
  if (t.kind !== 'field') {
    // an unlisted faint mover to "discover" with the difference tools
    const ang = rnd() * Math.PI * 2, spd = 5 + rnd() * 4;
    out.push({ e0: (rnd() - 0.5) * 300, n0: (rnd() - 0.5) * 300, pmE: Math.cos(ang) * spd, pmN: Math.sin(ang) * spd, amp: 5.5, spec: { T: 900, ref: 3.6, bumps: [[4.5, 0.25, 0.9]] },
      isTarget: false, gaia: false, wise: false, label: 'Unlisted mover (candidate)' });
  }
  void t0;
  fieldCache.set(t.id, out);
  return out;
}

export const sourcePos = (s: Source, year: number, t0: number) => ({ e: s.e0 + s.pmE * (year - t0), n: s.n0 + s.pmN * (year - t0) });
export const toPixel = (sc: Scene, e: number, n: number) => ({ x: sc.cx - e / PIXEL_ARCSEC, y: sc.cy - n / PIXEL_ARCSEC });

export function buildScene(target: TargetDef, fov: number): Scene {
  const w = Math.max(8, Math.round((fov * 60) / PIXEL_ARCSEC));
  const years = target.epochs.map(yearOf), mjd = target.epochs.map(mjdOf);
  const t0 = years[0];
  const all = fieldSources(target, t0);
  const half = (w / 2 + 6) * PIXEL_ARCSEC;
  const sources = all.filter((s) => years.some((y) => { const p = sourcePos(s, y, t0); return Math.abs(p.e) < half && Math.abs(p.n) < half; }));
  const sc: Scene = { target, fov, w, h: w, cx: (w - 1) / 2, cy: (w - 1) / 2, sources, years, mjd, t0, bg: null, stamps: new Map(), pixmaps: new Map() };
  if (target.kind === 'field') {
    const rnd = mulberry(strSeed(target.id + 'bg'));
    const blobs = Array.from({ length: 6 }, () => ({ x: rnd() * w, y: rnd() * w, r: w * (0.15 + rnd() * 0.3), a: 1.5 + rnd() * 3 }));
    sc.bg = new Float32Array(w * w);
    for (let y = 0; y < w; y++) for (let x = 0; x < w; x++) {
      let v = 0;
      for (const b of blobs) v += b.a * Math.exp(-((x - b.x) ** 2 + (y - b.y) ** 2) / (2 * b.r * b.r));
      sc.bg[y * w + x] = v;
    }
  }
  return sc;
}

/* ---------- flux model ---------- */
export function sourceFlux(s: Source, lam: number, year: number): number {
  const m = s.spec;
  let f = s.amp * (bb(lam, m.T) / bb(m.ref, m.T));
  if (m.dips) for (const [c, wd, d] of m.dips) f *= 1 - d * Math.exp(-(((lam - c) / wd) ** 2));
  if (m.bumps) for (const [c, wd, a] of m.bumps) f += s.amp * a * Math.exp(-(((lam - c) / wd) ** 2));
  const v = s.variability;
  if (v) {
    let dm = 0;
    if (v.period > 0) dm += 0.5 * v.amp * Math.sin((2 * Math.PI * year * 365.25) / v.period);
    if (v.irregular) dm += v.irregular * (hash4(Math.round(year * 1000), 3, 5, 7) - 0.5) * v.amp;
    f *= Math.pow(10, -0.4 * dm * Math.pow(1.6 / lam, 0.6));
  }
  return f;
}
export const sigmaBand = (b: number) => 1.2 * (1 + 0.1 * BANDS[b].center);
const PSF = 0.8, R = 4, HOT_ADD = 22, CR_ADD = 38;
function h32(a: number, b: number, c: number) {
  let h = Math.imul(a ^ 0x9e3779b9, 0x85ebca6b);
  h = Math.imul(h ^ (h >>> 13) ^ b, 0xc2b2ae35);
  h = Math.imul(h ^ (h >>> 16) ^ c, 0x27d4eb2f);
  h ^= h >>> 15; h = Math.imul(h, 0x2c1b3c6d); h ^= h >>> 13;
  return h >>> 0;
}
const gaussOf = (h: number) => (((h & 1023) + ((h >>> 10) & 1023) + ((h >>> 20) & 1023)) / 1024 - 1.5) * 2;
const crOf = (h: number) => (Math.imul(h, 0x9e3779b1) >>> 0) / 4294967296 < 0.0004;
const hotCache = new WeakMap<Scene, Map<number, Uint8Array>>();
function hotMap(sc: Scene, arr: number) {
  let m = hotCache.get(sc);
  if (!m) { m = new Map(); hotCache.set(sc, m); }
  let h = m.get(arr);
  if (!h) { h = new Uint8Array(sc.w * sc.h); for (let i = 0; i < h.length; i++) h[i] = hash4(i, arr, 11, 3) < 0.0012 ? 1 : 0; m.set(arr, h); }
  return h;
}

export function getStamps(sc: Scene, ep: number): Stamp[] {
  const hit = sc.stamps.get(ep);
  if (hit) return hit;
  const list = sc.sources.map((s) => {
    const p = sourcePos(s, sc.years[ep], sc.t0), q = toPixel(sc, p.e, p.n);
    const idx: number[] = [], w: number[] = [];
    for (let y = Math.round(q.y) - R; y <= Math.round(q.y) + R; y++) for (let x = Math.round(q.x) - R; x <= Math.round(q.x) + R; x++) {
      if (x < 0 || y < 0 || x >= sc.w || y >= sc.h) continue;
      idx.push(y * sc.w + x);
      w.push(Math.exp(-((x - q.x) ** 2 + (y - q.y) ** 2) / (2 * PSF * PSF)));
    }
    return { idx: Int32Array.from(idx), w: Float32Array.from(w) };
  });
  sc.stamps.set(ep, list);
  return list;
}

/** Mean of the selected bands (a "co-add"), with demo noise. Returns data and its 1-sigma noise. */
export function renderBands(sc: Scene, ep: number, bands: number[]): { data: Float32Array; sigma: number } {
  const n = sc.w * sc.h, data = new Float32Array(n), stamps = getStamps(sc, ep);
  let var2 = 0;
  for (const b of bands) {
    const lam = BANDS[b].center, hot = hotMap(sc, BANDS[b].array);
    for (let i = 0; i < stamps.length; i++) {
      const f = sourceFlux(sc.sources[i], lam, sc.years[ep]);
      const st = stamps[i];
      for (let k = 0; k < st.idx.length; k++) data[st.idx[k]] += st.w[k] * f;
    }
    const sg = sigmaBand(b);
    var2 += sg * sg;
    const bgScale = Math.pow(lam / 2, -0.7);
    for (let i = 0; i < n; i++) {
      const h = h32(i, b, ep);
      let v = gaussOf(h) * sg;
      if (hot[i]) v += HOT_ADD;
      if (crOf(h)) v += CR_ADD;
      if (sc.bg) v += sc.bg[i] * bgScale;
      data[i] += v;
    }
  }
  const nb = bands.length;
  for (let i = 0; i < n; i++) data[i] /= nb;
  return { data, sigma: Math.sqrt(var2) / nb };
}

function pixmap(sc: Scene, ep: number) {
  const hit = sc.pixmaps.get(ep);
  if (hit) return hit;
  const m = new Map<number, [number, number][]>(), stamps = getStamps(sc, ep);
  stamps.forEach((st, si) => { for (let k = 0; k < st.idx.length; k++) { const a = m.get(st.idx[k]); const e: [number, number] = [si, st.w[k]]; if (a) a.push(e); else m.set(st.idx[k], [e]); } });
  sc.pixmaps.set(ep, m);
  return m;
}

export type SpectrumPoint = { band: number; array: number; lam: number; flux: number; err: number };
export function spectrumAt(sc: Scene, ep: number, x: number, y: number): SpectrumPoint[] {
  const i = y * sc.w + x, list = pixmap(sc, ep).get(i) ?? [];
  return BANDS.map((bd) => {
    let v = 0;
    for (const [si, w] of list) v += w * sourceFlux(sc.sources[si], bd.center, sc.years[ep]);
    const sg = sigmaBand(bd.index);
    const h = h32(i, bd.index, ep);
    v += gaussOf(h) * sg;
    if (hotMap(sc, bd.array)[i]) v += HOT_ADD;
    if (crOf(h)) v += CR_ADD;
    if (sc.bg) v += sc.bg[i] * Math.pow(bd.center / 2, -0.7);
    return { band: bd.index, array: bd.array, lam: bd.center, flux: v, err: sg };
  });
}

/** Mean brightness of one pixel over the chosen bands (cheap: no full image render). */
export function pixelMean(sc: Scene, ep: number, x: number, y: number, bands: number[]) {
  const i = y * sc.w + x, list = pixmap(sc, ep).get(i) ?? [];
  let sum = 0, var2 = 0;
  for (const b of bands) {
    const lam = BANDS[b].center;
    let v = 0;
    for (const [si, w] of list) v += w * sourceFlux(sc.sources[si], lam, sc.years[ep]);
    const h = h32(i, b, ep), sg = sigmaBand(b);
    v += gaussOf(h) * sg;
    if (hotMap(sc, BANDS[b].array)[i]) v += HOT_ADD;
    if (crOf(h)) v += CR_ADD;
    if (sc.bg) v += sc.bg[i] * Math.pow(lam / 2, -0.7);
    sum += v; var2 += sg * sg;
  }
  return { flux: sum / bands.length, err: Math.sqrt(var2) / bands.length };
}

/** Photometry at the target's expected position for one epoch. Null if the target left the cutout. */
export function targetBrightness(sc: Scene, ep: number, bands: number[]) {
  const t = sc.sources.find((s) => s.isTarget);
  if (!t) return null;
  const p = sourcePos(t, sc.years[ep], sc.t0), q = toPixel(sc, p.e, p.n);
  const x = Math.round(q.x), y = Math.round(q.y);
  if (x < 0 || y < 0 || x >= sc.w || y >= sc.h) return null;
  return pixelMean(sc, ep, x, y, bands);
}

export function flagMap(sc: Scene, ep: number, bands: number[]): Uint8Array {
  const f = new Uint8Array(sc.w * sc.h), arrs = new Set(bands.map((b) => BANDS[b].array));
  for (const a of arrs) { const hm = hotMap(sc, a); for (let i = 0; i < f.length; i++) if (hm[i]) f[i] |= FLAG.HOT; }
  if (bands.length === 1) for (let i = 0; i < f.length; i++) if (crOf(h32(i, bands[0], ep))) f[i] |= FLAG.CR;
  getStamps(sc, ep).forEach((st, si) => {
    if (sc.sources[si].amp < 250) return;
    for (let k = 0; k < st.idx.length; k++) if (st.w[k] > 0.05) f[st.idx[k]] |= FLAG.HALO;
  });
  for (let x = 0; x < sc.w; x++) { f[x] |= FLAG.EDGE; f[(sc.h - 1) * sc.w + x] |= FLAG.EDGE; }
  for (let y = 0; y < sc.h; y++) { f[y * sc.w] |= FLAG.EDGE; f[y * sc.w + sc.w - 1] |= FLAG.EDGE; }
  return f;
}

/* ---------- catalogues ---------- */
export type CatEntry = { e: number; n: number; label?: string; moves: boolean };
export function catalogue(sc: Scene, which: 'gaia' | 'wise', year: number, propagate: boolean): CatEntry[] {
  const ref = which === 'gaia' ? GAIA_EPOCH : WISE_EPOCH;
  return sc.sources.filter((s) => (which === 'gaia' ? s.gaia : s.wise)).map((s) => {
    const p = sourcePos(s, propagate ? year : ref, sc.t0);
    return { e: p.e, n: p.n, label: s.label, moves: Math.hypot(s.pmE, s.pmN) > 0.5 };
  });
}

/* ---------- display helpers ---------- */
export function stretchOf(d: Float32Array) {
  const s = Float32Array.from(d).sort();
  const lo = s[Math.floor(s.length * 0.2)], hi = s[Math.floor(s.length * 0.9985)];
  return { lo, hi: Math.max(hi, lo + 1e-3) };
}
export const applyStretch = (v: number, lo: number, hi: number) => {
  const t = Math.min(1, Math.max(0, (v - lo) / (hi - lo)));
  return Math.asinh(t * 12) / Math.asinh(12);
};
export const fmtDate = (iso: string) => iso;
export function skyAt(sc: Scene, x: number, y: number) {
  const dE = (sc.cx - x) * PIXEL_ARCSEC, dN = (sc.cy - y) * PIXEL_ARCSEC;
  const dec = sc.target.dec + dN / 3600, ra = sc.target.ra + dE / 3600 / Math.cos((sc.target.dec * Math.PI) / 180);
  return { ra: (ra + 360) % 360, dec };
}