import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { ReactNode, CSSProperties } from 'react';
import { Layers, Database, Telescope, Crosshair, Share2, Code, Camera, Info, Plus, Minus, Search, Home, Play, Pause, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, X, Eye, EyeOff, Rocket, Activity, Orbit, Waypoints, Link2, Sparkles, ArrowLeft } from 'lucide-react';
import { SkyMap, GLOBE_R, BOT, D, wrap } from './SkyMap';
import type { View } from './SkyMap';
import { SkyFrame } from './SkyFrame';
import type { Mark } from './SkyFrame';
import { TARGETS, MANIFEST, ARRAY_EDGES, BANDS, ALL_BANDS, bandsOfArray, buildScene, renderBands, stretchOf, applyStretch, resolveName, sourcePos, toPixel, catalogue, spectrumAt, flagMap, skyAt, pixelMean, targetBrightness, sizeEstimate, fmtBytes, FLAG_INFO, PIXEL_ARCSEC } from './demoData';
import type { TargetDef } from './demoData';
import { listChangeDetectors, baselineDetector, findResiduals } from './changeDetection';
import { readUrl } from './urlState';

/* ---------- helpers ---------- */
const endR = (fovArc: number) => Math.max(300, Math.min(window.innerHeight - BOT, window.innerWidth)) / ((fovArc / 60) * D), MON = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
const DEFAULT_EPOCHS = ['2025-05-30', '2025-08-20', '2025-11-25', '2026-02-18', '2026-05-27', '2026-08-25'];
const fmtRA = (ra: number) => { const h = ra / 15, hh = Math.floor(h), m = (h - hh) * 60, mm = Math.floor(m); return `${hh}h${String(mm).padStart(2, '0')}m${((m - mm) * 60).toFixed(1)}s`; };
const fmtDec = (d: number) => { const a = Math.abs(d), dd = Math.floor(a), m = (a - dd) * 60, mm = Math.floor(m); return `${d < 0 ? '−' : '+'}${dd}°${String(mm).padStart(2, '0')}′${((m - mm) * 60).toFixed(0)}″`; };
const fmtWV = (iso: string) => { const [y, m, d] = iso.split('-'); return `${y} ${MON[+m - 1]} ${d}`; };
const customTarget = (ra: number, dec: number): TargetDef => ({ id: `custom-${ra.toFixed(3)}_${dec.toFixed(3)}`, name: `${fmtRA(ra)} ${fmtDec(dec)}`, group: 'sample', kind: 'field', ra, dec, description: 'Custom coordinates', aliases: [], epochs: DEFAULT_EPOCHS, amp: 0, spec: { T: 5000, ref: 1.6 }, inGaia: false, inWise: false });
function parseCoords(s: string): { ra: number; dec: number } | null {
  const t = s.trim();
  const m = t.match(/^(\d+(?:\.\d+)?)\s*[h: ]\s*(\d+(?:\.\d+)?)\s*[m: ]\s*(\d+(?:\.\d+)?)\s*s?\s*,?\s*([+\-−]?)\s*(\d+(?:\.\d+)?)\s*[d°: ]\s*(\d+(?:\.\d+)?)\s*['′m: ]\s*(\d+(?:\.\d+)?)/i);
  if (m) { const dec = (+m[5] + +m[6] / 60 + +m[7] / 3600) * (m[4] === '-' || m[4] === '−' ? -1 : 1); return { ra: (+m[1] + +m[2] / 60 + +m[3] / 3600) * 15, dec }; }
  const p = t.replace('−', '-').split(/[\s,]+/).map(Number);
  if (p.length === 2 && p.every(Number.isFinite) && p[1] >= -90 && p[1] <= 90) return { ra: wrap(p[0]), dec: p[1] };
  return null;
}
const angDist = (a: View, ra: number, dec: number) => Math.acos(Math.min(1, Math.sin(a.dec * D) * Math.sin(dec * D) + Math.cos(a.dec * D) * Math.cos(dec * D) * Math.cos((a.ra - ra) * D))) / D;

/* ---------- tiny SVG plot ---------- */
type Pt = { x: number; y: number; e?: number; c?: string };
function Plot({ pts, xl, yl, color = '#5ef2d0', line = true }: { pts: Pt[]; xl: string; yl: string; color?: string; line?: boolean }) {
  const W = 290, H = 120, L = 38, B = 20, T = 8, Rr = 6;
  if (!pts.length) return null;
  const xs = pts.map((p) => p.x), ys = pts.flatMap((p) => [p.y - (p.e ?? 0), p.y + (p.e ?? 0)]);
  const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys), pad = (y1 - y0) * 0.1 || 1;
  const sx = (x: number) => L + ((x - x0) / (x1 - x0 || 1)) * (W - L - Rr), sy = (y: number) => T + (1 - (y - (y0 - pad)) / (y1 - y0 + 2 * pad)) * (H - T - B);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="plot" role="img" aria-label={`${yl} versus ${xl}`}>
      <line x1={L} y1={H - B} x2={W - Rr} y2={H - B} stroke="#667" /><line x1={L} y1={T} x2={L} y2={H - B} stroke="#667" />
      {line && <path d={pts.map((p, i) => `${i ? 'L' : 'M'}${sx(p.x)},${sy(p.y)}`).join('')} fill="none" stroke={color} strokeOpacity=".45" />}
      {pts.map((p, i) => (<g key={i}>{p.e ? <line x1={sx(p.x)} x2={sx(p.x)} y1={sy(p.y - p.e)} y2={sy(p.y + p.e)} stroke={p.c ?? color} strokeOpacity=".4" /> : null}<circle cx={sx(p.x)} cy={sy(p.y)} r="2.6" fill={p.c ?? color} /></g>))}
      <text x={W / 2} y={H - 4} className="pl" textAnchor="middle">{xl}</text><text x="8" y={H / 2} className="pl" textAnchor="middle" transform={`rotate(-90 8 ${H / 2})`}>{yl}</text>
      <text x={L - 3} y={T + 8} className="pl" textAnchor="end">{y1.toFixed(0)}</text><text x={L - 3} y={H - B} className="pl" textAnchor="end">{y0.toFixed(0)}</text>
    </svg>
  );
}
const ARR_COL = ['#7fd3ff', '#5ef2d0', '#b6f06b', '#f2d54a', '#ff9a55', '#ff6b8a'];

/* ---------- tutorial cards ---------- */
type Preset = Partial<{ op: 'single' | 'add' | 'sub'; bandMode: 'all' | 'array' | 'band'; arr: number; gaia: boolean; pm: boolean; fov: number }>;
type Card = { id: string; title: string; blurb: string; icon: ReactNode; pos: string; target?: string; preset?: Preset; steps: string[] };
const CARDS: Card[] = [
  { id: 'intro', title: 'Introduction to LumenX', blurb: 'Learn the globe, search and timeline.', icon: <Telescope size={22} />, pos: '10% 20%', steps: ['This globe is the whole sky. Drag to rotate it and scroll to zoom. Cyan rings are the challenge test targets.', 'Click a ring or any patch of sky, or type a name or “RA, Dec” in the search box (top right), and the view zooms into that patch.', 'The left panel chooses what you see: catalogue overlays, wavelength bands (all 102, one of the six arrays, or one band) and the field of view.', 'The timeline at the bottom steps through every SPHEREx visit. Press play (or Space) to blink through them like a little video and spot what moves.', 'Click any pixel for its spectrum. The share and embed buttons (top right) copy a link to exactly what you see.'] },
  { id: 'barnard', title: 'Barnard’s Star: a fast mover', blurb: 'Watch the star drift between visits.', icon: <Rocket size={22} />, pos: '50% 30%', target: 'barnard', preset: { op: 'single', gaia: true, pm: false }, steps: ['Barnard’s Star has the largest known proper motion, about 10″ a year.', 'Press play on the timeline. The white ring marks where the star is expected; the blue Gaia circles are the 2016 catalogue positions.', 'Turn on “Move catalogue to observation epoch” in the left panel and watch the Gaia circle catch up with the star.'] },
  { id: 'wise', title: 'WISE 0855: a faint brown dwarf', blurb: 'Co-add bands and subtract visits.', icon: <Orbit size={22} />, pos: '90% 70%', target: 'wise0855', preset: { op: 'sub', bandMode: 'all' }, steps: ['WISE 0855−0714 is extremely cold, so it is nearly invisible at short wavelengths.', 'Difference mode subtracts the previous visit from the current one: stars cancel, movers leave a teal and orange pair. Rings mark detections.', 'Switch Wavelength to “By array” and try array 5 or 6 (about 4–5 µm), where this object is brightest.'] },
  { id: 'var', title: 'Variable stars: R Draconis', blurb: 'Brightness curves across visits.', icon: <Activity size={22} />, pos: '30% 80%', target: 'rdra', preset: { op: 'single', bandMode: 'array', arr: 1 }, steps: ['R Draconis is a Mira variable that swells and fades over about 245 days.', 'Step through the timeline: the card at bottom left plots its brightness at each visit.', 'Pick a different array in the left panel to see how the amplitude changes with wavelength.'] },
  { id: 'spec', title: 'Spectra on the fly', blurb: 'Click a pixel, get 102 bands.', icon: <Waypoints size={22} />, pos: '70% 10%', target: 'epsindib', preset: { bandMode: 'all' }, steps: ['Epsilon Indi B is a brown dwarf pair, so its spectrum has molecular absorption dips.', 'Click the centre of the field. The spectrum card plots all 102 bands, coloured by detector array.', 'Switch on “Contamination flags” to see hot pixels, cosmic rays and bright-star halos before you trust a value.'] },
  { id: 'share', title: 'Share & embed', blurb: 'Every view lives in the URL.', icon: <Link2 size={22} />, pos: '20% 55%', target: 'rwaur', steps: ['Everything you set (position, field of view, bands, visit, overlays) is stored in the page address.', 'The share button copies a link; the code button copies an iframe snippet that hides the controls.', 'You can also type an address like ?ra=76.9565&dec=30.4014&fov=8 yourself.'] },
];

/* ---------- component ---------- */
type Op = 'single' | 'add' | 'sub';
export function ExplorationPage() {
  const url = useMemo(() => readUrl(window.location.search), []);
  const [mode, setMode] = useState<'sky' | 'cutout'>('sky');
  const [view, setView] = useState<View>({ ra: 100, dec: 15, R: GLOBE_R });
  const [target, setTarget] = useState<TargetDef | null>(null);
  const [fov, setFov] = useState(url.fov && url.fov >= 2 && url.fov <= 30 ? url.fov : 10);
  const [ep, setEp] = useState(url.epochs?.[0] ?? 0);
  const [op, setOp] = useState<Op>(url.op === 'add' || url.op === 'sub' ? url.op : 'single');
  const [bandMode, setBandMode] = useState<'all' | 'array' | 'band'>(url.mode === 'array' ? 'array' : url.mode === 'band' ? 'band' : 'all');
  const [arr, setArr] = useState(url.arr ? url.arr - 1 : 3);
  const [band, setBand] = useState(url.band ?? 40);
  const [ov, setOv] = useState({ gaia: url.overlay.includes('gaia'), wise: url.overlay.includes('wise'), pm: url.pm, mask: url.mask, exp: true, grid: true });
  const [playing, setPlaying] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [pick, setPick] = useState<{ x: number; y: number } | null>(null);
  const [hover, setHover] = useState<{ x: number; y: number } | null>(null);
  const [zoom, setZoom] = useState(1);
  const [tab, setTab] = useState<'layers' | 'targets' | 'data'>('layers');
  const [collapsed, setCollapsed] = useState(() => window.innerWidth < 820);
  const [welcome, setWelcome] = useState(() => { let skip = false; try { skip = !!localStorage.getItem('lumenx-skip'); } catch { /* ignore */ } return !skip && !url.target && url.ra === undefined; });
  const [about, setAbout] = useState(false);
  const [tour, setTour] = useState<{ card: Card; step: number } | null>(null);
  const [q, setQ] = useState('');
  const [toast, setToast] = useState('');
  const [detId, setDetId] = useState(baselineDetector.id);
  const wheelAcc = useRef(0), flyRef = useRef(0), cache = useRef(new Map<string, ReturnType<typeof renderBands>>()), viewRef = useRef(view);
  viewRef.current = view;
  const embed = url.embed;
  const say = (m: string) => { setToast(m); window.setTimeout(() => setToast(''), 2800); };

  /* fly-to: rotate the globe, dip out if far away, then zoom into the patch */
  const fly = useCallback((ra: number, dec: number, R1: number, done?: () => void) => {
    const id = ++flyRef.current, t0 = performance.now(), v0 = viewRef.current;
    const dist = angDist(v0, ra, dec), dur = Math.min(3400, 1300 + dist * 9 + Math.abs(Math.log(R1 / v0.R)) * 170), dRa = ((ra - v0.ra + 540) % 360) - 180;
    const lR0 = Math.log(v0.R), lR1 = Math.log(R1), dip = Math.min(1, dist / 25) * Math.max(2.1, (Math.max(lR0, lR1) - Math.log(GLOBE_R)) * 0.85);
    const step = (now: number) => {
      if (id !== flyRef.current) return;
      const k = Math.min(1, (now - t0) / dur), e = k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
      setView({ ra: wrap(v0.ra + dRa * e), dec: v0.dec + (dec - v0.dec) * e, R: Math.max(GLOBE_R * 0.8, Math.exp(lR0 + (lR1 - lR0) * e - dip * Math.sin(Math.PI * k))) });
      if (k < 1) requestAnimationFrame(step); else done?.();
    };
    requestAnimationFrame(step);
  }, []);

  const select = useCallback((t: TargetDef, preset?: Preset, instant = false) => {
    setPlaying(false); setPick(null); setEp(0); setZoom(1); setWelcome(false); if (window.innerWidth < 820) setCollapsed(true);
    if (preset) { if (preset.op) setOp(preset.op); if (preset.bandMode) setBandMode(preset.bandMode); if (preset.arr !== undefined) setArr(preset.arr); if (preset.fov) setFov(preset.fov); setOv((o) => ({ ...o, gaia: preset.gaia ?? o.gaia, pm: preset.pm ?? o.pm })); }
    setTarget(t);
    if (instant) { flyRef.current++; setView({ ra: t.ra, dec: t.dec, R: endR(preset?.fov ?? fov) }); setMode('cutout'); return; }
    setMode('sky'); fly(t.ra, t.dec, endR(preset?.fov ?? fov), () => setMode('cutout'));
  }, [fly, fov]);
  const goHome = () => { setPlaying(false); setMode('sky'); setTour(null); fly(viewRef.current.ra, Math.max(-40, Math.min(60, viewRef.current.dec)), GLOBE_R); };
  const search = (s: string) => {
    const t = resolveName(s); if (t) { setTour(null); return select(t); }
    const c = parseCoords(s); if (c) { setTour(null); return select(customTarget(c.ra, c.dec)); }
    say('Not found. Try “WISE 0855”, “Barnard’s Star”, or coordinates like “133.795, −7.245” or “08h55m10.8s −07d14m42s”.');
  };
  const startCard = (c: Card) => {
    setWelcome(false); setTour({ card: c, step: 0 });
    const t = c.target ? TARGETS.find((x) => x.id === c.target) : undefined;
    if (t) select(t, c.preset);
  };

  useEffect(() => {
    const t = url.target ? TARGETS.find((x) => x.id === url.target) ?? resolveName(url.target) : undefined;
    if (t) select(t, undefined, true); else if (url.ra !== undefined && url.dec !== undefined) select(customTarget(wrap(url.ra), url.dec), undefined, true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ---------- derived data ---------- */
  const sc = useMemo(() => (target ? buildScene(target, fov) : null), [target, fov]);
  const bands = useMemo(() => (bandMode === 'all' ? ALL_BANDS : bandMode === 'array' ? bandsOfArray(arr) : [band]), [bandMode, arr, band]);
  const nEp = sc?.years.length ?? 0;
  const getR = useCallback((e: number) => {
    if (!sc) throw new Error('no scene');
    const k = `${sc.target.id}|${fov}|${bandMode}${arr}${band}|${e}`, c = cache.current, hit = c.get(k);
    if (hit) return hit;
    if (c.size > 90) c.clear();
    const r = renderBands(sc, e, bands); c.set(k, r); return r;
  }, [sc, fov, bandMode, arr, band, bands]);

  const frame = useMemo(() => {
    if (!sc) return null;
    const n = sc.w * sc.h, cur = getR(Math.min(ep, nEp - 1));
    if (op === 'single') return { data: cur.data, sigma: cur.sigma, a: null as Float32Array | null, sigmaA: 0, ref: stretchOf(getR(0).data) };
    if (op === 'add') { const s = new Float32Array(n); for (let e = 0; e < nEp; e++) { const d = getR(e).data; for (let i = 0; i < n; i++) s[i] += d[i] / nEp; } return { data: s, sigma: cur.sigma / Math.sqrt(nEp), a: null, sigmaA: 0, ref: stretchOf(s) }; }
    const r = getR(ep > 0 ? ep - 1 : Math.min(1, nEp - 1)), d = new Float32Array(n);
    for (let i = 0; i < n; i++) d[i] = cur.data[i] - r.data[i];
    return { data: d, sigma: Math.hypot(cur.sigma, r.sigma), a: r.data, sigmaA: r.sigma, ref: { lo: 0, hi: 1 } };
  }, [sc, ep, op, getR, nEp]);

  const rgba = useMemo(() => {
    if (!sc || !frame) return null;
    const n = sc.w * sc.h, out = new Uint8ClampedArray(n * 4);
    for (let i = 0; i < n; i++) {
      if (op === 'sub') { const z = frame.data[i] / frame.sigma, t = Math.min(1, Math.abs(z) / 8), p = z >= 0; out[i * 4] = (p ? 70 : 255) * t; out[i * 4 + 1] = (p ? 255 : 150) * t; out[i * 4 + 2] = (p ? 220 : 60) * t; }
      else { const v = applyStretch(frame.data[i], frame.ref.lo, frame.ref.hi); out[i * 4] = 255 * Math.min(1, v * 1.5); out[i * 4 + 1] = 255 * Math.min(1, Math.max(0, v * 1.25 - 0.1)); out[i * 4 + 2] = 255 * Math.min(1, Math.max(0, v * 1.5 - 0.45)); }
      out[i * 4 + 3] = 255;
    }
    return out;
  }, [sc, frame, op]);

  const residuals = useMemo(() => {
    if (!sc || !frame || op !== 'sub' || !frame.a) return [];
    const det = listChangeDetectors().find((d) => d.id === detId) ?? baselineDetector, cur = getR(ep);
    const prob = det.detect({ a: frame.a, b: cur.data, sigmaA: frame.sigmaA, sigmaB: cur.sigma, width: sc.w, height: sc.h });
    return findResiduals(prob, frame.a, cur.data, frame.sigma, sc.w, sc.h);
  }, [sc, frame, op, ep, detId, getR]);

  const patchCanvas = useMemo(() => { if (!rgba || !sc) return null; const c = document.createElement('canvas'); c.width = sc.w; c.height = sc.h; c.getContext('2d')?.putImageData(new ImageData(new Uint8ClampedArray(rgba), sc.w, sc.h), 0, 0); return c; }, [rgba, sc]);
  const marks = useMemo(() => {
    if (!sc) return { exp: [] as Mark[], gaia: [] as Mark[], wise: [] as Mark[] };
    const yr = sc.years[ep], inb = (m: Mark) => m.x >= -1 && m.y >= -1 && m.x <= sc.w && m.y <= sc.h;
    const exp: Mark[] = ov.exp ? sc.sources.filter((s) => s.label && !s.label.startsWith('Unlisted')).map((s) => { const p = sourcePos(s, yr, sc.t0), q2 = toPixel(sc, p.e, p.n); return { x: q2.x, y: q2.y, label: s.label }; }).filter(inb) : [];
    const cat = (w: 'gaia' | 'wise') => (ov[w] ? catalogue(sc, w, yr, ov.pm).map((c) => { const q2 = toPixel(sc, c.e, c.n); return { x: q2.x, y: q2.y }; }).filter(inb) : []);
    return { exp, gaia: cat('gaia'), wise: cat('wise') };
  }, [sc, ep, ov]);
  const mask = useMemo(() => (sc && ov.mask ? flagMap(sc, ep, bands) : null), [sc, ep, ov.mask, bands]);
  const spec = useMemo(() => (sc && pick ? spectrumAt(sc, ep, pick.x, pick.y) : null), [sc, ep, pick]);
  const curve = useMemo(() => {
    if (!sc || !sc.sources.some((s) => s.isTarget) || nEp < 3) return [];
    return sc.years.map((_, e) => { const b = targetBrightness(sc, e, bands); return b ? { x: sc.mjd[e] - sc.mjd[0], y: b.flux, e: b.err, c: e === ep ? '#ffffff' : undefined } : null; }).filter(Boolean) as Pt[];
  }, [sc, nEp, bands, ep]);
  const hov = sc && hover ? { ...skyAt(sc, hover.x, hover.y), v: pixelMean(sc, ep, hover.x, hover.y, bands), f: mask ? mask[hover.y * sc.w + hover.x] : 0 } : null;

  useEffect(() => { if (!playing || !nEp) return; const id = window.setInterval(() => setEp((e) => (e + 1) % nEp), 1000 / speed); return () => window.clearInterval(id); }, [playing, speed, nEp]);
  useEffect(() => {
    const k = (e: KeyboardEvent) => { if ((e.target as HTMLElement).tagName === 'INPUT') return; if (e.code === 'Space' && mode === 'cutout') { e.preventDefault(); setPlaying((p) => !p); }
      if (e.key === 'Escape') { if (welcome) setWelcome(false); else if (about) setAbout(false); else if (mode === 'cutout') goHome(); } };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, welcome, about]);

  useEffect(() => {
    if (mode !== 'cutout' || !target) return;
    const p = new URLSearchParams();
    if (TARGETS.some((t) => t.id === target.id)) p.set('target', target.id); else { p.set('ra', target.ra.toFixed(4)); p.set('dec', target.dec.toFixed(4)); }
    p.set('fov', String(fov)); p.set('mode', bandMode); if (bandMode === 'array') p.set('arr', String(arr + 1)); if (bandMode === 'band') p.set('band', BANDS[band].center.toFixed(2));
    p.set('epochs', String(ep + 1)); p.set('op', op);
    const o = [ov.gaia && 'gaia', ov.wise && 'wise'].filter(Boolean).join(','); if (o) p.set('overlay', o); if (ov.pm) p.set('pm', '1'); if (ov.mask) p.set('mask', '1'); if (embed) p.set('embed', '1');
    try { window.history.replaceState(null, '', `${window.location.pathname}?${p}`); } catch { /* ignore */ }
  }, [mode, target, fov, bandMode, arr, band, ep, op, ov, embed]);

  const copy = (text: string, msg: string) => navigator.clipboard?.writeText(text).then(() => say(msg), () => say('Copy failed. Copy the address bar instead.'));
  const embedCode = () => { const u = new URL(window.location.href); u.searchParams.set('embed', '1'); return `<iframe src="${u.toString()}" width="640" height="480" style="border:0" title="LumenX"></iframe>`; };
  const shot = () => {
    const src = (mode === 'cutout' ? document.querySelector('.sky-frame canvas') : document.querySelector('.sky-map')) as HTMLCanvasElement | null; if (!src) return;
    const c = document.createElement('canvas'); c.width = mode === 'cutout' ? 900 : src.width; c.height = mode === 'cutout' ? 900 : src.height;
    const x = c.getContext('2d'); if (!x) return; x.imageSmoothingEnabled = false; x.drawImage(src, 0, 0, c.width, c.height);
    const a = document.createElement('a'); a.download = `spherex-${target?.id ?? 'sky'}.png`; a.href = c.toDataURL('image/png'); a.click(); say('Image saved');
  };
  const eye = (k: 'gaia' | 'wise' | 'exp' | 'mask' | 'grid', label: string, sub: string, swatch?: string) => (
    <button className={`layer ${ov[k] ? 'on' : ''}`} onClick={() => setOv({ ...ov, [k]: !ov[k] })} aria-pressed={ov[k]}>
      {ov[k] ? <Eye size={18} /> : <EyeOff size={18} />}<span className="ltxt"><b>{label}</b><i>{sub}</i></span>{swatch && <span className="sw" style={{ background: swatch }} />}
    </button>
  );
  const tdate = (iso: string) => (Date.parse(iso) - Date.parse('2025-03-01')) / (Date.parse('2026-12-01') - Date.parse('2025-03-01'));
  const epochs = target?.epochs ?? TARGETS[0].epochs, cur = Math.min(ep, epochs.length - 1);
  const months = Array.from({ length: 21 }, (_, i) => { const d = new Date(Date.UTC(2025, 2 + i, 1)); return { t: tdate(d.toISOString().slice(0, 10)), y: d.getUTCFullYear(), m: d.getUTCMonth() }; });
  const est = sizeEstimate(fov, nEp || 6);

  return (
    <div className={`app ${embed ? 'embed' : ''}`}>
      <SkyMap view={view} setView={(v) => { flyRef.current++; setView(v); }} visible={mode === 'sky'} targets={TARGETS} activeId={target?.id} grid={ov.grid} patch={patchCanvas && sc ? { img: patchCanvas, ra: sc.target.ra, dec: sc.target.dec, fovDeg: fov / 60 } : null}
        onSelect={(t) => { setTour(null); select(t); }} onSelectCoords={(ra, dec) => { setTour(null); select(customTarget(ra, dec)); }} />

      <div className={`cutout ${mode === 'cutout' ? 'in' : ''}`} onWheel={(e) => { if (zoom <= 1 && e.deltaY > 0) { wheelAcc.current += e.deltaY; if (wheelAcc.current > 260) { wheelAcc.current = 0; goHome(); return; } } else wheelAcc.current = 0; setZoom((z) => Math.max(1, Math.min(3, z - e.deltaY * 0.002))); }}>
        {sc && rgba && frame && (
          <div className="frame-wrap">
            <SkyFrame rgba={rgba} w={sc.w} h={sc.h} mask={mask} zoom={zoom} pick={pick} onPick={(x, y) => setPick({ x, y })} onHover={setHover}
              expected={marks.exp} gaia={marks.gaia} wise={marks.wise} residuals={residuals} ariaLabel={`SPHEREx field around ${sc.target.name}, visit ${cur + 1}`} />
          </div>
        )}
      </div>

      <aside className={`side ${collapsed ? 'collapsed' : ''}`}>
        <header className="brand"><img src="/lumenx-symbol.png" alt="" /><div><h1>Lumen<span>X</span></h1><small>SPHEREx · the changing infrared sky</small></div></header>
        <nav className="tabs">
          {([['layers', <Layers size={16} key="l" />, 'Layers'], ['targets', <Telescope size={16} key="t" />, 'Targets'], ['data', <Database size={16} key="d" />, 'Data']] as const).map(([id, ic, label]) => (
            <button key={id} className={tab === id ? 'on' : ''} onClick={() => setTab(id)}>{ic}{label}</button>))}
          <button className="collapse" onClick={() => setCollapsed(true)} aria-label="Collapse panel"><ChevronsLeft size={18} /></button>
        </nav>
        <div className="scroll">
          {tab === 'layers' && (<>
            <h4>Reference</h4>
            {eye('grid', 'Sky grid', 'RA / Dec lines on the globe')}
            {eye('exp', 'Expected position', 'Where the target should be at this visit', '#fff')}
            {eye('gaia', 'Gaia catalogue', 'Stars, epoch 2016.0', '#7fd3ff')}
            {eye('wise', 'WISE catalogue', 'Infrared sources, epoch ≈ 2010', '#ffb86b')}
            <label className="check"><input type="checkbox" checked={ov.pm} onChange={(e) => setOv({ ...ov, pm: e.target.checked })} /> Move catalogue to observation epoch</label>
            {eye('mask', 'Contamination flags', 'Hot pixels, cosmic rays, halos, edges')}
            {ov.mask && <ul className="legend">{FLAG_INFO.map((f) => <li key={f.bit} title={f.text}><span style={{ background: f.color }} />{f.name}</li>)}</ul>}
            <h4>Wavelength · co-add</h4>
            <div className="seg">{(['all', 'array', 'band'] as const).map((m) => <button key={m} className={bandMode === m ? 'on' : ''} onClick={() => setBandMode(m)}>{m === 'all' ? 'All 102' : m === 'array' ? 'By array' : 'One band'}</button>)}</div>
            {bandMode === 'array' && <div className="arrs">{Array.from({ length: 6 }, (_, a) => <button key={a} className={arr === a ? 'on' : ''} style={{ '--c': ARR_COL[a] } as CSSProperties} onClick={() => setArr(a)}>{a + 1}<small>{ARRAY_EDGES[a].toFixed(1)}–{ARRAY_EDGES[a + 1].toFixed(1)} µm</small></button>)}</div>}
            {bandMode === 'band' && <><input type="range" min={0} max={101} value={band} onChange={(e) => setBand(+e.target.value)} aria-label="Band" /><p className="hint">Band {band + 1} of 102 · {BANDS[band].center.toFixed(2)} µm</p></>}
            <p className="hint">{bands.length} band{bands.length > 1 ? 's' : ''} added together; noise drops by √{bands.length}.</p>
            <h4>Time</h4>
            <div className="seg">{([['single', 'Single visit'], ['add', 'Co-add visits'], ['sub', 'Difference']] as const).map(([m, l]) => <button key={m} className={op === m ? 'on' : ''} onClick={() => setOp(m)}>{l}</button>)}</div>
            <p className="hint">{op === 'sub' ? 'Current visit minus the previous one. Movers show as a teal and orange pair.' : op === 'add' ? 'All visits stacked: deeper, but movers smear.' : 'Press play on the timeline to blink through visits.'}</p>
            {op === 'sub' && <select value={detId} onChange={(e) => setDetId(e.target.value)} aria-label="Detector">{listChangeDetectors().map((d) => <option key={d.id} value={d.id}>{d.label}</option>)}</select>}
            <h4>Field of view</h4>
            <input type="range" min={2} max={30} value={fov} onChange={(e) => setFov(+e.target.value)} aria-label="Field of view" />
            <p className="hint">{fov}′ × {fov}′ · {est.n}×{est.n} px · est. download {fmtBytes(est.total)}. Bigger fields catch faster movers.</p>
          </>)}
          {tab === 'targets' && (<>
            <h4>Challenge test targets</h4>
            {TARGETS.filter((t) => t.group === 'test').map((t) => <button key={t.id} className={`trow ${target?.id === t.id ? 'on' : ''}`} onClick={() => { setTour(null); select(t); }}><b>{t.name}</b><i>{t.description}</i></button>)}
            <h4>Sample fields</h4>
            {TARGETS.filter((t) => t.group === 'sample').map((t) => <button key={t.id} className="trow" onClick={() => { setTour(null); select(t); }}><b>{t.name}</b><i>{t.description}</i></button>)}
          </>)}
          {tab === 'data' && (<>
            <h4>Dataset</h4>
            <p className="hint"><b>{MANIFEST.source}</b><br />Version {MANIFEST.version} · updated {MANIFEST.updated}<br />Pixel scale {PIXEL_ARCSEC}″ · 102 bands · 6 arrays</p>
            <p className="warn">Demo data only. Images, dates and spectra are synthetic: they show the interface, not real SPHEREx measurements.</p>
            <h4>Updating</h4>
            <p className="hint">Replace the generator in <code>demoData.ts</code> with calls to your data service (same shapes). New releases appear when the manifest version changes.</p>
          </>)}
        </div>
        <footer><button onClick={() => setAbout(true)}><Info size={15} /> About</button><button onClick={() => setWelcome(true)}><Sparkles size={15} /> Tutorials</button><button onClick={goHome}><Home size={15} /> All sky</button></footer>
      </aside>
      {collapsed && <button className="expand" onClick={() => setCollapsed(false)} aria-label="Expand panel"><ChevronsRight size={20} /></button>}

      <div className="top">
        {mode === 'cutout' && <button className="backbtn" onClick={goHome} aria-label="Back to all sky"><ArrowLeft size={17} /><span>All sky</span></button>}
        <form className="search" onSubmit={(e) => { e.preventDefault(); if (q.trim()) search(q); }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name or RA, Dec" aria-label="Search" list="names" />
          <datalist id="names">{TARGETS.map((t) => <option key={t.id} value={t.name} />)}</datalist>
          <button type="submit" aria-label="Go"><Search size={16} /></button>
        </form>
        <button className="ibtn blue" title="Fly to the current target" onClick={() => target && select(target)}><Crosshair size={18} /></button>
        <button className="ibtn" title="Copy link" onClick={() => copy(window.location.href, 'Link copied')}><Share2 size={18} /></button>
        <button className="ibtn hide-m" title="Copy embed code" onClick={() => copy(embedCode(), 'Embed code copied')}><Code size={18} /></button>
        <button className="ibtn hide-m" title="Save image" onClick={shot}><Camera size={18} /></button>
        <button className="ibtn" title="Tutorials" onClick={() => setWelcome(true)}><Info size={18} /><em>6</em></button>
      </div>

      <div className="zoom"><button onClick={() => (mode === 'sky' ? setView({ ...view, R: Math.min(2e6, view.R * 1.5) }) : setZoom(Math.min(3, zoom + 0.5)))} aria-label="Zoom in"><Plus size={20} /></button>
        <button onClick={() => (mode === 'sky' ? setView({ ...view, R: Math.max(GLOBE_R * 0.7, view.R / 1.5) }) : zoom <= 1 ? goHome() : setZoom(Math.max(1, zoom - 0.5)))} aria-label={mode === 'cutout' && zoom <= 1 ? 'Zoom out to all sky' : 'Zoom out'}><Minus size={20} /></button></div>
      {mode === 'cutout' && sc && <div className="scale">{fov}′ field · {zoom.toFixed(1)}× · {PIXEL_ARCSEC}″ pixels</div>}
      <div className="readout">
        {mode === 'sky' ? <>Drag to rotate · scroll to zoom · click anywhere to open that patch</> : hov ? <>RA {fmtRA(hov.ra)} · Dec {fmtDec(hov.dec)} · {hov.v.flux.toFixed(1)} ± {hov.v.err.toFixed(1)} (demo units){hov.f ? ` · ${FLAG_INFO.filter((f) => hov.f & f.bit).map((f) => f.name).join(', ')}` : ''}</> : target && <>{target.name} · RA {fmtRA(target.ra)} · Dec {fmtDec(target.dec)} · click a pixel for its spectrum</>}
      </div>

      {mode === 'cutout' && (spec || curve.length > 0) && (
        <div className="cards-dock">
          {spec && pick && <div className="dcard"><h5>Spectrum · pixel {pick.x},{pick.y}<button onClick={() => setPick(null)} aria-label="Close"><X size={14} /></button></h5>
            <Plot pts={spec.map((s) => ({ x: s.lam, y: s.flux, e: s.err, c: ARR_COL[s.array] }))} xl="wavelength (µm)" yl="flux (demo)" /></div>}
          {curve.length > 0 && <div className="dcard"><h5>Light curve · {target?.name}</h5><Plot pts={curve} xl="days since first visit" yl="brightness (demo)" color="#ffd37a" /></div>}
        </div>
      )}

      <div className="tl">
        <div className="datebox">
          <b>{fmtWV(epochs[cur])}</b>
          <div className="ctl">
            <button onClick={() => setEp((e) => (e + nEp - 1) % Math.max(1, nEp))} disabled={mode !== 'cutout'} aria-label="Previous visit"><ChevronLeft size={22} /></button>
            <button onClick={() => setPlaying(!playing)} disabled={mode !== 'cutout'} aria-label={playing ? 'Pause' : 'Play'}>{playing ? <Pause size={20} /> : <Play size={20} />}</button>
            <button onClick={() => setEp((e) => (e + 1) % Math.max(1, nEp))} disabled={mode !== 'cutout'} aria-label="Next visit"><ChevronRight size={22} /></button>
            <button className="spd" onClick={() => setSpeed(speed >= 2 ? 0.5 : speed * 2)} title="Playback speed">{speed}×</button>
          </div>
          <small>Visit {mode === 'cutout' ? cur + 1 : '–'} / {epochs.length}</small>
        </div>
        <div className="strip" role="group" aria-label="Observation timeline">
          {months.map((m, i) => <span key={i} className={`mt ${m.m % 3 === 0 ? 'big' : ''}`} style={{ left: `${m.t * 100}%` }}>{m.m % 3 === 0 && <em>{MON[m.m]} {m.y}</em>}</span>)}
          {epochs.map((d, i) => <button key={d} className={`ep ${i === cur && mode === 'cutout' ? 'on' : ''}`} style={{ left: `${tdate(d) * 100}%` }} disabled={mode !== 'cutout'} onClick={() => { setEp(i); setPlaying(false); }} title={d} aria-label={`Visit ${i + 1}, ${d}`} />)}
          {mode !== 'cutout' && <div className="tlhint">Choose a target to see its SPHEREx visits</div>}
        </div>
      </div>

      {tour && !embed && (
        <div className="tour"><header>{tour.card.icon}<h3>{tour.card.title}</h3><button onClick={() => setTour(null)} aria-label="Close"><X size={18} /></button></header>
          <p>{tour.card.steps[tour.step]}</p>
          <footer><button onClick={() => setTour({ ...tour, step: Math.max(0, tour.step - 1) })} disabled={tour.step === 0} aria-label="Previous step"><ChevronLeft size={22} /></button><span>Step {tour.step + 1}/{tour.card.steps.length}</span>
            <button onClick={() => (tour.step + 1 < tour.card.steps.length ? setTour({ ...tour, step: tour.step + 1 }) : setTour(null))} aria-label="Next step"><ChevronRight size={22} /></button></footer></div>
      )}

      {welcome && !embed && (
        <div className="modal-bg" onClick={() => setWelcome(false)}><div className="modal" role="dialog" aria-label="Welcome" onClick={(e) => e.stopPropagation()}>
          <header><h2>Welcome to LumenX</h2><button onClick={() => setWelcome(false)} aria-label="Close"><X size={20} /></button></header>
          <p>Since 2025, NASA’s SPHEREx has mapped the whole sky every six months in 102 infrared bands. Pick a story to learn the tools, or <a href="#start" onClick={(e) => { e.preventDefault(); setWelcome(false); }}>start exploring <span className="go">→</span></a></p>
          <div className="cards">{CARDS.map((c) => <button key={c.id} className="card" onClick={() => startCard(c)} style={{ backgroundPosition: c.pos }}><span className="ci">{c.icon}</span><b>{c.title}</b><i>{c.blurb}</i></button>)}</div>
          <label className="check"><input type="checkbox" onChange={(e) => { try { localStorage.setItem('lumenx-skip', e.target.checked ? '1' : ''); } catch { /* ignore */ } }} /> Don’t show this on startup</label>
        </div></div>
      )}
      {about && (
        <div className="modal-bg" onClick={() => setAbout(false)}><div className="modal narrow" role="dialog" aria-label="About" onClick={(e) => e.stopPropagation()}>
          <header><h2>About LumenX</h2><button onClick={() => setAbout(false)} aria-label="Close"><X size={20} /></button></header>
          <p>LumenX is a public tool for spotting how the infrared sky changes. Enter a patch of sky and watch it play back as a short movie: movers such as comets, asteroids and brown dwarfs shift between visits, while variable stars pulse.</p>
          <p className="warn">This prototype runs on synthetic demo data that mimics SPHEREx’s structure (102 bands, six arrays, 6.2″ pixels). It is not connected to NASA/IRSA yet.</p>
          <p className="hint">Built for the NASA Space Apps Challenge “Planet X and SPHEREx”. Try Barnard’s Star, Epsilon Indi B, WISE 0855, RW Aurigae and R Draconis.</p>
        </div></div>
      )}
      {toast && <div className="toast" role="status">{toast}</div>}
    </div>
  );
}