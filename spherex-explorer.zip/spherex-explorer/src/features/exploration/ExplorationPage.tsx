import { useEffect, useMemo, useState } from 'react';
import type { FormEvent } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CircleHelp,
  Minus,
  Pause,
  Play,
  Plus,
  RotateCcw,
  Search,
  SlidersHorizontal,
  X,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { Brand } from '../../components/layout/Brand';
import {
  ALL_BANDS,
  BANDS,
  FLAG_INFO,
  PIXEL_ARCSEC,
  TARGETS,
  applyStretch,
  bandsInRange,
  bandsOfArray,
  buildScene,
  catalogue,
  flagMap,
  fmtBytes,
  mjdOf,
  nearestTarget,
  renderBands,
  resolveName,
  skyAt,
  sizeEstimate,
  sourcePos,
  spectrumAt,
  stretchOf,
  targetBrightness,
  targetById,
  toPixel,
} from './demoData';
import type { TargetDef } from './demoData';
import { findResiduals, listChangeDetectors } from './changeDetection';
import type { Residual } from './changeDetection';
import { readUrl, writeUrl } from './urlState';
import type { DisplayMode, EpochOp } from './urlState';
import { SkyFrame } from './SkyFrame';
import type { Mark } from './SkyFrame';
import { LightCurve, SpectrumChart } from './Charts';

const FOVS = [1, 3, 10, 30];
const MIN_EPOCHS_LC = 5;

const MODES: { id: DisplayMode; label: string }[] = [
  { id: 'band', label: 'Single band' },
  { id: 'array', label: 'Array co-add' },
  { id: 'all', label: 'All-band co-add' },
  { id: 'rgb', label: 'Colour composite' },
];

const OPS: { id: EpochOp; label: string }[] = [
  { id: 'single', label: 'Single' },
  { id: 'side', label: 'Side by side' },
  { id: 'blink', label: 'Blink' },
  { id: 'add', label: 'Add' },
  { id: 'sub', label: 'Subtract' },
];

const GLOSSARY = [
  ['What is a band?', 'SPHEREx splits infrared light into 102 narrow slices of colour, called bands, from 0.75 to 5 µm. Our eyes only see about 0.4–0.7 µm, so every band here is invisible light shown in greys or false colours.'],
  ['What is a detector array?', 'SPHEREx records the sky with six separate detectors (D1–D6). Each one covers its own stretch of wavelengths, 17 bands apiece.'],
  ['What is a co-add?', 'Adding (averaging) several images together. Random noise cancels out while real sources stay, so faint things become easier to see. An array co-add stacks the 17 bands of one detector; an all-band co-add stacks all 102.'],
  ['What is a colour composite?', 'You choose which wavelengths feed the red, green and blue channels. The colours are not what the eye would see, but they show how an object’s brightness changes with wavelength.'],
  ['What is a spectrum?', 'A plot of brightness against wavelength for one spot. Click the image to plot the spectrum for that pixel. The shaded band shows the uncertainty.'],
  ['What is an epoch?', 'One visit to the same patch of sky. Comparing epochs reveals things that moved or changed brightness.'],
  ['What is a difference image?', 'One epoch subtracted from another. Anything unchanged disappears; objects that moved show up as a bright and a dark spot side by side. Circled spots are changes much larger than the noise.'],
  ['What are quality flags?', 'Labels that warn a pixel may be unreliable (for example a hot pixel or glare from a bright star). Switch on the mask to see where they are.'],
  ['What is field of view (FOV)?', 'How much sky the cutout covers, measured in arcminutes. A wider field shows more but needs a much bigger download.'],
  ['What is proper motion?', 'Nearby stars slowly drift across the sky. Catalogues record where a star was at one date; the “move to observation epoch” option shifts it to where it should be on the observation date.'],
] as const;

const fmtMjd = (m: number) => m.toFixed(1);
const range = (n: number) => Array.from({ length: n }, (_, i) => i);

export function ExplorationPage() {
  const init = useMemo(() => readUrl(window.location.search), []);

  const start = useMemo(() => {
    let t: TargetDef | null = null;
    let err = '';

    if (init.target) {
      t = resolveName(init.target);
      if (!t) err = `Couldn’t find “${init.target}” in the available target catalogue.`;
    } else if (init.ra !== undefined && init.dec !== undefined) {
      const n = nearestTarget(init.ra, init.dec);

      if (n.distDeg < 0.5) {
        t = n.target;
      } else {
        err = `No available target covers RA ${init.ra}°, Dec ${init.dec}°.`;
      }
    }

    return { t: t ?? TARGETS[0], err };
  }, [init]);

  const embed = init.embed;

  const [targetId, setTargetId] = useState(start.t.id);
  const target = targetById(targetId) as TargetDef;
  const nEp0 = start.t.epochs.length;

  const [fov, setFov] = useState(
    init.fov && FOVS.includes(init.fov) ? init.fov : 10
  );
  const [pendingFov, setPendingFov] = useState(fov);
  const [cached, setCached] = useState<string[]>([
    `${start.t.id}:${fov}`,
  ]);
  const [fetching, setFetching] = useState(0);

  const [mode, setMode] = useState<DisplayMode>(init.mode ?? 'band');
  const [bandIdx, setBandIdx] = useState(init.band ?? 40);
  const [arr, setArr] = useState(
    Math.min(5, Math.max(0, (init.arr ?? 3) - 1))
  );

  const [rgb, setRgb] = useState<[number, number][]>([
    [2.42, 5],
    [1.64, 2.42],
    [0.75, 1.64],
  ]);

  const [cmp, setCmp] = useState<number[]>(() => {
    const epochs = (init.epochs ?? []).filter(
      (index: number) => index < nEp0
    );

    if (epochs.length) {
      return Array.from(new Set<number>(epochs)).sort(
        (a: number, b: number) => a - b
      );
    }

    return nEp0 > 1 ? [0, nEp0 - 1] : [0];
  });

  const [active, setActive] = useState(0);
  const [op, setOp] = useState<EpochOp>(
    init.op ?? (nEp0 > 1 ? 'side' : 'single')
  );

  const [detId, setDetId] = useState('baseline');
  const [showProb, setShowProb] = useState(false);
  const [overlay, setOverlay] = useState<string[]>(init.overlay);
  const [pm, setPm] = useState(init.pm);
  const [mask, setMask] = useState(init.mask);

  const [pick, setPick] = useState<{
    x: number;
    y: number;
  } | null>(null);

  const [hover, setHover] = useState<{
    x: number;
    y: number;
  } | null>(null);

  const [zoom, setZoom] = useState(1);
  const [phase, setPhase] = useState(0);
  const [bandPlay, setBandPlay] = useState(false);
  const [epochPlay, setEpochPlay] = useState(false);
  const [speed, setSpeed] = useState('1');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [helpOpen, setHelpOpen] = useState(false);
  const [analysisScreen, setAnalysisScreen] = useState<'spectrum' | 'lightcurve' | 'details' | 'share' | null>(null);

  const [message, setMessage] = useState(
    start.err ? `${start.err} Showing ${start.t.name} instead.` : ''
  );

  const [nameQ, setNameQ] = useState('');
  const [ra, setRa] = useState(String(start.t.ra));
  const [dec, setDec] = useState(String(start.t.dec));
  const [copied, setCopied] = useState('');

  const scene = useMemo(
    () => buildScene(target, fov),
    [target, fov]
  );

  const nEp = scene.years.length;

  const cmpSorted = useMemo(
    () => [...new Set(cmp.filter((i) => i < nEp))].sort((a, b) => a - b),
    [cmp, nEp]
  );

  const eff: EpochOp =
    cmpSorted.length < 2 && op !== 'single' ? 'single' : op;

  const isRgb = mode === 'rgb';

  const epochList =
    eff === 'single'
      ? [Math.min(active, nEp - 1)]
      : cmpSorted;

  const dispEp =
    eff === 'single'
      ? epochList[0]
      : eff === 'blink'
        ? epochList[phase % epochList.length]
        : epochList[epochList.length - 1];

  const channels: number[][] = useMemo(
    () =>
      isRgb
        ? rgb.map(([lo, hi]) => bandsInRange(lo, hi))
        : [
            mode === 'band'
              ? [bandIdx]
              : mode === 'array'
                ? bandsOfArray(arr)
                : ALL_BANDS,
          ],
    [isRgb, rgb, mode, bandIdx, arr]
  );

  const allBands = useMemo(
    () => [...new Set(channels.flat())],
    [channels]
  );

  const bandsKey = JSON.stringify(channels);
  const epochKey = epochList.join(',');

  /* initial pick = target position; refresh when the target changes */
  useEffect(() => {
    const t = scene.sources.find((s) => s.isTarget);

    if (!t) {
      setPick({
        x: Math.floor(scene.w / 2),
        y: Math.floor(scene.h / 2),
      });
      return;
    }

    const p = sourcePos(
      t,
      scene.years[Math.min(active, nEp - 1)],
      scene.t0
    );

    const q = toPixel(scene, p.e, p.n);

    setPick({
      x: Math.round(Math.min(scene.w - 1, Math.max(0, q.x))),
      y: Math.round(Math.min(scene.h - 1, Math.max(0, q.y))),
    });

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [targetId, fov]);

  /* timers */
  useEffect(() => {
    if (!bandPlay) return;

    const id = window.setInterval(() => {
      if (mode === 'band') {
        setBandIdx((b) => (b + 1) % 102);
      } else {
        setArr((a) => (a + 1) % 6);
      }
    }, 520 / Number(speed));

    return () => window.clearInterval(id);
  }, [bandPlay, speed, mode]);

  useEffect(() => {
    if (!epochPlay) return;

    const id = window.setInterval(
      () => setActive((i) => (i + 1) % nEp),
      2000 / Number(speed)
    );

    return () => window.clearInterval(id);
  }, [epochPlay, speed, nEp]);

  useEffect(() => {
    if (eff !== 'blink') return;

    const id = window.setInterval(
      () => setPhase((v) => v + 1),
      700
    );

    return () => window.clearInterval(id);
  }, [eff]);

  /* keep the address bar shareable */
  useEffect(() => {
    writeUrl({
      target: targetId,
      fov,
      band: bandIdx,
      mode,
      arr,
      epochs: cmpSorted,
      op: eff,
      overlay,
      pm,
      mask,
      embed,
    });
  }, [
    targetId,
    fov,
    bandIdx,
    mode,
    arr,
    cmpSorted,
    eff,
    overlay,
    pm,
    mask,
    embed,
  ]);

  /* frames */
  const frames = useMemo(
    () =>
      epochList.map((ep) =>
        channels.map((b) => renderBands(scene, ep, b))
      ),
    [scene, epochKey, bandsKey]
  ); // eslint-disable-line react-hooks/exhaustive-deps

  const detector =
    listChangeDetectors().find((d) => d.id === detId) ??
    listChangeDetectors()[0];

  const view = useMemo(() => {
    const n = scene.w * scene.h;
    const rgba = new Uint8ClampedArray(n * 4);

    let residuals: Residual[] = [];
    let sigma = frames[0][0].sigma;
    let values: Float32Array | null = null;
    let rgbaB: Uint8ClampedArray | null = null;

    const paint = (
      fr: { data: Float32Array }[],
      st: { lo: number; hi: number }[],
      out: Uint8ClampedArray
    ) => {
      for (let i = 0; i < n; i++) {
        if (fr.length === 1) {
          const v = applyStretch(
            fr[0].data[i],
            st[0].lo,
            st[0].hi
          );

          out[i * 4] = 8 + v * 205;
          out[i * 4 + 1] = 12 + v * 232;
          out[i * 4 + 2] = 18 + v * 226;
        } else {
          for (let c = 0; c < 3; c++) {
            out[i * 4 + c] =
              applyStretch(
                fr[c].data[i],
                st[c].lo,
                st[c].hi
              ) * 255;
          }
        }

        out[i * 4 + 3] = 255;
      }
    };

    if (eff === 'sub' && !isRgb) {
      const A = frames[0][0];
      const B = frames[frames.length - 1][0];
      const sg = Math.hypot(A.sigma, B.sigma);

      const prob = detector.detect({
        a: A.data,
        b: B.data,
        sigmaA: A.sigma,
        sigmaB: B.sigma,
        width: scene.w,
        height: scene.h,
      });

      residuals = findResiduals(
        prob,
        A.data,
        B.data,
        sg,
        scene.w,
        scene.h
      );

      values = new Float32Array(n);
      sigma = sg;

      for (let i = 0; i < n; i++) {
        const d = B.data[i] - A.data[i];
        values[i] = d;

        if (showProb) {
          const v = prob[i];
          rgba[i * 4] = 8 + v * 230;
          rgba[i * 4 + 1] = 12 + v * 220;
          rgba[i * 4 + 2] = 18 + v * 200;
        } else {
          const t = Math.min(
            1,
            Math.max(0, (Math.abs(d / sg) - 2) / 6)
          );

          const pos = d >= 0;
          const k = Math.pow(t, 0.7);

          rgba[i * 4] =
            8 + ((pos ? 40 : 245) - 8) * k;

          rgba[i * 4 + 1] =
            12 + ((pos ? 225 : 145) - 12) * k;

          rgba[i * 4 + 2] =
            18 + ((pos ? 195 : 70) - 18) * k;
        }

        rgba[i * 4 + 3] = 255;
      }

      return {
        rgba,
        rgbaB,
        residuals,
        sigma,
        values,
        label: showProb
          ? 'CHANGE PROBABILITY'
          : 'DIFFERENCE (LATER − EARLIER)',
      };
    }

    const nCh = frames[0].length;
    const baseStretch = frames[0].map((f) => stretchOf(f.data));

    if (eff === 'add') {
      const mean = range(nCh).map((c) => {
        const d = new Float32Array(n);

        frames.forEach((f) => {
          for (let i = 0; i < n; i++) {
            d[i] += f[c].data[i] / frames.length;
          }
        });

        return {
          data: d,
          sigma: frames[0][c].sigma / Math.sqrt(frames.length),
        };
      });

      paint(mean, mean.map((m) => stretchOf(m.data)), rgba);
      sigma = mean[0].sigma;
      values = mean[0].data;

      return {
        rgba,
        rgbaB,
        residuals,
        sigma,
        values,
        label: `SUM OF ${frames.length} EPOCHS (MEAN)`,
      };
    }

    if (eff === 'side') {
      rgbaB = new Uint8ClampedArray(n * 4);

      paint(frames[0], baseStretch, rgba);
      paint(frames[frames.length - 1], baseStretch, rgbaB);

      values = frames[frames.length - 1][0].data;

      return {
        rgba,
        rgbaB,
        residuals,
        sigma,
        values,
        label: 'SIDE BY SIDE',
      };
    }

    const cur =
      eff === 'blink'
        ? frames[phase % frames.length]
        : frames[0];

    paint(cur, baseStretch, rgba);

    values = nCh === 1 ? cur[0].data : null;
    sigma = cur[0].sigma;

    return {
      rgba,
      rgbaB,
      residuals,
      sigma,
      values,
      label:
        eff === 'blink'
          ? 'BLINK'
          : isRgb
            ? 'COLOUR COMPOSITE'
            : 'IMAGE',
    };
  }, [frames, eff, phase, showProb, detector, scene, isRgb]);

  const flags = useMemo(
    () => flagMap(scene, dispEp, allBands),
    [scene, dispEp, allBands]
  );

  const flagCounts = useMemo(
    () =>
      FLAG_INFO.map((f) =>
        flags.reduce((a, v) => a + (v & f.bit ? 1 : 0), 0)
      ),
    [flags]
  );

  /* markers */
  const tSrc = scene.sources.find((s) => s.isTarget);

  const markAt = (
    ep: number,
    label?: string,
    dashed?: boolean,
    color?: string
  ): Mark[] => {
    if (!tSrc) return [];

    const p = sourcePos(tSrc, scene.years[ep], scene.t0);
    const q = toPixel(scene, p.e, p.n);

    return [
      {
        x: q.x - 0.5,
        y: q.y - 0.5,
        label,
        dashed,
        color,
      },
    ];
  };

  const expected: Mark[] = useMemo(() => {
    if (!tSrc) return [];

    const at = (
      ep: number,
      label?: string,
      dashed?: boolean,
      color?: string
    ): Mark => markAt(ep, label, dashed, color)[0];

    if (eff === 'add') {
      return epochList.map((e) => at(e, undefined, true));
    }

    if (eff === 'sub') {
      return [
        at(epochList[0], 'A', true, '#ff9a55'),
        at(
          epochList[epochList.length - 1],
          'B',
          false,
          '#5ef2d0'
        ),
      ];
    }

    return [
      at(
        dispEp,
        target.kind === 'mover' ? 'expected' : undefined
      ),
    ];
  }, [
    tSrc,
    scene,
    eff,
    epochKey,
    dispEp,
    target.kind,
  ]); // eslint-disable-line react-hooks/exhaustive-deps

  const cat = (
    which: 'gaia' | 'wise',
    ep = dispEp
  ): Mark[] =>
    overlay.includes(which)
      ? catalogue(scene, which, scene.years[ep], pm)
          .map((c) => {
            const q = toPixel(scene, c.e, c.n);
            return { x: q.x - 0.5, y: q.y - 0.5 };
          })
          .filter(
            (m) =>
              m.x > -1 &&
              m.y > -1 &&
              m.x < scene.w &&
              m.y < scene.h
          )
      : [];

  const gaia = cat('gaia');
  const wise = cat('wise');

  /* spectrum + light curve */
  const spec = useMemo(
    () =>
      pick
        ? spectrumAt(scene, dispEp, pick.x, pick.y)
        : null,
    [scene, dispEp, pick]
  );

  const lcBands = isRgb ? ALL_BANDS : channels[0];

  const lc = useMemo(
    () =>
      range(nEp)
        .map((ep) => {
          const b = targetBrightness(scene, ep, lcBands);

          return b
            ? {
                mjd: scene.mjd[ep],
                flux: b.flux,
                err: b.err,
                date: target.epochs[ep],
              }
            : null;
        })
        .filter(
          (v): v is NonNullable<typeof v> => v !== null
        ),
    [scene, nEp, lcBands, target]
  );

  /* actions */
  function chooseTarget(id: string, note = true) {
    const t = targetById(id) as TargetDef;

    setTargetId(id);
    setRa(String(t.ra));
    setDec(String(t.dec));
    setActive(0);
    setOp(t.epochs.length > 1 ? 'side' : 'single');
    setBandPlay(false);
    setEpochPlay(false);

    setCmp(
      t.epochs.length > 1
        ? [0, t.epochs.length - 1]
        : [0]
    );

    setCached((c) =>
      c.includes(`${id}:${fov}`)
        ? c
        : [...c, `${id}:${fov}`]
    );

    if (note) {
      setMessage(
        `${t.name} selected.`
      );
    }
  }

  function submitName(e: FormEvent) {
    e.preventDefault();

    const t = resolveName(nameQ);

    if (t) {
      chooseTarget(t.id, false);
      setMessage(
        `Resolved “${nameQ}” to ${t.name}.`
      );
    } else {
      setMessage(
        `Couldn’t resolve “${nameQ}”. Try “Barnard’s Star” or “R Dra”.`
      );
    }
  }

  function submitCoords(e: FormEvent) {
    e.preventDefault();

    const r = Number(ra);
    const d = Number(dec);

    if (!Number.isFinite(r) || r < 0 || r >= 360) {
      return setMessage(
        'Right Ascension must be a number from 0° up to (but not including) 360°.'
      );
    }

    if (!Number.isFinite(d) || d < -90 || d > 90) {
      return setMessage(
        'Declination must be a number between −90° and +90°.'
      );
    }

    const n = nearestTarget(r, d);

    if (n.distDeg < 0.5) {
      chooseTarget(n.target.id, false);
      setMessage(`Position matches ${n.target.name}.`);
    } else {
      setMessage(
        `No available observation covers that position. Nearest catalogue region: ${n.target.name}, ${n.distDeg.toFixed(1)}° away.`
      );
    }
  }

  function applyFov(f: number) {
    setFov(f);

    setCached((c) =>
      c.includes(`${targetId}:${f}`)
        ? c
        : [...c, `${targetId}:${f}`]
    );

    setMessage('');
  }

  function startFetch() {
    setFetching(1);

    let p = 1;

    const id = window.setInterval(() => {
      p += 22;

      if (p >= 100) {
        window.clearInterval(id);
        setFetching(0);
        applyFov(pendingFov);
      } else {
        setFetching(p);
      }
    }, 260);
  }

  function toggleCmp(i: number) {
    setCmp((c) =>
      c.includes(i)
        ? c.length > 1
          ? c.filter((v) => v !== i)
          : c
        : [...c, i]
    );
  }

  async function copy(text: string, what: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(what);

      window.setTimeout(() => setCopied(''), 1600);
    } catch {
      setMessage(
        'Copy failed. Select the text and copy it manually.'
      );
    }
  }

  const toggleOverlay = (k: string) =>
    setOverlay((o) =>
      o.includes(k)
        ? o.filter((v) => v !== k)
        : [...o, k]
    );

  const setRange = (
    c: number,
    k: 0 | 1,
    v: number
  ) =>
    setRgb((r) =>
      r.map((p, i) => {
        if (i !== c) return p;

        const n: [number, number] = [p[0], p[1]];
        n[k] = v;

        if (n[0] >= n[1]) {
          if (k === 0) {
            n[1] = Math.min(5, v + 0.05);
          } else {
            n[0] = Math.max(0.75, v - 0.05);
          }
        }

        return n;
      })
    );

  const est = sizeEstimate(pendingFov, nEp);
  const isCached = cached.includes(`${targetId}:${pendingFov}`);

  const shareUrl =
    typeof window !== 'undefined'
      ? window.location.href
      : '';

  const embedUrl = shareUrl.includes('embed=1')
    ? shareUrl
    : shareUrl + '&embed=1';

  const band = BANDS[bandIdx];

  const hoverVal =
    hover && view.values
      ? view.values[hover.y * scene.w + hover.x]
      : null;

  const hoverSky = hover
    ? skyAt(scene, hover.x, hover.y)
    : null;

  const tl = (i: number) => {
    const a = scene.mjd[0];
    const b = scene.mjd[nEp - 1];

    return b === a
      ? 0
      : ((scene.mjd[i] - a) / (b - a)) * 100;
  };

  const bandLabel = isRgb
    ? 'R / G / B ranges'
    : mode === 'band'
      ? `${band.center.toFixed(2)} µm`
      : mode === 'array'
        ? `Array D${arr + 1} co-add`
        : 'All 102 bands';

  const cur = {
    date: target.epochs[dispEp],
    mjd: mjdOf(target.epochs[dispEp]),
  };

  const frameProps = {
    w: scene.w,
    h: scene.h,
    zoom,
    pick,
    onPick: (x: number, y: number) =>
      setPick({ x, y }),
    onHover: setHover,
    expected,
    gaia,
    wise,
    residuals: view.residuals,
  };

  const maskArr = mask ? flags : null;

  return (
    <div
      className={`explorer-page${embed ? ' embed-mode' : ''}`}
    >
      {!embed && (
        <header className="explorer-header">
          <Brand />

          <div className="explorer-header-right">
            <Link to="/" className="back-link">
              <ArrowLeft size={15} /> Overview
            </Link>
          </div>
        </header>
      )}

      <main className={`explorer-layout${!sidebarOpen && !embed ? ' sidebar-collapsed' : ''}`}>
        {!embed && sidebarOpen && (
          <aside className="explorer-sidebar" aria-label="Explorer controls">
            <div className="sidebar-topbar">
              <button className="sidebar-close" type="button" onClick={() => setSidebarOpen(false)} aria-label="Close controls">
                <X size={18} />
              </button>
            </div>
            <div className="sidebar-heading">
              <span>EXPLORE A REGION</span>
              <p>
                Choose a target, search by name, or enter coordinates.
              </p>
            </div>

            <label className="field-label" htmlFor="target-select">
              Target
            </label>

            <div className="select-wrap">
              <select
                id="target-select"
                value={targetId}
                onChange={(e) => chooseTarget(e.target.value)}
              >
                <optgroup label="Test targets">
                  {TARGETS.filter((t) => t.group === 'test').map(
                    (t) => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    )
                  )}
                </optgroup>

                <optgroup label="Sample regions">
                  {TARGETS.filter((t) => t.group === 'sample').map(
                    (t) => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    )
                  )}
                </optgroup>
              </select>

              <ChevronDown size={15} />
            </div>

            <p className="target-description">
              {target.description}
            </p>

            <form className="coordinate-form" onSubmit={submitName}>
              <div className="form-title">FIND BY NAME</div>

              <label className="field-label" htmlFor="name-input">
                Object name
              </label>

              <input
                id="name-input"
                value={nameQ}
                onChange={(e) => setNameQ(e.target.value)}
                placeholder="e.g. R Draconis"
              />

              <button className="search-region-button" type="submit">
                <Search size={15} /> Resolve name
              </button>
            </form>

            <form className="coordinate-form" onSubmit={submitCoords}>
              <div className="form-title">
                SKY COORDINATES
                <span title="RA measures position eastward along the celestial equator; Dec measures position north or south of it.">
                  <CircleHelp size={13} />
                </span>
              </div>

              <label className="field-label" htmlFor="ra-input">
                Right Ascension <small>degrees</small>
              </label>

              <input
                id="ra-input"
                value={ra}
                onChange={(e) => setRa(e.target.value)}
                inputMode="decimal"
              />

              <label className="field-label" htmlFor="dec-input">
                Declination <small>degrees</small>
              </label>

              <input
                id="dec-input"
                value={dec}
                onChange={(e) => setDec(e.target.value)}
                inputMode="decimal"
              />

              <button className="search-region-button" type="submit">
                <Search size={15} /> Go to coordinates
              </button>
            </form>

            <div className="coordinate-form">
              <div className="form-title">
                FIELD OF VIEW
                <span title="How much sky the cutout covers, in arcminutes (′).">
                  <CircleHelp size={13} />
                </span>
              </div>

              <div
                className="seg"
                role="group"
                aria-label="Field of view"
              >
                {FOVS.map((f) => (
                  <button
                    key={f}
                    className={pendingFov === f ? 'active' : ''}
                    onClick={() => setPendingFov(f)}
                    aria-pressed={pendingFov === f}
                  >
                    {f}′
                  </button>
                ))}
              </div>

              <p className="fine">
                {est.n} × {est.n} pixels · {nEp} epochs × 102 bands
                <br />
                Estimated download <b>{fmtBytes(est.total)}</b>{' '}
                <span className="muted">
                  (rough: 3 planes × 4 bytes per pixel)
                </span>
              </p>

              {pendingFov >= 10 && (
                <p className="warn">
                  <AlertTriangle size={14} />
                  {pendingFov === 30
                    ? 'Very large transfer. Consider a smaller field or fewer epochs.'
                    : 'Larger fields mean a noticeably bigger download.'}
                </p>
              )}

              {fetching > 0 ? (
                <div
                  className="progress"
                  role="progressbar"
                  aria-valuenow={fetching}
                  aria-valuemin={0}
                  aria-valuemax={100}
                >
                  <i style={{ width: `${fetching}%` }} />
                  <span>Preparing image cutouts…</span>
                </div>
              ) : pendingFov === fov ? (
                <p className="fine ok">
                  Showing this field of view.
                </p>
              ) : (
                <button
                  className="search-region-button"
                  onClick={startFetch}
                >
                  {isCached
                    ? 'Load from cache'
                    : `Load ${pendingFov}′ cutouts`}
                </button>
              )}

              {isCached && pendingFov !== fov && fetching === 0 && (
                <p className="fine ok">
                  Cached: no new download needed.
                </p>
              )}
            </div>

            <div className="coordinate-form">
              <div className="form-title">OVERLAYS</div>

              <label className="check">
                <input
                  type="checkbox"
                  checked={overlay.includes('gaia')}
                  onChange={() => toggleOverlay('gaia')}
                />
                <i className="sw gaia" /> Gaia sources
              </label>

              <label className="check">
                <input
                  type="checkbox"
                  checked={overlay.includes('wise')}
                  onChange={() => toggleOverlay('wise')}
                />
                <i className="sw wise" /> WISE / AllWISE sources
              </label>

              <label className="check">
                <input
                  type="checkbox"
                  checked={pm}
                  onChange={() => setPm((v) => !v)}
                />
                Move to observation epoch
                <span title="Shifts catalogue positions by each star’s proper motion so movers line up.">
                  <CircleHelp size={12} />
                </span>
              </label>

              <label className="check">
                <input
                  type="checkbox"
                  checked={mask}
                  onChange={() => setMask((v) => !v)}
                />
                Quality-flag mask
              </label>
            </div>

          {/* epochs */}
          <section className="timeline-section">
            <div className="timeline-heading">
              <div>
                <span className="eyebrow-small">OBSERVATION TIMELINE</span>
                <h2>Move through time</h2>
              </div>

              <span className="sequence-count">
                {String(dispEp + 1).padStart(2, '0')} <i>/</i>{' '}
                {String(nEp).padStart(2, '0')}
              </span>
            </div>

            <div
              className="timeline-track"
              aria-label="Choose an observation"
            >
              {range(nEp).map((i) => (
                <button
                  key={i}
                  className={`timeline-point ${
                    dispEp === i ? 'selected' : ''
                  }`}
                  style={{ left: `${tl(i)}%` }}
                  onClick={() => {
                    setActive(i);
                    setOp('single');
                    setEpochPlay(false);
                  }}
                  aria-label={`Select ${target.epochs[i]}`}
                >
                  <span className="timeline-dot" />
                  <span className="timeline-date">
                    {target.epochs[i].slice(2, 7)}
                  </span>
                </button>
              ))}
            </div>

            <div className="timeline-controls">
              <div className="playback-buttons">
                <button
                  onClick={() => {
                    setOp('single');
                    setEpochPlay(false);
                    setActive((i) => Math.max(0, i - 1));
                  }}
                  disabled={active === 0}
                  aria-label="Previous observation"
                >
                  <ChevronLeft size={18} />
                </button>

                <button
                  className="play-button"
                  onClick={() => {
                    setOp('single');
                    setEpochPlay((v) => !v);
                  }}
                  aria-label={
                    epochPlay
                      ? 'Pause playback'
                      : 'Play observations'
                  }
                >
                  {epochPlay ? (
                    <Pause size={16} />
                  ) : (
                    <Play size={16} />
                  )}
                </button>

                <button
                  onClick={() => {
                    setOp('single');
                    setEpochPlay(false);
                    setActive((i) => Math.min(nEp - 1, i + 1));
                  }}
                  disabled={active === nEp - 1}
                  aria-label="Next observation"
                >
                  <ChevronRight size={18} />
                </button>
              </div>
            </div>

            <div className="ctl-card">
              <div className="ctl-head">
                <b>Compare observations</b>
                <span>
                  Select at least two visits to reveal movement or
                  changing brightness
                </span>
              </div>

              <div
                className="chips"
                role="group"
                aria-label="Epochs to compare"
              >
                {range(nEp).map((i) => (
                  <label
                    key={i}
                    className={`chip ${cmp.includes(i) ? 'on' : ''}`}
                  >
                    <input
                      type="checkbox"
                      checked={cmp.includes(i)}
                      onChange={() => toggleCmp(i)}
                    />
                    {target.epochs[i]}
                  </label>
                ))}
              </div>

              <div
                className="seg"
                role="group"
                aria-label="Epoch operation"
              >
                {OPS.map((o) => (
                  <button
                    key={o.id}
                    className={eff === o.id ? 'active' : ''}
                    aria-pressed={eff === o.id}
                    disabled={
                      (o.id !== 'single' && cmpSorted.length < 2) ||
                      (o.id === 'sub' && isRgb)
                    }
                    onClick={() => setOp(o.id)}
                  >
                    {o.label}
                  </button>
                ))}
              </div>

              {cmpSorted.length < 2 && (
                <p className="fine">
                  Tick at least two epochs to enable Side by side,
                  Blink, Add and Subtract.
                </p>
              )}

              {isRgb && (
                <p className="fine">
                  Subtract works on one image at a time: switch to a
                  single band or co-add.
                </p>
              )}

              {eff === 'sub' && !isRgb && (
                <>
                  <div className="ctl-row wrap">
                    <label className="speed-control inline">
                      Detector
                      <select
                        value={detId}
                        onChange={(e) => setDetId(e.target.value)}
                      >
                        {listChangeDetectors().map((d) => (
                          <option key={d.id} value={d.id}>
                            {d.label}
                          </option>
                        ))}
                        <option disabled>
                          Your ML model: not connected
                        </option>
                      </select>
                    </label>

                    <label className="check">
                      <input
                        type="checkbox"
                        checked={showProb}
                        onChange={() => setShowProb((v) => !v)}
                      />
                      Show change-probability map
                    </label>
                  </div>

                  <div className="change-summary" role="status">
                    <div>
                      <span>CHANGE CANDIDATES</span>
                      <strong>{view.residuals.length}</strong>
                    </div>

                    <div>
                      <span>OBSERVATION PAIR</span>
                      <strong>
                        {target.epochs[epochList[0]]} →{' '}
                        {target.epochs[epochList[epochList.length - 1]]}
                      </strong>
                    </div>

                    <div>
                      <span>INTERPRETATION</span>
                      <strong>
                        {view.residuals.length
                          ? 'Needs inspection'
                          : 'No strong residuals'}
                      </strong>
                    </div>
                  </div>

                  <p className="fine">
                    Highlighted residuals exceed the selected detection
                    threshold (about 4.5σ; σ = {view.sigma.toFixed(2)}).
                    Treat them as candidates for inspection, not
                    confirmed discoveries.{' '}
                    {target.kind === 'mover' &&
                      'A moving source can leave a dark position in the earlier image and a bright position in the later image.'}
                  </p>

                  {view.residuals.length > 0 && (
                    <ul className="residuals">
                      {view.residuals.slice(0, 5).map((r, i) => (
                        <li key={i}>
                          ({r.x}, {r.y}) ·{' '}
                          {r.z >= 0 ? 'brighter' : 'fainter'} later ·{' '}
                          {Math.abs(r.z).toFixed(1)}σ
                        </li>
                      ))}
                    </ul>
                  )}

                  {view.residuals.length === 0 && (
                    <p className="fine">
                      No significant changes found. Try an all-band
                      co-add to dig deeper.
                    </p>
                  )}
                </>
              )}

              {eff === 'blink' && (
                <p className="fine">
                  Blinking between{' '}
                  {cmpSorted.map((i) => target.epochs[i]).join(' → ')}.
                  Anything that jumps is moving or changing.
                </p>
              )}

              {eff === 'add' && (
                <p className="fine">
                  Averaging {cmpSorted.length} epochs to reduce noise
                  (noise falls by about √{cmpSorted.length}). A mover
                  smears into a streak.
                </p>
              )}
            </div>
          </section>

          <div className="viewer-toolbar">
            <div className="viewer-heading">
              <span className="eyebrow-small">
                IMAGE ANALYSIS
              </span>
              <b>
                {eff === 'side'
                  ? 'Compare two observations'
                  : eff === 'blink'
                    ? 'Watch the sky change'
                    : eff === 'sub'
                      ? 'Inspect detected differences'
                      : 'Inspect the selected observation'}
              </b>
            </div>

            <div
              className="view-switcher"
              role="group"
              aria-label="Display mode"
            >
              {MODES.map((m) => (
                <button
                  key={m.id}
                  className={mode === m.id ? 'active' : ''}
                  onClick={() => {
                    setMode(m.id);
                    setBandPlay(false);
                  }}
                >
                  {m.label}
                </button>
              ))}
            </div>

            <div className="viewer-tools">
              <button
                title="Zoom out"
                aria-label="Zoom out"
                onClick={() =>
                  setZoom((v) => Math.max(0.7, +(v - 0.1).toFixed(1)))
                }
              >
                <Minus size={15} />
              </button>

              <span>{Math.round(zoom * 100)}%</span>

              <button
                title="Zoom in"
                aria-label="Zoom in"
                onClick={() =>
                  setZoom((v) => Math.min(1.8, +(v + 0.1).toFixed(1)))
                }
              >
                <Plus size={15} />
              </button>

              <button
                title="Reset zoom"
                aria-label="Reset zoom"
                onClick={() => setZoom(1)}
              >
                <RotateCcw size={15} />
              </button>
            </div>
          </div>

          {/* band explorer */}
          {mode !== 'all' && (
            <div className="ctl-card">
              {mode === 'band' && (
                <>
                  <div className="ctl-head">
                    <b>Band explorer</b>
                    <span>
                      {band.center.toFixed(3)} µm · band {bandIdx + 1}{' '}
                      of 102 · detector D{band.array + 1}
                    </span>
                  </div>

                  <div className="ctl-row">
                    <button
                      className="mini"
                      aria-label="Previous band"
                      onClick={() => {
                        setBandPlay(false);
                        setBandIdx((b) => Math.max(0, b - 1));
                      }}
                    >
                      <ChevronLeft size={16} />
                    </button>

                    <button
                      className="mini on"
                      aria-label={
                        bandPlay
                          ? 'Pause band playback'
                          : 'Play through bands'
                      }
                      onClick={() => setBandPlay((v) => !v)}
                    >
                      {bandPlay ? (
                        <Pause size={15} />
                      ) : (
                        <Play size={15} />
                      )}
                    </button>

                    <button
                      className="mini"
                      aria-label="Next band"
                      onClick={() => {
                        setBandPlay(false);
                        setBandIdx((b) => Math.min(101, b + 1));
                      }}
                    >
                      <ChevronRight size={16} />
                    </button>

                    <input
                      className="wl-slider"
                      type="range"
                      min={0}
                      max={101}
                      value={bandIdx}
                      onChange={(e) => {
                        setBandPlay(false);
                        setBandIdx(Number(e.target.value));
                      }}
                      aria-label="Wavelength band"
                      aria-valuetext={`${band.center.toFixed(2)} micrometres`}
                    />
                  </div>

                  <div className="array-strip" aria-hidden="true">
                    {range(6).map((a) => (
                      <span
                        key={a}
                        className={band.array === a ? 'here' : ''}
                      >
                        D{a + 1}
                      </span>
                    ))}
                  </div>
                </>
              )}

              {mode === 'array' && (
                <>
                  <div className="ctl-head">
                    <b>Per-array co-add</b>
                    <span>
                      17 bands stacked from detector D{arr + 1} ·{' '}
                      {BANDS[arr * 17].lo.toFixed(2)}–
                      {BANDS[arr * 17 + 16].hi.toFixed(2)} µm
                    </span>
                  </div>

                  <div className="ctl-row">
                    <button
                      className="mini on"
                      aria-label={
                        bandPlay ? 'Pause' : 'Cycle through arrays'
                      }
                      onClick={() => setBandPlay((v) => !v)}
                    >
                      {bandPlay ? (
                        <Pause size={15} />
                      ) : (
                        <Play size={15} />
                      )}
                    </button>

                    <div
                      className="seg"
                      role="group"
                      aria-label="Detector array"
                    >
                      {range(6).map((a) => (
                        <button
                          key={a}
                          className={arr === a ? 'active' : ''}
                          aria-pressed={arr === a}
                          onClick={() => {
                            setBandPlay(false);
                            setArr(a);
                          }}
                        >
                          D{a + 1}
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}

              {isRgb && (
                <>
                  <div className="ctl-head">
                    <b>False-colour composite builder</b>
                    <span>
                      Choose which wavelengths feed each colour
                    </span>
                  </div>

                  {rgb.map(([lo, hi], c) => (
                    <div className="rgb-row" key={c}>
                      <span className="rgb-name">
                        <i
                          style={{
                            background: [
                              '#ff6b5e',
                              '#6ee08f',
                              '#6aa4ff',
                            ][c],
                          }}
                        />
                        {['Red', 'Green', 'Blue'][c]}
                      </span>

                      <input
                        type="range"
                        min={0.75}
                        max={5}
                        step={0.05}
                        value={lo}
                        onChange={(e) =>
                          setRange(c, 0, Number(e.target.value))
                        }
                        aria-label={`${['Red', 'Green', 'Blue'][c]} from (µm)`}
                      />

                      <input
                        type="range"
                        min={0.75}
                        max={5}
                        step={0.05}
                        value={hi}
                        onChange={(e) =>
                          setRange(c, 1, Number(e.target.value))
                        }
                        aria-label={`${['Red', 'Green', 'Blue'][c]} to (µm)`}
                      />

                      <span className="rgb-val">
                        {lo.toFixed(2)}–{hi.toFixed(2)} µm ·{' '}
                        {channels[c].length} bands
                      </span>
                    </div>
                  ))}
                </>
              )}

              <label className="speed-control inline">
                Speed
                <select
                  value={speed}
                  onChange={(e) => setSpeed(e.target.value)}
                >
                  <option value="0.5">0.5×</option>
                  <option value="1">1×</option>
                  <option value="2">2×</option>
                  <option value="4">4×</option>
                </select>
              </label>
            </div>
          )}

          {mode === 'all' && (
            <div className="ctl-card">
              <div className="ctl-head">
                <b>All-band co-add</b>
                <span>
                  All 102 bands averaged: faintest sources, lowest noise
                  (σ ≈ {view.sigma.toFixed(2)})
                </span>
              </div>
            </div>
          )}


            {!embed && (
              <nav className="sidebar-analysis-nav" aria-label="Analysis and tools">
                <span className="sidebar-nav-title">ANALYSIS &amp; TOOLS</span>
                <button type="button" onClick={() => setAnalysisScreen('spectrum')}><span>Wavelength spectrum</span><small>Inspect a pixel across infrared bands</small></button>
                <button type="button" onClick={() => setAnalysisScreen('lightcurve')}><span>Brightness over time</span><small>Track brightness across observations</small></button>
                <button type="button" onClick={() => setAnalysisScreen('details')}><span>Observation details</span><small>Metadata and quality information</small></button>
                <button type="button" onClick={() => setAnalysisScreen('share')}><span>Share this view</span><small>Copy a link or embed code</small></button>
                <button type="button" onClick={() => setHelpOpen(true)}><span>Help</span><small>Learn the controls and terminology</small></button>
              </nav>
            )}

          </aside>
        )}

        {!embed && !sidebarOpen && (
          <button className="controls-reopen" type="button" onClick={() => setSidebarOpen(true)} aria-label="Open controls">
            <SlidersHorizontal size={16} />
            <span>CONTROLS</span>
          </button>
        )}

        <section className="explorer-main">
          <div className="target-heading">
            <div>
              <div className="eyebrow-small">
                LUMENX SKY LAB <span>·</span> SELECTED REGION{' '}
                {target.id.toUpperCase()}
              </div>

              <h1>{target.name}</h1>

              <p>
                RA {ra}° <span>·</span> Dec {dec}° <span>·</span>{' '}
                {fov}′ field
              </p>
            </div>


          </div>


          {target.note && (
            <div className="target-note">
              <b>{target.noteTitle}.</b> {target.note}
            </div>
          )}

          {message && (
            <div className="feedback-message" role="status">
              <span>{message}</span>
              <button
                onClick={() => setMessage('')}
                aria-label="Dismiss message"
              >
                <X size={14} />
              </button>
            </div>
          )}

          <div
            className={`image-stage mode-${
              eff === 'side' ? 'compare' : 'single'
            }`}
          >
            {eff === 'side' && view.rgbaB ? (
              <>
                <div className="image-panel">
                  <div className="image-panel-label">
                    {target.epochs[epochList[0]]}
                    <span>EARLIER</span>
                  </div>

                  <SkyFrame
                    rgba={view.rgba}
                    {...frameProps}
                    expected={markAt(
                      epochList[0],
                      target.kind === 'mover'
                        ? 'expected'
                        : undefined
                    )}
                    gaia={cat('gaia', epochList[0])}
                    wise={cat('wise', epochList[0])}
                    mask={maskArr}
                    ariaLabel="Earlier epoch"
                  />
                </div>

                <div className="image-panel">
                  <div className="image-panel-label">
                    {target.epochs[epochList[epochList.length - 1]]}
                    <span>LATER</span>
                  </div>

                  <SkyFrame
                    rgba={view.rgbaB}
                    {...frameProps}
                    expected={markAt(
                      dispEp,
                      target.kind === 'mover'
                        ? 'expected'
                        : undefined
                    )}
                    mask={maskArr}
                    ariaLabel="Later epoch"
                  />
                </div>
              </>
            ) : (
              <div className="single-image-panel">
                <div className="image-panel-label">
                  {target.epochs[dispEp]}
                  <span>{view.label}</span>
                </div>

                <SkyFrame
                  rgba={view.rgba}
                  {...frameProps}
                  mask={maskArr}
                  ariaLabel={`${target.name} ${view.label}`}
                />
              </div>
            )}

          </div>

          {helpOpen && !embed && (
            <div className="analysis-overlay help-overlay" role="dialog" aria-modal="true" aria-label="LumenX help">
              <section className="analysis-screen">
                <div className="analysis-screen-head">
                  <div><span className="eyebrow-small">LUMENX GUIDE</span><h2>How to explore the sky</h2></div>
                  <button className="analysis-close" onClick={() => setHelpOpen(false)} aria-label="Close help"><X /></button>
                </div>
                {GLOSSARY.map(([q, a]) => <details key={q} className="help-item"><summary>{q}</summary><p>{a}</p></details>)}
              </section>
            </div>
          )}

          {analysisScreen && !embed && (
            <div className="analysis-overlay" role="dialog" aria-modal="true" aria-label={analysisScreen === 'spectrum' ? 'Wavelength spectrum' : analysisScreen === 'lightcurve' ? 'Brightness over time' : analysisScreen === 'details' ? 'Observation details' : 'Share this view'}>
              <section className="analysis-screen">
                <div className="analysis-screen-head">
                  <div>
                    <span className="eyebrow-small">{analysisScreen === 'details' ? 'OBSERVATION RECORD' : analysisScreen === 'share' ? 'COLLABORATION' : 'SCIENTIFIC ANALYSIS'}</span>
                    <h2>{analysisScreen === 'spectrum' ? 'Wavelength spectrum' : analysisScreen === 'lightcurve' ? 'Brightness over time' : analysisScreen === 'details' ? 'Observation details' : 'Share this view'}</h2>
                    <p>{target.name} · {analysisScreen === 'spectrum' ? 'Selected pixel across infrared wavelengths' : analysisScreen === 'lightcurve' ? 'Brightness across observation epochs' : analysisScreen === 'details' ? `Epoch ${dispEp + 1} · ${cur.date}` : 'Share the current exploration settings'}</p>
                  </div>
                  <button className="analysis-close" onClick={() => setAnalysisScreen(null)} aria-label="Close screen"><X /></button>
                </div>
                {analysisScreen === 'spectrum' && (spec ? <SpectrumChart points={spec} marked={isRgb || channels[0].length === 102 ? [] : channels[0]} /> : <p className="fine">Select a pixel in the sky image to generate its spectrum.</p>)}
                {analysisScreen === 'lightcurve' && (tSrc && lc.length >= MIN_EPOCHS_LC ? <LightCurve points={lc} /> : <p className="fine">There are not enough observations in this selection to display a light curve.</p>)}
                {analysisScreen === 'details' && (
                  <>
                    <div className="metadata-grid">
                      <div><span>Observation date</span><strong>{cur.date}</strong></div>
                      <div><span>Modified Julian Date</span><strong>{fmtMjd(cur.mjd)}</strong></div>
                      <div><span>Band shown</span><strong>{bandLabel}</strong></div>
                      <div><span>Detector array</span><strong>{isRgb ? 'D1–D6 (mixed)' : mode === 'band' ? `D${band.array + 1}` : mode === 'array' ? `D${arr + 1}` : 'D1–D6'}</strong></div>
                      <div><span>Bands combined</span><strong>{allBands.length}</strong></div>
                      <div><span>Exposure</span><strong>1 visit · 110 s each</strong></div>
                      <div><span>Cutout</span><strong>{scene.w} × {scene.h} px · {PIXEL_ARCSEC}″/px</strong></div>
                      <div><span>Noise level σ</span><strong>{view.sigma.toFixed(2)}</strong></div>
                      <div><span>Provenance</span><strong>Sample catalogue record</strong></div>
                    </div>
                    <div className="flag-explain">{FLAG_INFO.map((f) => <p key={f.bit}><i style={{ background: f.color }} /><b>{f.name}.</b> {f.text}</p>)}</div>
                  </>
                )}
                {analysisScreen === 'share' && (
                  <div className="share-screen-content">
                    <p>Anyone with this link can reopen the current target, field of view, wavelength and comparison settings.</p>
                    <label className="field-label" htmlFor="share-url">Shareable link</label>
                    <input id="share-url" className="share-field" readOnly value={shareUrl} onFocus={(e) => e.currentTarget.select()} />
                    <div className="ctl-row wrap">
                      <button className="mini wide" onClick={() => copy(shareUrl, 'link')}>{copied === 'link' ? 'Copied ✓' : 'Copy link'}</button>
                      <button className="mini wide" onClick={() => copy(`<iframe src="${embedUrl}" width="100%" height="720" style="border:0" title="LumenX viewer"></iframe>`, 'embed')}>{copied === 'embed' ? 'Copied ✓' : 'Copy embed code'}</button>
                    </div>
                  </div>
                )}
              </section>
            </div>
          )}


        </section>
      </main>
    </div>
  );
}