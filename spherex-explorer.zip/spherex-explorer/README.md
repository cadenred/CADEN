# SPHEREx Explorer — frontend prototype

React + TypeScript + Vite interface for the Lumen X project.

## Run locally on Windows

Open PowerShell in this folder and run:

```powershell
npm install
npm run dev
```

Open the local URL printed by Vite (usually http://localhost:5173).

## Current demo experience

- Choose one of three illustrative sky targets.
- Enter RA, Dec, and a search radius; the values are validated locally.
- Browse four illustrative observation timestamps.
- Play/pause the sequence and change playback speed.
- Switch between single-image, side-by-side, and blink demonstration modes.
- Zoom the display and inspect demonstration metadata.

## Important scientific limitation

All sky images, observation dates, wavelength labels, and metadata in this prototype are demonstration content. The coordinate form does not contact NASA, IRSA, or a backend. The comparison and blink modes are visual UI demonstrations, not calibrated scientific comparisons or difference products.

## Tailwind note

The current visual system is authored in `src/styles/index.css`. Tailwind is installed but not currently used for utility classes, so its PostCSS plugin is not enabled; this avoids the warning about no utility classes being detected.
