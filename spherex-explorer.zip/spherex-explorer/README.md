# LumenX — NASA Space Apps 2026, "Planet X and SPHEREx"

The app opens straight into the explorer: a rotatable all-sky globe. Click a target, any patch of sky, or search a name / coordinates and the view flies in to a cutout you can play back as a movie.

## Run
```
npm install
npm run dev
```

## What it does (maps to the challenge)
- **Enter RA/Dec** (decimal or `08h55m10.8s -07d14m42s`) or a name → cutout "video" across visits (play, step, speed, Space to pause).
- **Moving objects**: blink, Difference mode (visit − previous visit) with detections, Co-add of all visits.
- **102 bands**: all bands, per-array co-add (six arrays), or a single band. **Spectra on the fly** by clicking a pixel.
- **Field of view** slider with download-size estimate. **Gaia / WISE overlays** with epoch propagation. **Contamination flags**.
- **URL-addressable**: `?target=wise0855&fov=10&mode=array&arr=5&op=sub` or `?ra=133.795&dec=-7.245`. `&embed=1` hides controls; the code button copies an iframe snippet.
- **Tutorial cards** and guided steps on first load (Worldview-style).
- Pluggable change detector: `src/features/exploration/changeDetection.ts`.

## Important limitation
All images, dates, spectra and catalogues are **synthetic demo data** from `demoData.ts` (and the all-sky starfield is procedural). Nothing contacts NASA/IRSA yet.
To go real: replace `buildScene / renderBands / spectrumAt / catalogue` with calls to a backend that returns IRSA SPHEREx cutouts (same shapes), and drive "latest release" from `MANIFEST`.